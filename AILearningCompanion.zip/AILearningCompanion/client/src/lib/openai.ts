import { apiRequest } from "./queryClient";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

interface AIAnalysisRequest {
  content: string;
  contentType: 'video' | 'slideshow' | 'speech';
  knowledgeLevel: 'beginner' | 'intermediate' | 'advanced';
}

export interface AIFeedback {
  complexity: {
    level: 'low' | 'moderate' | 'high';
    score: number;
    suggestion: string;
  };
  visualOpportunity?: {
    suggestion: string;
  };
  learningEnhancement: {
    suggestion: string;
  };
}

export async function analyzeContent(
  request: AIAnalysisRequest
): Promise<AIFeedback> {
  try {
    const response = await apiRequest(
      'POST', 
      '/api/analyze-content',
      request
    );
    return await response.json();
  } catch (error) {
    console.error('Error analyzing content:', error);
    throw new Error('Failed to analyze content');
  }
}

export interface ContentSuggestion {
  content: string;
}

export async function generateEnhancedContent(
  originalContent: string,
  knowledgeLevel: 'beginner' | 'intermediate' | 'advanced'
): Promise<ContentSuggestion> {
  try {
    const response = await apiRequest(
      'POST',
      '/api/generate-content',
      {
        originalContent,
        knowledgeLevel
      }
    );
    return await response.json();
  } catch (error) {
    console.error('Error generating enhanced content:', error);
    throw new Error('Failed to generate enhanced content');
  }
}
