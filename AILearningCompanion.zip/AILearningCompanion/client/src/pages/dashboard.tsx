import QuickActionCard from "@/components/dashboard/quick-action-card";
import ContentCard from "@/components/dashboard/content-card";
import FeatureCard from "@/components/dashboard/feature-card";
import { Video, SlidersHorizontal, Mic2, FileText, Sparkles, Layers } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: contents, isLoading } = useQuery({
    queryKey: ['/api/contents'],
  });

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Welcome section */}
      <div className="mb-8">
        <h1 className="font-heading text-2xl font-bold text-neutral-400 mb-2">Welcome back, Teacher!</h1>
        <p className="text-neutral-300">Create and enhance your educational content with AI assistance.</p>
      </div>

      {/* New Content Workflow Banner */}
      <Card className="mb-8 bg-gradient-to-r from-primary/90 to-primary border-none text-white">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0 md:mr-6">
              <h2 className="text-xl font-semibold mb-2">New: Complete Content Creation Workflow</h2>
              <p className="opacity-90 mb-4">
                Create professional educational content in 3 simple steps:
              </p>
              <ol className="list-decimal ml-5 space-y-1 opacity-90">
                <li>Write a speech with AI assistance tailored to knowledge levels</li>
                <li>Generate slideshow presentations from your speech</li>
                <li>Record videos with eye contact analysis and speech clarity feedback</li>
              </ol>
            </div>
            <Link href="/create-workflow">
              <Button size="lg" variant="outline" className="bg-white/10 text-white border-white hover:bg-white/20">
                <Sparkles className="mr-2 h-5 w-5" />
                Try the New Workflow
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Quick actions */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="md:col-span-4 mb-2">
          <h2 className="font-heading text-xl font-semibold text-neutral-400">Create Content</h2>
        </div>
        
        <QuickActionCard
          title="Complete Workflow"
          description="Create educational content in a guided process from speech to video."
          icon={<Layers className="h-6 w-6" />}
          buttonText="Start Workflow"
          href="/create-workflow"
        />
        <QuickActionCard
          title="Video Course"
          description="Record, upload, and enhance video content with AI feedback."
          icon={<Video className="h-6 w-6" />}
          buttonText="New Course"
          href="/create?type=video"
        />
        <QuickActionCard
          title="Slideshow"
          description="Build engaging slide presentations with optimized content flow."
          icon={<SlidersHorizontal className="h-6 w-6" />}
          buttonText="New Slideshow"
          href="/create?type=slideshow"
        />
        <QuickActionCard
          title="Speech"
          description="Write and refine speeches with AI-powered content suggestions."
          icon={<Mic2 className="h-6 w-6" />}
          buttonText="New Speech"
          href="/create?type=speech"
        />
      </div>

      {/* Recent Content */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-heading text-xl font-semibold text-neutral-400">Recent Content</h2>
          <a href="#" className="text-primary hover:text-primary-dark transition-colors flex items-center">
            View All <span className="material-icons ml-1 text-sm">arrow_forward</span>
          </a>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="h-40 bg-gray-200"></div>
                <CardContent className="p-4">
                  <div className="h-5 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-100 rounded mb-3"></div>
                  <div className="h-3 bg-gray-200 rounded mb-3"></div>
                  <div className="flex justify-between">
                    <div className="h-4 w-24 bg-gray-100 rounded"></div>
                    <div className="h-8 w-8 rounded-full bg-gray-200"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <ContentCard
              id="1"
              title="Introduction to Machine Learning"
              type="video"
              lastEdited="2 days ago"
              complexityLevel="intermediate"
              complexityScore={0.75}
              optimized={true}
              imageUrl="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
              editLink="/video-courses/1"
            />
            <ContentCard
              id="2"
              title="Leadership Communication"
              type="speech"
              lastEdited="1 week ago"
              complexityLevel="advanced"
              complexityScore={1.0}
              optimized={false}
              imageUrl="https://images.unsplash.com/photo-1475721027785-f74eccf877e2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
              editLink="/speeches/2"
            />
            <ContentCard
              id="3"
              title="Intro to Digital Marketing"
              type="slideshow"
              lastEdited="3 days ago"
              complexityLevel="beginner"
              complexityScore={0.33}
              optimized={true}
              imageUrl="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
              editLink="/slideshows/3"
            />
          </div>
        )}
      </div>

      {/* Features Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="md:col-span-4 mb-2">
          <h2 className="font-heading text-xl font-semibold text-neutral-400">Key Features</h2>
        </div>
        
        <FeatureCard
          title="AI Content Analysis"
          description="Our AI analyzes your content and provides feedback on complexity, engagement, and clarity."
          imageUrl="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250"
          imageAlt="AI Content Analysis"
        />
        <FeatureCard
          title="Knowledge Level Adaptation"
          description="Customize content for beginner, intermediate, or advanced learners with targeted suggestions."
          imageUrl="https://images.unsplash.com/photo-1509062522246-3755977927d7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250"
          imageAlt="Knowledge Level Adaptation"
        />
        <FeatureCard
          title="Eye Contact Analysis"
          description="Get real-time feedback on your eye contact during video recordings to enhance engagement."
          imageUrl="https://images.unsplash.com/photo-1577741314755-048d8525d31e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250"
          imageAlt="Eye Contact Analysis"
        />
        <FeatureCard
          title="Speech Clarity Feedback"
          description="Analyze your speech for clarity and understandability to improve learning outcomes."
          imageUrl="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250"
          imageAlt="Speech Clarity Feedback"
        />
      </div>
    </div>
  );
}
