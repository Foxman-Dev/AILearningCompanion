import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import TabNavigation from "@/components/content-creator/tab-navigation";
import ContentEditor from "@/components/content-creator/content-editor";
import AIAssistant from "@/components/content-creator/ai-assistant";
import { useToast } from "@/hooks/use-toast";
import { AIFeedback, analyzeContent, generateEnhancedContent } from "@/lib/openai";

export default function ContentCreator() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1]);
  const initialType = searchParams.get('type') as 'slideshow' | 'video' | 'speech' || 'slideshow';
  
  const [activeTab, setActiveTab] = useState<'slideshow' | 'video' | 'speech'>(initialType);
  const [feedback, setFeedback] = useState<AIFeedback | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentContent, setCurrentContent] = useState("");
  const [currentLevel, setCurrentLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('beginner');
  const { toast } = useToast();
  
  const handleAnalyzeContent = async (content: string, knowledgeLevel: 'beginner' | 'intermediate' | 'advanced') => {
    setIsAnalyzing(true);
    setCurrentContent(content);
    setCurrentLevel(knowledgeLevel);
    
    try {
      const result = await analyzeContent({
        content,
        contentType: activeTab,
        knowledgeLevel
      });
      setFeedback(result);
    } catch (error) {
      console.error("Error analyzing content:", error);
      toast({
        title: "Analysis failed",
        description: "There was an error analyzing your content.",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleApplySuggestions = async () => {
    if (!currentContent || !feedback) return;
    
    try {
      const result = await generateEnhancedContent(currentContent, currentLevel);
      toast({
        title: "Suggestions applied",
        description: "The AI suggestions have been applied to your content."
      });
      // In a real implementation, this would update the editor content
      console.log("Enhanced content:", result);
    } catch (error) {
      console.error("Error applying suggestions:", error);
      toast({
        title: "Failed to apply suggestions",
        description: "There was an error applying the AI suggestions.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <Card className="shadow-md p-6 mb-8">
        <CardContent className="p-0">
          <h2 className="font-heading text-xl font-semibold text-neutral-400 mb-4">Content Creator</h2>
          
          <TabNavigation 
            activeTab={activeTab} 
            onTabChange={(tab) => setActiveTab(tab)} 
          />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <ContentEditor 
              contentType={activeTab}
              onAnalyzeContent={handleAnalyzeContent}
            />
            
            <AIAssistant 
              feedback={feedback}
              isLoading={isAnalyzing}
              onApplySuggestions={handleApplySuggestions}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
