import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import ContentCreator from "@/pages/content-creator";
import VideoCoursePage from "@/pages/video-course";
import SlideshowPage from "@/pages/slideshow";
import SpeechPage from "@/pages/speech";
import ContentWorkflowPage from "@/pages/content-workflow";
import AppLayout from "@/components/layout/app-layout";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/create" component={ContentCreator} />
      <Route path="/create-workflow" component={ContentWorkflowPage} />
      <Route path="/video-courses" component={VideoCoursePage} />
      <Route path="/slideshows" component={SlideshowPage} />
      <Route path="/speeches" component={SpeechPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppLayout>
          <Router />
        </AppLayout>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
