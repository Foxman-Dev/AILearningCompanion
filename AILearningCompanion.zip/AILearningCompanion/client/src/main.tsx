import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add CSS variables for the EduGenius theme
document.documentElement.style.setProperty('--primary', '207 90% 54%');
document.documentElement.style.setProperty('--primary-foreground', '211 100% 99%');
document.documentElement.style.setProperty('--secondary', '328 73% 69%');
document.documentElement.style.setProperty('--secondary-foreground', '328 57% 10%');
document.documentElement.style.setProperty('--accent', '199 89% 48%');
document.documentElement.style.setProperty('--accent-foreground', '0 0% 100%');
document.documentElement.style.setProperty('--success', '142 69% 58%');
document.documentElement.style.setProperty('--warning', '36 100% 50%');
document.documentElement.style.setProperty('--error', '0 84% 60%');

createRoot(document.getElementById("root")!).render(<App />);
