import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Trophy,
  Award,
  BarChart3,
  Target,
  TrendingUp,
  FileText,
  SlidersHorizontal,
  Video,
  Star,
  Gift,
  Calendar,
  Clock,
  Lock,
  ChevronUp,
  CheckCircle2,
  Sparkles
} from "lucide-react";

interface ProgressDashboardProps {
  userId: number;
}

interface LearningProgress {
  id: number;
  userId: number;
  totalPoints: number;
  level: number;
  contentCreated: number;
  speechCompleted: number;
  slideshowsCreated: number;
  videosRecorded: number;
  avgEyeContactScore: number;
  avgSpeechClarityScore: number;
  lastUpdated: string;
}

interface UserStats {
  contentCount: number;
  speechCount: number;
  slideshowCount: number;
  videoCount: number;
  avgEyeContactScore: number;
  avgSpeechClarityScore: number;
  achievementCount: number;
}

interface Achievement {
  id: number;
  userId: number;
  type: string;
  title: string;
  description: string;
  pointsAwarded: number;
  iconUrl: string | null;
  dateEarned: string;
  level: number;
}

interface LearningMilestone {
  id: number;
  level: number;
  pointsRequired: number;
  title: string;
  description: string;
  rewardDescription: string | null;
  iconUrl: string | null;
}

export default function ProgressDashboard({ userId }: ProgressDashboardProps) {
  const [activeTab, setActiveTab] = useState("progress");
  const { toast } = useToast();
  
  // Fetch learning progress data
  const { data: progress, isLoading: progressLoading } = useQuery({
    queryKey: [`/api/users/${userId}/progress`],
    enabled: !!userId
  });
  
  // Fetch user stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: [`/api/users/${userId}/stats`],
    enabled: !!userId
  });
  
  // Fetch user achievements
  const { data: achievements, isLoading: achievementsLoading } = useQuery({
    queryKey: [`/api/users/${userId}/achievements`],
    enabled: !!userId
  });
  
  // Fetch learning milestones
  const { data: milestones, isLoading: milestonesLoading } = useQuery({
    queryKey: [`/api/learning-milestones`]
  });

  // Calculate next milestone
  const getNextMilestone = () => {
    if (!progress || !milestones) return null;
    
    // Find the next milestone based on current level
    return milestones.find(m => m.level > progress.level);
  };
  
  // Calculate progress to next level
  const calculateLevelProgress = () => {
    if (!progress || !milestones) return 0;
    
    // Find current and next milestone
    const currentMilestone = milestones.find(m => m.level === progress.level);
    const nextMilestone = milestones.find(m => m.level === progress.level + 1);
    
    if (!currentMilestone || !nextMilestone) return 100; // If at max level, show 100%
    
    // Calculate points needed for next level and current progress
    const pointsNeeded = nextMilestone.pointsRequired - currentMilestone.pointsRequired;
    const pointsGained = progress.totalPoints - currentMilestone.pointsRequired;
    
    return Math.min(100, Math.round((pointsGained / pointsNeeded) * 100));
  };
  
  // Group achievements by type
  const groupedAchievements = () => {
    if (!achievements) return {};
    
    const grouped = achievements.reduce((acc, achievement) => {
      if (!acc[achievement.type]) {
        acc[achievement.type] = [];
      }
      acc[achievement.type].push(achievement);
      return acc;
    }, {});
    
    return grouped;
  };
  
  // Format a date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };
  
  // Generate achievement icon based on type or use default
  const getAchievementIcon = (achievement: Achievement) => {
    if (achievement.type === 'content_created') return <FileText className="h-5 w-5" />;
    if (achievement.type === 'speech_mastery') return <FileText className="h-5 w-5" />;
    if (achievement.type === 'slideshow_expert') return <SlidersHorizontal className="h-5 w-5" />;
    if (achievement.type === 'video_presenter') return <Video className="h-5 w-5" />;
    if (achievement.type === 'eye_contact_master') return <Star className="h-5 w-5" />;
    if (achievement.type === 'speech_clarity_champion') return <Star className="h-5 w-5" />;
    if (achievement.type === 'content_series_completed') return <CheckCircle2 className="h-5 w-5" />;
    if (achievement.type === 'knowledge_level_up') return <TrendingUp className="h-5 w-5" />;
    return <Award className="h-5 w-5" />; // Default icon
  };
  
  // Generate a color class based on level
  const getLevelColorClass = (level: number) => {
    if (level === 1) return "bg-neutral-100 text-neutral-800";
    if (level === 2) return "bg-blue-100 text-blue-800";
    if (level === 3) return "bg-green-100 text-green-800";
    if (level === 4) return "bg-purple-100 text-purple-800";
    if (level === 5) return "bg-amber-100 text-amber-800";
    if (level >= 6) return "bg-gradient-to-r from-blue-500 to-violet-500 text-white";
    return "bg-neutral-100 text-neutral-800";
  };

  // Format level name based on level number
  const formatLevelName = (level: number) => {
    if (!milestones) return `Level ${level}`;
    
    const milestone = milestones.find(m => m.level === level);
    return milestone ? milestone.title : `Level ${level}`;
  };
  
  // Group milestones into current, next and future
  const categorizeMilestones = () => {
    if (!milestones || !progress) return { current: null, next: null, future: [] };
    
    const current = milestones.find(m => m.level === progress.level);
    const next = milestones.find(m => m.level === progress.level + 1);
    const future = milestones.filter(m => m.level > progress.level + 1);
    
    return { current, next, future };
  };
  
  if (progressLoading || statsLoading || achievementsLoading || milestonesLoading) {
    return (
      <div className="flex items-center justify-center h-[300px]">
        <div className="animate-pulse text-center">
          <div className="h-12 w-12 rounded-full bg-neutral-200 mx-auto mb-4"></div>
          <div className="h-4 w-48 bg-neutral-200 rounded mx-auto mb-2"></div>
          <div className="h-3 w-32 bg-neutral-200 rounded mx-auto"></div>
        </div>
      </div>
    );
  }
  
  if (!progress) {
    return (
      <div className="text-center p-8">
        <Award className="h-12 w-12 mx-auto mb-4 text-neutral-300" />
        <h3 className="text-lg font-medium mb-2">No Progress Data Available</h3>
        <p className="text-neutral-500 mb-4">Start creating educational content to track your progress</p>
      </div>
    );
  }
  
  const { current, next, future } = categorizeMilestones();
  const levelProgress = calculateLevelProgress();

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-8">
        <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-6 grid grid-cols-3">
            <TabsTrigger value="progress" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              <Target className="mr-2 h-4 w-4" /> Progress
            </TabsTrigger>
            <TabsTrigger value="achievements" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              <Trophy className="mr-2 h-4 w-4" /> Achievements
            </TabsTrigger>
            <TabsTrigger value="stats" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              <BarChart3 className="mr-2 h-4 w-4" /> Statistics
            </TabsTrigger>
          </TabsList>
          
          {/* Progress Tab */}
          <TabsContent value="progress" className="space-y-6">
            {/* Current Level Card */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Current Level</CardTitle>
                <CardDescription>Your current progress and next milestone</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Current Level */}
                  <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <Badge className={getLevelColorClass(progress.level)}>Level {progress.level}</Badge>
                      </div>
                      <span className="text-2xl font-bold">{progress.totalPoints} pts</span>
                    </div>
                    
                    <h3 className="text-lg font-medium mb-1">{formatLevelName(progress.level)}</h3>
                    <p className="text-neutral-500 text-sm mb-4">{current?.description}</p>
                    
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span>Progress to Level {progress.level + 1}</span>
                      <span>{levelProgress}%</span>
                    </div>
                    <Progress value={levelProgress} className="h-2 mb-2" />
                  </div>
                  
                  {/* Next Level */}
                  {next ? (
                    <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center">
                          <Badge className={getLevelColorClass(next.level)}>Level {next.level}</Badge>
                        </div>
                        <div className="flex items-center text-sm">
                          <Target className="h-4 w-4 mr-1 text-primary" />
                          <span>{next.pointsRequired} pts required</span>
                        </div>
                      </div>
                      
                      <h3 className="text-lg font-medium mb-1">{next.title}</h3>
                      <p className="text-neutral-500 text-sm mb-4">{next.description}</p>
                      
                      {next.rewardDescription && (
                        <div className="flex items-center text-sm text-primary">
                          <Gift className="h-4 w-4 mr-1" />
                          <span>{next.rewardDescription}</span>
                        </div>
                      )}
                      
                      <div className="mt-4">
                        <div className="text-sm text-neutral-500 mb-1">Points needed:</div>
                        <div className="flex items-center">
                          <Progress 
                            value={(progress.totalPoints / next.pointsRequired) * 100} 
                            className="h-2 flex-1 mr-2" 
                          />
                          <span className="text-sm font-medium">
                            {progress.totalPoints}/{next.pointsRequired}
                          </span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100 flex items-center justify-center">
                      <div className="text-center">
                        <Sparkles className="h-8 w-8 mx-auto mb-2 text-amber-500" />
                        <h3 className="text-lg font-medium mb-1">Maximum Level Reached!</h3>
                        <p className="text-neutral-500 text-sm">You've reached the highest level available</p>
                      </div>
                    </div>
                  )}
                  
                  {/* Recent Achievement */}
                  {achievements && achievements.length > 0 ? (
                    <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-medium">Recent Achievement</h3>
                        <Badge className="bg-amber-100 text-amber-800">
                          +{achievements[0].pointsAwarded} pts
                        </Badge>
                      </div>
                      
                      <div className="flex items-center mb-2">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                          {getAchievementIcon(achievements[0])}
                        </div>
                        <div>
                          <h4 className="font-medium">{achievements[0].title}</h4>
                          <p className="text-xs text-neutral-500">{achievements[0].description}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between text-xs text-neutral-500 mt-3">
                        <div className="flex items-center">
                          <Calendar className="h-3 w-3 mr-1" />
                          <span>{formatDate(achievements[0].dateEarned)}</span>
                        </div>
                        <Button variant="link" size="sm" className="text-xs h-auto p-0" onClick={() => setActiveTab("achievements")}>
                          View All
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100 flex items-center justify-center">
                      <div className="text-center">
                        <Trophy className="h-8 w-8 mx-auto mb-2 text-neutral-300" />
                        <h3 className="text-neutral-600 font-medium mb-1">No Achievements Yet</h3>
                        <p className="text-neutral-500 text-xs">Complete tasks to earn achievements</p>
                      </div>
                    </div>
                  )}
                </div>
                
                {/* Future Levels */}
                {future.length > 0 && (
                  <div className="mt-6">
                    <h3 className="text-sm font-medium mb-3">Future Levels</h3>
                    <div className="space-y-3">
                      {future.map((milestone) => (
                        <div key={milestone.level} className="bg-white p-3 rounded-lg shadow-sm border border-neutral-100">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <Badge className={getLevelColorClass(milestone.level)}>Level {milestone.level}</Badge>
                              <span className="ml-3 font-medium">{milestone.title}</span>
                            </div>
                            <div className="flex items-center text-xs text-neutral-500">
                              <Target className="h-3 w-3 mr-1" />
                              <span>{milestone.pointsRequired} pts required</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* Content Creation Progress */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Content Creation Progress</CardTitle>
                <CardDescription>Track your educational content portfolio</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-neutral-500 text-sm">Total Content</span>
                      <Badge className="bg-neutral-100 text-neutral-800">{progress.contentCreated}</Badge>
                    </div>
                    <div className="text-2xl font-bold mb-3">{progress.contentCreated}</div>
                    <Progress 
                      value={Math.min(100, (progress.contentCreated / 10) * 100)} 
                      className="h-1 mb-2" 
                    />
                    <div className="text-xs text-neutral-500">
                      {progress.contentCreated >= 10 ? 
                        "Expert Creator Status Achieved!" : 
                        `${10 - progress.contentCreated} more to reach Expert status`}
                    </div>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-neutral-500 text-sm">Speeches</span>
                      <Badge className="bg-blue-100 text-blue-800">{progress.speechCompleted}</Badge>
                    </div>
                    <div className="text-2xl font-bold mb-3">{progress.speechCompleted}</div>
                    <Progress 
                      value={Math.min(100, (progress.speechCompleted / 10) * 100)} 
                      className="h-1 mb-2" 
                    />
                    <div className="text-xs text-neutral-500">
                      {progress.speechCompleted >= 10 ? 
                        "Speech Master Status Achieved!" : 
                        `${10 - progress.speechCompleted} more to reach Master status`}
                    </div>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-neutral-500 text-sm">Slideshows</span>
                      <Badge className="bg-green-100 text-green-800">{progress.slideshowsCreated}</Badge>
                    </div>
                    <div className="text-2xl font-bold mb-3">{progress.slideshowsCreated}</div>
                    <Progress 
                      value={Math.min(100, (progress.slideshowsCreated / 10) * 100)} 
                      className="h-1 mb-2" 
                    />
                    <div className="text-xs text-neutral-500">
                      {progress.slideshowsCreated >= 10 ? 
                        "Slideshow Master Status Achieved!" : 
                        `${10 - progress.slideshowsCreated} more to reach Master status`}
                    </div>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-neutral-500 text-sm">Videos</span>
                      <Badge className="bg-purple-100 text-purple-800">{progress.videosRecorded}</Badge>
                    </div>
                    <div className="text-2xl font-bold mb-3">{progress.videosRecorded}</div>
                    <Progress 
                      value={Math.min(100, (progress.videosRecorded / 10) * 100)} 
                      className="h-1 mb-2" 
                    />
                    <div className="text-xs text-neutral-500">
                      {progress.videosRecorded >= 10 ? 
                        "Video Master Status Achieved!" : 
                        `${10 - progress.videosRecorded} more to reach Master status`}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-6">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Your Achievements</CardTitle>
                    <CardDescription>Accomplishments and milestones you've earned</CardDescription>
                  </div>
                  {achievements && (
                    <Badge className="bg-primary text-white">{achievements.length} Total</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {achievements && achievements.length > 0 ? (
                  <div className="space-y-6">
                    {Object.entries(groupedAchievements()).map(([type, achievements]) => (
                      <div key={type} className="space-y-2">
                        <h3 className="text-md font-medium mb-2 capitalize">
                          {type.replace(/_/g, ' ')} Achievements
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {(achievements as Achievement[]).map((achievement) => (
                            <div key={achievement.id} className="bg-white p-3 rounded-lg shadow-sm border border-neutral-100 flex">
                              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mr-3 flex-shrink-0">
                                {getAchievementIcon(achievement)}
                              </div>
                              <div className="flex-1">
                                <div className="flex justify-between items-start">
                                  <h4 className="font-medium">{achievement.title}</h4>
                                  <Badge className="bg-amber-100 text-amber-800">+{achievement.pointsAwarded} pts</Badge>
                                </div>
                                <p className="text-sm text-neutral-500 mb-1">{achievement.description}</p>
                                <div className="text-xs text-neutral-400 flex items-center">
                                  <Calendar className="h-3 w-3 mr-1" />
                                  <span>{formatDate(achievement.dateEarned)}</span>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center p-8">
                    <Trophy className="h-12 w-12 mx-auto mb-4 text-neutral-300" />
                    <h3 className="text-lg font-medium mb-2">No Achievements Yet</h3>
                    <p className="text-neutral-500 mb-4">
                      Create educational content to earn achievements and level up
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* Available Achievements */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Available Achievements</CardTitle>
                <CardDescription>Unlock these achievements by creating content</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {/* Content Created Achievements */}
                    <div className="bg-white p-3 rounded-lg shadow-sm border border-neutral-100">
                      <div className="flex items-center mb-2">
                        <div className="h-10 w-10 rounded-full bg-neutral-100 flex items-center justify-center mr-3">
                          <FileText className="h-5 w-5 text-neutral-500" />
                        </div>
                        <div>
                          <h4 className="font-medium">Content Creator</h4>
                          <p className="text-xs text-neutral-500">Create 5 pieces of educational content</p>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex-1 mr-3">
                          <Progress 
                            value={Math.min(100, (progress.contentCreated / 5) * 100)} 
                            className="h-1" 
                          />
                        </div>
                        <div className="text-xs font-medium">
                          {progress.contentCreated}/5
                        </div>
                      </div>
                    </div>
                    
                    {/* Speech Mastery Achievements */}
                    <div className="bg-white p-3 rounded-lg shadow-sm border border-neutral-100">
                      <div className="flex items-center mb-2">
                        <div className="h-10 w-10 rounded-full bg-blue-50 flex items-center justify-center mr-3">
                          <FileText className="h-5 w-5 text-blue-500" />
                        </div>
                        <div>
                          <h4 className="font-medium">Speech Writer</h4>
                          <p className="text-xs text-neutral-500">Create 3 speech scripts</p>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex-1 mr-3">
                          <Progress 
                            value={Math.min(100, (progress.speechCompleted / 3) * 100)} 
                            className="h-1" 
                          />
                        </div>
                        <div className="text-xs font-medium">
                          {progress.speechCompleted}/3
                        </div>
                      </div>
                    </div>
                    
                    {/* Slideshow Expert Achievements */}
                    <div className="bg-white p-3 rounded-lg shadow-sm border border-neutral-100">
                      <div className="flex items-center mb-2">
                        <div className="h-10 w-10 rounded-full bg-green-50 flex items-center justify-center mr-3">
                          <SlidersHorizontal className="h-5 w-5 text-green-500" />
                        </div>
                        <div>
                          <h4 className="font-medium">Slideshow Creator</h4>
                          <p className="text-xs text-neutral-500">Create 3 slideshows</p>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex-1 mr-3">
                          <Progress 
                            value={Math.min(100, (progress.slideshowsCreated / 3) * 100)} 
                            className="h-1" 
                          />
                        </div>
                        <div className="text-xs font-medium">
                          {progress.slideshowsCreated}/3
                        </div>
                      </div>
                    </div>
                    
                    {/* Video Presenter Achievements */}
                    <div className="bg-white p-3 rounded-lg shadow-sm border border-neutral-100">
                      <div className="flex items-center mb-2">
                        <div className="h-10 w-10 rounded-full bg-purple-50 flex items-center justify-center mr-3">
                          <Video className="h-5 w-5 text-purple-500" />
                        </div>
                        <div>
                          <h4 className="font-medium">Video Presenter</h4>
                          <p className="text-xs text-neutral-500">Record 3 educational videos</p>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex-1 mr-3">
                          <Progress 
                            value={Math.min(100, (progress.videosRecorded / 3) * 100)} 
                            className="h-1" 
                          />
                        </div>
                        <div className="text-xs font-medium">
                          {progress.videosRecorded}/3
                        </div>
                      </div>
                    </div>
                    
                    {/* Content Trifecta Achievement */}
                    <div className="bg-white p-3 rounded-lg shadow-sm border border-neutral-100">
                      <div className="flex items-center mb-2">
                        <div className="h-10 w-10 rounded-full bg-amber-50 flex items-center justify-center mr-3">
                          <CheckCircle2 className="h-5 w-5 text-amber-500" />
                        </div>
                        <div>
                          <h4 className="font-medium">Content Trifecta</h4>
                          <p className="text-xs text-neutral-500">Create all three types of content</p>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex-1 mr-3">
                          <Progress 
                            value={
                              ((progress.speechCompleted > 0 ? 1 : 0) + 
                               (progress.slideshowsCreated > 0 ? 1 : 0) + 
                               (progress.videosRecorded > 0 ? 1 : 0)) / 3 * 100
                            } 
                            className="h-1" 
                          />
                        </div>
                        <div className="text-xs font-medium">
                          {(progress.speechCompleted > 0 ? 1 : 0) + 
                           (progress.slideshowsCreated > 0 ? 1 : 0) + 
                           (progress.videosRecorded > 0 ? 1 : 0)}/3
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Statistics Tab */}
          <TabsContent value="stats" className="space-y-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Content Creation Statistics</CardTitle>
                <CardDescription>Overview of your educational content portfolio</CardDescription>
              </CardHeader>
              <CardContent>
                {stats ? (
                  <div className="space-y-6">
                    {/* Content Type Distribution */}
                    <div>
                      <h3 className="text-md font-medium mb-3">Content Type Distribution</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center">
                              <div className="h-8 w-8 rounded-full bg-blue-50 flex items-center justify-center mr-2">
                                <FileText className="h-4 w-4 text-blue-500" />
                              </div>
                              <span className="font-medium">Speeches</span>
                            </div>
                            <Badge className="bg-blue-100 text-blue-800">{stats.speechCount}</Badge>
                          </div>
                          <Progress 
                            value={stats.contentCount ? (stats.speechCount / stats.contentCount) * 100 : 0} 
                            className="h-1 mb-1" 
                          />
                          <div className="text-xs text-neutral-500 text-right">
                            {stats.contentCount ? 
                              Math.round((stats.speechCount / stats.contentCount) * 100) : 0}% of portfolio
                          </div>
                        </div>
                        
                        <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center">
                              <div className="h-8 w-8 rounded-full bg-green-50 flex items-center justify-center mr-2">
                                <SlidersHorizontal className="h-4 w-4 text-green-500" />
                              </div>
                              <span className="font-medium">Slideshows</span>
                            </div>
                            <Badge className="bg-green-100 text-green-800">{stats.slideshowCount}</Badge>
                          </div>
                          <Progress 
                            value={stats.contentCount ? (stats.slideshowCount / stats.contentCount) * 100 : 0} 
                            className="h-1 mb-1" 
                          />
                          <div className="text-xs text-neutral-500 text-right">
                            {stats.contentCount ? 
                              Math.round((stats.slideshowCount / stats.contentCount) * 100) : 0}% of portfolio
                          </div>
                        </div>
                        
                        <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center">
                              <div className="h-8 w-8 rounded-full bg-purple-50 flex items-center justify-center mr-2">
                                <Video className="h-4 w-4 text-purple-500" />
                              </div>
                              <span className="font-medium">Videos</span>
                            </div>
                            <Badge className="bg-purple-100 text-purple-800">{stats.videoCount}</Badge>
                          </div>
                          <Progress 
                            value={stats.contentCount ? (stats.videoCount / stats.contentCount) * 100 : 0} 
                            className="h-1 mb-1" 
                          />
                          <div className="text-xs text-neutral-500 text-right">
                            {stats.contentCount ? 
                              Math.round((stats.videoCount / stats.contentCount) * 100) : 0}% of portfolio
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Performance Metrics */}
                    <div>
                      <h3 className="text-md font-medium mb-3">Performance Metrics</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                          <div className="flex items-center mb-2">
                            <div className="h-8 w-8 rounded-full bg-amber-50 flex items-center justify-center mr-2">
                              <Eye className="h-4 w-4 text-amber-500" />
                            </div>
                            <span className="font-medium">Average Eye Contact Score</span>
                          </div>
                          <div className="text-2xl font-bold mb-2">{stats.avgEyeContactScore}%</div>
                          <Progress 
                            value={stats.avgEyeContactScore} 
                            className="h-1 mb-1" 
                          />
                          <div className="text-xs text-neutral-500">
                            {stats.avgEyeContactScore >= 80 ? "Excellent eye contact" : 
                             stats.avgEyeContactScore >= 60 ? "Good eye contact" : 
                             "Needs improvement"}
                          </div>
                        </div>
                        
                        <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                          <div className="flex items-center mb-2">
                            <div className="h-8 w-8 rounded-full bg-cyan-50 flex items-center justify-center mr-2">
                              <Star className="h-4 w-4 text-cyan-500" />
                            </div>
                            <span className="font-medium">Average Speech Clarity</span>
                          </div>
                          <div className="text-2xl font-bold mb-2">{stats.avgSpeechClarityScore}%</div>
                          <Progress 
                            value={stats.avgSpeechClarityScore} 
                            className="h-1 mb-1" 
                          />
                          <div className="text-xs text-neutral-500">
                            {stats.avgSpeechClarityScore >= 80 ? "Excellent clarity" : 
                             stats.avgSpeechClarityScore >= 60 ? "Good clarity" : 
                             "Needs improvement"}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Achievement Summary */}
                    <div>
                      <h3 className="text-md font-medium mb-3">Achievement Summary</h3>
                      <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                              <Trophy className="h-4 w-4 text-primary" />
                            </div>
                            <span className="font-medium">Total Achievements</span>
                          </div>
                          <Badge className="bg-primary text-white">{stats.achievementCount}</Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <div className="text-sm text-neutral-500 mb-1">Current Level</div>
                            <div className="flex items-center">
                              <Badge className={getLevelColorClass(progress.level)}>Level {progress.level}</Badge>
                              <span className="ml-2">{formatLevelName(progress.level)}</span>
                            </div>
                          </div>
                          <div>
                            <div className="text-sm text-neutral-500 mb-1">Total Points</div>
                            <div className="font-bold">{progress.totalPoints} pts</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8">
                    <BarChart3 className="h-12 w-12 mx-auto mb-4 text-neutral-300" />
                    <h3 className="text-lg font-medium mb-2">No Statistics Available</h3>
                    <p className="text-neutral-500">
                      Create educational content to see your statistics
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}