import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Smile,
  Frown,
  Meh,
  AlertCircle,
  Zap,
  CheckCircle,
  BarChart3,
  Eye,
  TrendingUp
} from 'lucide-react';

// Define types for facial expression analysis
interface FacialExpressionData {
  joy: number;
  sorrow: number;
  anger: number;
  surprise: number;
  engagementScore: number;
}

interface EyeContactData {
  score: number;
  lookingAtCamera: boolean;
  confidence: number;
}

interface FacialAnalysisReportProps {
  facialExpressions: FacialExpressionData;
  eyeContact: EyeContactData;
  targetAudience?: 'beginner' | 'intermediate' | 'advanced';
  showRecommendations?: boolean;
}

export default function FacialExpressionReport({
  facialExpressions,
  eyeContact,
  targetAudience = 'intermediate',
  showRecommendations = true
}: FacialAnalysisReportProps) {
  const [activeTab, setActiveTab] = useState<string>('overview');

  // Helper function to get color class based on score
  const getScoreColorClass = (score: number) => {
    if (score >= 80) return 'bg-green-100 text-green-800';
    if (score >= 60) return 'bg-blue-100 text-blue-800';
    if (score >= 40) return 'bg-amber-100 text-amber-800';
    return 'bg-red-100 text-red-800';
  };

  // Helper to get emoji component based on score
  const getExpressionEmoji = (type: string, score: number) => {
    if (type === 'joy') {
      return score > 0.5 ? <Smile className="h-5 w-5 text-green-500" /> : <Meh className="h-5 w-5 text-neutral-500" />;
    }
    if (type === 'sorrow' || type === 'anger') {
      return score > 0.3 ? <Frown className="h-5 w-5 text-red-500" /> : <Meh className="h-5 w-5 text-neutral-500" />;
    }
    if (type === 'surprise') {
      return score > 0.4 ? <AlertCircle className="h-5 w-5 text-amber-500" /> : <Meh className="h-5 w-5 text-neutral-500" />;
    }
    return <Meh className="h-5 w-5 text-neutral-500" />;
  };

  // Generate recommendations based on analysis and audience
  const generateRecommendations = () => {
    const recs: Array<{
      title: string;
      description: string;
      icon: React.ReactNode;
      importance: 'high' | 'medium' | 'low';
    }> = [];

    // Eye contact recommendations
    if (eyeContact.score < 65) {
      recs.push({
        title: 'Improve Eye Contact',
        description: 'Try to look directly at the camera more consistently to increase viewer engagement.',
        icon: <Eye className="h-4 w-4" />,
        importance: 'high'
      });
    }

    // Facial expression recommendations
    if (facialExpressions.joy < 0.4) {
      recs.push({
        title: 'Show More Enthusiasm',
        description: `${targetAudience === 'beginner' ? 'Beginners especially respond well to enthusiastic presenters.' : 'Adding more positive expressions increases viewer retention.'}`,
        icon: <Smile className="h-4 w-4" />,
        importance: targetAudience === 'beginner' ? 'high' : 'medium'
      });
    }

    if (facialExpressions.surprise < 0.2) {
      recs.push({
        title: 'Add Dynamic Expressions',
        description: 'Varying your facial expressions makes the content more engaging.',
        icon: <Zap className="h-4 w-4" />,
        importance: 'medium'
      });
    }

    // Audience-specific recommendations
    if (targetAudience === 'beginner' && facialExpressions.engagementScore < 70) {
      recs.push({
        title: 'Increase Engagement for Beginners',
        description: 'Beginners need more visual cues and expressions to stay engaged with new concepts.',
        icon: <TrendingUp className="h-4 w-4" />,
        importance: 'high'
      });
    }

    if (targetAudience === 'advanced' && facialExpressions.joy > 0.7) {
      recs.push({
        title: 'Moderate Enthusiasm for Advanced Audience',
        description: 'Advanced audiences may prefer a more measured, professional delivery style.',
        icon: <BarChart3 className="h-4 w-4" />,
        importance: 'medium'
      });
    }

    return recs;
  };

  const recommendationsList = generateRecommendations();

  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center">
          <BarChart3 className="h-5 w-5 mr-2 text-primary" />
          Advanced Facial Expression Analysis
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-4 grid grid-cols-3">
            <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
            <TabsTrigger value="expressions" className="text-xs">Expressions</TabsTrigger>
            <TabsTrigger value="recommendations" className="text-xs">Recommendations</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Overall Engagement Score</span>
              <Badge className={getScoreColorClass(facialExpressions.engagementScore)}>
                {facialExpressions.engagementScore}%
              </Badge>
            </div>
            <Progress 
              value={facialExpressions.engagementScore}
              className="h-2 mb-3"
            />

            <div className="grid grid-cols-2 gap-3">
              {/* Eye Contact */}
              <div className="bg-white p-3 rounded-lg border border-neutral-100">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium flex items-center">
                    <Eye className="h-4 w-4 mr-1 text-blue-500" /> Eye Contact
                  </span>
                  <Badge className={getScoreColorClass(eyeContact.score)}>
                    {eyeContact.score}%
                  </Badge>
                </div>
                <div className="text-xs text-neutral-500 mt-1">
                  {eyeContact.score >= 80 ? 'Excellent camera engagement' : 
                   eyeContact.score >= 60 ? 'Good eye contact maintained' : 
                   'Could improve camera focus'}
                </div>
              </div>

              {/* Expression Balance */}
              <div className="bg-white p-3 rounded-lg border border-neutral-100">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium flex items-center">
                    <Smile className="h-4 w-4 mr-1 text-green-500" /> Expression Balance
                  </span>
                  <Badge className={getScoreColorClass(facialExpressions.joy * 80)}>
                    {Math.round(facialExpressions.joy * 100)}%
                  </Badge>
                </div>
                <div className="text-xs text-neutral-500 mt-1">
                  {facialExpressions.joy > 0.7 ? 'Very enthusiastic presentation' : 
                   facialExpressions.joy > 0.4 ? 'Good expression variety' : 
                   'Consider more expressive delivery'}
                </div>
              </div>
            </div>

            <div className="text-sm mt-4 text-neutral-700">
              <p>
                {eyeContact.score >= 70 && facialExpressions.joy >= 0.6 
                  ? 'Excellent presenter connection! Your facial expressions and eye contact create an engaging experience.'
                  : eyeContact.score >= 50 && facialExpressions.joy >= 0.4 
                    ? 'Good presenter presence with room for improvement in consistency and expressiveness.'
                    : 'Consider focusing on improving your camera engagement and expressiveness for better viewer connection.'}
              </p>
            </div>
          </TabsContent>

          {/* Expressions Tab */}
          <TabsContent value="expressions" className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Joy */}
              <div className="bg-white p-3 rounded-lg border border-neutral-100">
                <div className="flex items-center gap-2 mb-2">
                  {getExpressionEmoji('joy', facialExpressions.joy)}
                  <span className="text-sm font-medium">Joy/Enthusiasm</span>
                </div>
                <Progress 
                  value={facialExpressions.joy * 100}
                  className="h-2 mb-1"
                />
                <div className="text-xs text-neutral-500 mt-1">
                  {facialExpressions.joy > 0.7 ? 'Very enthusiastic delivery' : 
                   facialExpressions.joy > 0.4 ? 'Good level of enthusiasm' : 
                   'Consider showing more enthusiasm'}
                </div>
              </div>

              {/* Surprise */}
              <div className="bg-white p-3 rounded-lg border border-neutral-100">
                <div className="flex items-center gap-2 mb-2">
                  {getExpressionEmoji('surprise', facialExpressions.surprise)}
                  <span className="text-sm font-medium">Expressiveness/Surprise</span>
                </div>
                <Progress 
                  value={facialExpressions.surprise * 100}
                  className="h-2 mb-1"
                />
                <div className="text-xs text-neutral-500 mt-1">
                  {facialExpressions.surprise > 0.5 ? 'Highly dynamic expressions' : 
                   facialExpressions.surprise > 0.3 ? 'Good expression variation' : 
                   'Consider adding more expression dynamics'}
                </div>
              </div>

              {/* Negative Expressions */}
              <div className="bg-white p-3 rounded-lg border border-neutral-100">
                <div className="flex items-center gap-2 mb-2">
                  {getExpressionEmoji('sorrow', facialExpressions.sorrow)}
                  <span className="text-sm font-medium">Sorrow/Concern</span>
                </div>
                <Progress 
                  value={facialExpressions.sorrow * 100}
                  className="h-2 mb-1"
                />
                <div className="text-xs text-neutral-500 mt-1">
                  {facialExpressions.sorrow > 0.3 ? 'Consider more positive expressions' : 
                   'Good balance of expressions'}
                </div>
              </div>

              {/* Anger */}
              <div className="bg-white p-3 rounded-lg border border-neutral-100">
                <div className="flex items-center gap-2 mb-2">
                  {getExpressionEmoji('anger', facialExpressions.anger)}
                  <span className="text-sm font-medium">Tension/Frustration</span>
                </div>
                <Progress 
                  value={facialExpressions.anger * 100}
                  className="h-2 mb-1"
                />
                <div className="text-xs text-neutral-500 mt-1">
                  {facialExpressions.anger > 0.3 ? 'Consider a more relaxed delivery' : 
                   'Good relaxed presentation style'}
                </div>
              </div>
            </div>

            <div className="text-sm mt-2 text-neutral-700">
              <p>
                {facialExpressions.joy > 0.6 && facialExpressions.surprise > 0.4 
                  ? 'Your facial expressions show excellent engagement and variety, which keeps viewers interested.'
                  : facialExpressions.joy > 0.4 && facialExpressions.surprise > 0.2
                    ? 'Your facial expressions show good engagement with room for more variety and emphasis.'
                    : 'Consider enhancing your facial expressions to better engage viewers and emphasize key points.'}
              </p>
            </div>
          </TabsContent>

          {/* Recommendations Tab */}
          <TabsContent value="recommendations" className="space-y-2">
            {showRecommendations && recommendationsList && recommendationsList.length > 0 ? (
              <div className="space-y-3">
                {recommendationsList.map((rec: any, index: number) => (
                  <div key={index} className={`p-3 rounded-lg border ${rec.importance === 'high' ? 'bg-amber-50 border-amber-200' : 'bg-white border-neutral-100'}`}>
                    <div className="flex items-start gap-3">
                      <div className={`mt-0.5 flex-shrink-0 ${rec.importance === 'high' ? 'text-amber-500' : 'text-blue-500'}`}>
                        {rec.icon}
                      </div>
                      <div>
                        <h4 className="text-sm font-medium mb-1">{rec.title}</h4>
                        <p className="text-xs text-neutral-600">{rec.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <CheckCircle className="h-12 w-12 mx-auto mb-3 text-green-500" />
                <h3 className="text-lg font-medium mb-1">Great Performance!</h3>
                <p className="text-sm text-neutral-600">
                  Your facial expressions and eye contact are excellent for a {targetAudience} audience.
                </p>
              </div>
            )}

            <div className="text-sm mt-2 p-3 rounded-lg bg-blue-50 border border-blue-100">
              <h4 className="font-medium mb-1 flex items-center">
                <TrendingUp className="h-4 w-4 mr-1 text-blue-500" /> 
                Audience Insight
              </h4>
              <p className="text-xs text-neutral-700">
                {targetAudience === 'beginner' 
                  ? 'Beginner audiences respond best to enthusiastic expressions, clear eye contact, and encouraging facial cues that build confidence.'
                  : targetAudience === 'intermediate'
                    ? 'Intermediate audiences appreciate a balanced approach with good eye contact and expressions that emphasize key concepts.'
                    : 'Advanced audiences value a professional presentation style with strategic emphasis through expressions and consistent eye contact.'}
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}