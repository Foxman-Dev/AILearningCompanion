import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { 
  CalendarDays, 
  CheckCircle, 
  Info,
  Edit
} from "lucide-react";
import { cn } from "@/lib/utils";

interface ContentCardProps {
  id: string;
  title: string;
  type: 'video' | 'slideshow' | 'speech';
  lastEdited: string;
  complexityLevel: 'beginner' | 'intermediate' | 'advanced';
  complexityScore: number;
  optimized: boolean;
  imageUrl: string;
  editLink: string;
}

export default function ContentCard({
  id,
  title,
  type,
  lastEdited,
  complexityLevel,
  complexityScore,
  optimized,
  imageUrl,
  editLink
}: ContentCardProps) {
  const getTypeColor = () => {
    switch (type) {
      case 'video': return 'bg-primary';
      case 'slideshow': return 'bg-accent';
      case 'speech': return 'bg-secondary';
      default: return 'bg-primary';
    }
  };

  const getTypeLabel = () => {
    switch (type) {
      case 'video': return 'Video Course';
      case 'slideshow': return 'Slideshow';
      case 'speech': return 'Speech';
      default: return 'Content';
    }
  };

  const getComplexityColor = () => {
    if (complexityLevel === 'beginner') return 'bg-success';
    if (complexityLevel === 'intermediate') return 'bg-warning';
    return 'bg-error';
  };

  const getStatusDisplay = () => {
    if (optimized) {
      return (
        <div className="text-success flex items-center">
          <CheckCircle className="h-4 w-4 mr-1" />
          <span className="text-sm">AI optimized</span>
        </div>
      );
    }
    return (
      <div className="text-warning flex items-center">
        <Info className="h-4 w-4 mr-1" />
        <span className="text-sm">Needs simplification</span>
      </div>
    );
  };

  return (
    <Card className="overflow-hidden">
      <div className="relative h-40">
        <img 
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover"
        />
        <Badge className={cn("absolute top-2 right-2 text-white", getTypeColor())}>
          {getTypeLabel()}
        </Badge>
      </div>
      <div className="p-4">
        <h3 className="font-heading font-medium text-lg mb-2">{title}</h3>
        <div className="flex items-center text-sm text-neutral-300 mb-3">
          <CalendarDays className="h-4 w-4 mr-1" />
          <span>Last edited: {lastEdited}</span>
        </div>
        
        <div className="mb-3">
          <div className="flex justify-between text-sm mb-1">
            <span>Complexity Level</span>
            <span className="font-medium capitalize">{complexityLevel}</span>
          </div>
          <div className="knowledge-indicator h-3 rounded-full bg-neutral-200 overflow-hidden">
            <div 
              className={`h-full ${getComplexityColor()}`} 
              style={{ width: `${complexityScore * 100}%` }}
            ></div>
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          {getStatusDisplay()}
          <Link href={editLink}>
            <Button variant="ghost" size="icon" className="text-primary hover:text-primary-dark transition-colors">
              <Edit className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </Card>
  );
}
