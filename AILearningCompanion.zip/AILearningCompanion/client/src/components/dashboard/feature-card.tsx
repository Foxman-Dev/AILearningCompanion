import { Card, CardContent } from "@/components/ui/card";

interface FeatureCardProps {
  title: string;
  description: string;
  imageUrl: string;
  imageAlt: string;
}

export default function FeatureCard({
  title,
  description,
  imageUrl,
  imageAlt
}: FeatureCardProps) {
  return (
    <Card className="shadow-md">
      <CardContent className="p-6 text-center">
        <img 
          src={imageUrl} 
          alt={imageAlt} 
          className="w-full h-40 object-cover rounded-lg mb-4"
        />
        <h3 className="font-heading font-medium text-lg mb-2">{title}</h3>
        <p className="text-neutral-300 text-sm">{description}</p>
      </CardContent>
    </Card>
  );
}
