import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Plus,
  X,
  FileText,
  Image as ImageIcon,
  MoveUp,
  MoveDown,
  Sparkles,
  Loader2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

type LearningLevel = 'beginner' | 'intermediate' | 'advanced';

interface Slide {
  id: string;
  title: string;
  content: string;
  imageUrl?: string;
}

interface SlideshowCreatorProps {
  speechContent: string;
  learningLevel: LearningLevel;
  onContentChange: (content: string) => void;
}

export default function SlideshowCreator({
  speechContent,
  learningLevel,
  onContentChange
}: SlideshowCreatorProps) {
  const [slides, setSlides] = useState<Slide[]>([]);
  const [activeSlideIndex, setActiveSlideIndex] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  // Initialize slides from speech content when component mounts
  useEffect(() => {
    if (speechContent && slides.length === 0) {
      generateInitialSlides();
    }
  }, [speechContent]);

  // Generate markdown string from slides
  useEffect(() => {
    const markdown = slides.map(slide => {
      let slideContent = `# ${slide.title}\n\n${slide.content}`;
      if (slide.imageUrl) {
        slideContent += `\n\n![Slide image](${slide.imageUrl})`;
      }
      return slideContent;
    }).join('\n\n---\n\n');
    
    onContentChange(markdown);
  }, [slides, onContentChange]);

  // Generate initial slides from speech content
  const generateInitialSlides = async () => {
    if (!speechContent.trim()) {
      toast({
        title: "Cannot generate slides",
        description: "Please create speech content first.",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);

    try {
      // Start with a simple heuristic approach
      const sections = speechContent.split(/\n\s*\n/);
      
      // Extract headings and content
      const generatedSlides: Slide[] = [];
      let currentTitle = "Introduction";
      let currentContent = "";
      
      for (const section of sections) {
        // Check if this section starts with a heading
        const headingMatch = section.match(/^#+\s+(.+)$/m);
        
        if (headingMatch) {
          // If we already have content, save the previous slide
          if (currentContent) {
            generatedSlides.push({
              id: `slide-${generatedSlides.length}`,
              title: currentTitle,
              content: currentContent.trim()
            });
          }
          
          // Start a new slide
          currentTitle = headingMatch[1];
          currentContent = section.replace(/^#+\s+(.+)$/m, '');
        } else {
          // Add to current content
          currentContent += section + "\n\n";
        }
      }
      
      // Add the last slide
      if (currentContent) {
        generatedSlides.push({
          id: `slide-${generatedSlides.length}`,
          title: currentTitle,
          content: currentContent.trim()
        });
      }
      
      // If no slides were generated, create a default one
      if (generatedSlides.length === 0) {
        generatedSlides.push({
          id: "slide-0",
          title: "Introduction",
          content: speechContent
        });
      }
      
      setSlides(generatedSlides);
      
      // For real implementation, you would use AI here
      if (process.env.OPENAI_API_KEY) {
        try {
          const response = await apiRequest(
            'POST',
            '/api/generate-slides',
            {
              speechContent,
              knowledgeLevel: learningLevel
            }
          );
          
          const result = await response.json();
          if (result.slides && result.slides.length > 0) {
            setSlides(result.slides.map((slide: any, index: number) => ({
              id: `slide-${index}`,
              title: slide.title,
              content: slide.content,
              imageUrl: slide.imageUrl
            })));
          }
        } catch (error) {
          console.error("Error generating slides with AI:", error);
          // We'll keep the heuristic slides if AI fails
        }
      }
      
      toast({
        title: "Slides generated",
        description: `Created ${generatedSlides.length} slides from your speech content.`
      });
    } catch (error) {
      console.error("Error generating slides:", error);
      toast({
        title: "Generation failed",
        description: "There was an error generating slides from your speech.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  // Add a new slide
  const addSlide = () => {
    const newSlide: Slide = {
      id: `slide-${Date.now()}`,
      title: "New Slide",
      content: ""
    };
    
    const newSlides = [...slides];
    newSlides.splice(activeSlideIndex + 1, 0, newSlide);
    setSlides(newSlides);
    setActiveSlideIndex(activeSlideIndex + 1);
  };

  // Remove a slide
  const removeSlide = (index: number) => {
    if (slides.length <= 1) {
      toast({
        title: "Cannot remove slide",
        description: "You must have at least one slide.",
        variant: "destructive"
      });
      return;
    }
    
    const newSlides = slides.filter((_, i) => i !== index);
    setSlides(newSlides);
    
    // Adjust active slide index if needed
    if (index <= activeSlideIndex) {
      setActiveSlideIndex(Math.max(0, activeSlideIndex - 1));
    }
  };

  // Move slide up
  const moveSlideUp = (index: number) => {
    if (index === 0) return;
    
    const newSlides = [...slides];
    [newSlides[index - 1], newSlides[index]] = [newSlides[index], newSlides[index - 1]];
    setSlides(newSlides);
    setActiveSlideIndex(index - 1);
  };

  // Move slide down
  const moveSlideDown = (index: number) => {
    if (index === slides.length - 1) return;
    
    const newSlides = [...slides];
    [newSlides[index], newSlides[index + 1]] = [newSlides[index + 1], newSlides[index]];
    setSlides(newSlides);
    setActiveSlideIndex(index + 1);
  };

  // Update slide content
  const updateSlide = (index: number, field: keyof Slide, value: string) => {
    const newSlides = [...slides];
    newSlides[index] = { ...newSlides[index], [field]: value };
    setSlides(newSlides);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Slide list sidebar */}
      <div className="lg:col-span-1 bg-neutral-50 p-4 rounded-lg border border-neutral-200">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-medium">Slides</h3>
          <Button
            variant="outline"
            size="sm"
            className="h-8 px-2"
            onClick={addSlide}
          >
            <Plus className="h-4 w-4 mr-1" /> Add Slide
          </Button>
        </div>
        
        {isGenerating ? (
          <div className="flex flex-col items-center justify-center py-10">
            <Loader2 className="h-10 w-10 text-primary animate-spin mb-4" />
            <p className="text-neutral-600">Generating slides from your speech...</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
            {slides.map((slide, index) => (
              <div 
                key={slide.id}
                className={`p-3 rounded-md cursor-pointer flex justify-between group ${
                  index === activeSlideIndex 
                    ? 'bg-primary text-white' 
                    : 'bg-white hover:bg-neutral-100'
                }`}
                onClick={() => setActiveSlideIndex(index)}
              >
                <div className="truncate">
                  <span className="text-xs opacity-70">#{index + 1}</span>
                  <p className="font-medium truncate">{slide.title}</p>
                </div>
                <div className={`hidden group-hover:flex items-center space-x-1 ${
                  index === activeSlideIndex ? 'text-white' : 'text-neutral-400'
                }`}>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={(e) => {
                      e.stopPropagation();
                      moveSlideUp(index);
                    }}
                    disabled={index === 0}
                  >
                    <MoveUp className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={(e) => {
                      e.stopPropagation();
                      moveSlideDown(index);
                    }}
                    disabled={index === slides.length - 1}
                  >
                    <MoveDown className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={(e) => {
                      e.stopPropagation();
                      removeSlide(index);
                    }}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {slides.length === 0 && !isGenerating && (
          <div className="text-center py-10">
            <FileText className="h-10 w-10 text-neutral-300 mx-auto mb-2" />
            <p className="text-neutral-400">No slides yet</p>
            <Button
              variant="outline"
              className="mt-4"
              onClick={generateInitialSlides}
            >
              <Sparkles className="h-4 w-4 mr-2" /> Generate from Speech
            </Button>
          </div>
        )}
      </div>

      {/* Slide editor */}
      <div className="lg:col-span-2">
        {slides.length > 0 && activeSlideIndex < slides.length ? (
          <div>
            <div className="bg-white p-6 rounded-lg border border-neutral-200 mb-4">
              <div className="mb-4">
                <label className="block text-sm font-medium text-neutral-600 mb-1">
                  Slide Title
                </label>
                <Input 
                  value={slides[activeSlideIndex].title}
                  onChange={(e) => updateSlide(activeSlideIndex, 'title', e.target.value)}
                  className="w-full"
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-neutral-600 mb-1">
                  Slide Content
                </label>
                <Textarea 
                  value={slides[activeSlideIndex].content}
                  onChange={(e) => updateSlide(activeSlideIndex, 'content', e.target.value)}
                  className="w-full min-h-[200px]"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-neutral-600 mb-1">
                  Image URL (optional)
                </label>
                <div className="flex">
                  <Input 
                    value={slides[activeSlideIndex].imageUrl || ''}
                    onChange={(e) => updateSlide(activeSlideIndex, 'imageUrl', e.target.value)}
                    className="w-full"
                    placeholder="https://example.com/image.jpg"
                  />
                  <Button 
                    variant="ghost"
                    className="ml-2"
                    onClick={() => updateSlide(activeSlideIndex, 'imageUrl', '')}
                    disabled={!slides[activeSlideIndex].imageUrl}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Slide preview */}
            <div className="border border-neutral-200 rounded-lg overflow-hidden">
              <div className="bg-neutral-100 px-3 py-2 border-b border-neutral-200 text-sm font-medium text-neutral-500">
                Slide Preview
              </div>
              <div className="bg-white p-6 flex flex-col items-center">
                <h2 className="text-2xl font-bold mb-4">{slides[activeSlideIndex].title}</h2>
                <div className="text-neutral-600 mb-4 max-w-lg text-center whitespace-pre-line">
                  {slides[activeSlideIndex].content}
                </div>
                {slides[activeSlideIndex].imageUrl && (
                  <img 
                    src={slides[activeSlideIndex].imageUrl} 
                    alt={slides[activeSlideIndex].title}
                    className="max-w-md max-h-[200px] object-contain mt-4 border border-neutral-200 rounded"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = 'https://via.placeholder.com/400x200?text=Image+Not+Found';
                    }}
                  />
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white p-8 rounded-lg border border-neutral-200 text-center">
            {isGenerating ? (
              <div className="flex flex-col items-center justify-center py-10">
                <Loader2 className="h-10 w-10 text-primary animate-spin mb-4" />
                <p className="text-neutral-600">Generating slides from your speech...</p>
              </div>
            ) : (
              <>
                <ImageIcon className="h-16 w-16 text-neutral-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-neutral-600 mb-2">No Slide Selected</h3>
                <p className="text-neutral-400 mb-6">Select a slide from the sidebar or create a new one.</p>
                <Button 
                  onClick={addSlide}
                  className="bg-primary text-white"
                >
                  <Plus className="h-4 w-4 mr-2" /> Create First Slide
                </Button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}