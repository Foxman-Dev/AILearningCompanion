import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import Webcam from "react-webcam";
import * as tf from "@tensorflow/tfjs";
import * as faceLandmarksDetection from "@tensorflow-models/face-landmarks-detection";
import {
  Video,
  Mic2,
  Play,
  Pause,
  StopCircle,
  Camera,
  Eye,
  AlertTriangle,
  Volume2,
  RefreshCw,
  Layers,
  MessageSquare,
  FileText,
  CheckCircle,
  Upload,
  Timer,
  Smile,
  Maximize2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import VideoPreviewAnalyzer from "./video-preview-analyzer";

type LearningLevel = 'beginner' | 'intermediate' | 'advanced';

interface EnhancedVideoCreatorProps {
  speechContent: string;
  slideshowContent: string;
  learningLevel: LearningLevel;
  onRecordingComplete: (eyeContactScore: number, speechClarityScore: number) => void;
}

export default function EnhancedVideoCreator({
  speechContent,
  slideshowContent,
  learningLevel,
  onRecordingComplete
}: EnhancedVideoCreatorProps) {
  const [activeTab, setActiveTab] = useState<string>("setup");
  
  // Video recording state
  const webcamRef = useRef<Webcam>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [recordedChunks, setRecordedChunks] = useState<Blob[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [uploadedVideoUrl, setUploadedVideoUrl] = useState<string | null>(null);
  
  // Face detection state
  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");
  const [detector, setDetector] = useState<any>(null);
  const [isModelLoading, setIsModelLoading] = useState(true);
  const [isFaceDetected, setIsFaceDetected] = useState(false);
  const requestAnimationRef = useRef<number>();
  
  // Metrics state
  const [eyeContactMetrics, setEyeContactMetrics] = useState<number[]>([]);
  const [eyeContactScore, setEyeContactScore] = useState(0);
  const [speechClarityScore, setSpeechClarityScore] = useState(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisComplete, setAnalysisComplete] = useState(false);
  
  // Slides state
  const [currentSlide, setCurrentSlide] = useState(0);
  const [slides, setSlides] = useState<string[]>([]);
  const [scriptVisible, setScriptVisible] = useState(true);
  
  // Preview mode state
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  
  // Tutorial-specific metrics
  const [tutorialMetrics, setTutorialMetrics] = useState({
    pacing: 0.7,             // Speaking pace
    enthusiasm: 0.5,         // Vocal enthusiasm
    facialExpressions: 0.6,  // Appropriate facial expressions
    slideAlignment: 0.6,     // Alignment with slide content
    overall: 0               // Overall score (calculated later)
  });
  
  const { toast } = useToast();

  // Parse slides from slideshow content
  useEffect(() => {
    if (slideshowContent) {
      const parsedSlides = slideshowContent.split('---').map(slide => slide.trim());
      setSlides(parsedSlides);
    }
  }, [slideshowContent]);

  // Load TensorFlow.js and face landmarks model
  useEffect(() => {
    async function loadModel() {
      try {
        // Make sure TensorFlow.js is initialized
        await tf.ready();
        
        // Load the face landmarks detection model
        const model = faceLandmarksDetection.SupportedModels.MediaPipeFaceMesh;
        const detectorConfig = {
          runtime: 'mediapipe',
          solutionPath: 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh',
          maxFaces: 1
        };
        
        const faceDetector = await faceLandmarksDetection.createDetector(
          model, 
          detectorConfig as any
        );
        
        setDetector(faceDetector);
        setIsModelLoading(false);
        
        toast({
          title: "Face detection initialized",
          description: "Eye contact tracking is now active."
        });
      } catch (error) {
        console.error("Error loading facial recognition model:", error);
        toast({
          title: "Face detection failed",
          description: "Could not initialize eye contact tracking.",
          variant: "destructive"
        });
        setIsModelLoading(false);
      }
    }
    
    loadModel();
    
    return () => {
      if (requestAnimationRef.current) {
        cancelAnimationFrame(requestAnimationRef.current);
      }
    };
  }, [toast]);

  // Clean up URL objects on unmount
  useEffect(() => {
    return () => {
      if (videoUrl) {
        URL.revokeObjectURL(videoUrl);
      }
      if (uploadedVideoUrl) {
        URL.revokeObjectURL(uploadedVideoUrl);
      }
    };
  }, [videoUrl, uploadedVideoUrl]);

  // Track recording time
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRecording && !isPaused) {
      interval = setInterval(() => {
        setRecordingTime((prevTime) => prevTime + 1);
      }, 1000);
    }
    
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isRecording, isPaused]);

  // Format seconds to mm:ss
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // Detect eye contact
  const detectEyeContact = useCallback(async () => {
    if (!detector || !webcamRef.current || !webcamRef.current.video || !isRecording) return;
    
    const video = webcamRef.current.video;
    
    if (video.readyState === 4) {
      try {
        // Get face landmarks
        const faces = await detector.estimateFaces(video);
        
        if (faces && faces.length > 0) {
          setIsFaceDetected(true);
          
          // Extract eye landmarks
          const face = faces[0];
          const leftEye = face.keypoints.filter((kp: any) => kp.name && kp.name.includes('leftEye'));
          const rightEye = face.keypoints.filter((kp: any) => kp.name && kp.name.includes('rightEye'));
          
          // Calculate eye attention metrics (simplified)
          const eyeOpenness = calculateEyeOpenness(leftEye, rightEye);
          const lookingAtCamera = isLookingAtCamera(face);
          
          // Score from 0-1, where 1 is perfect eye contact
          let contactScore = eyeOpenness * 0.5 + (lookingAtCamera ? 0.5 : 0);
          
          // Add to metrics array
          setEyeContactMetrics(prevMetrics => {
            const newMetrics = [...prevMetrics, contactScore];
            // Only keep last 30 frames for real-time display
            if (newMetrics.length > 30) {
              return newMetrics.slice(newMetrics.length - 30);
            }
            return newMetrics;
          });
          
          // Update overall score (average of all metrics)
          if (eyeContactMetrics.length > 0) {
            const averageScore = eyeContactMetrics.reduce((sum, score) => sum + score, 0) / eyeContactMetrics.length;
            setEyeContactScore(averageScore);
          }
          
          // Update tutorial-specific metrics
          const expressiveness = Math.random() * 0.3 + 0.5; // Random value between 0.5 and 0.8 for facial expressions
          
          setTutorialMetrics(prev => ({
            ...prev,
            facialExpressions: (prev.facialExpressions * 0.95) + (expressiveness * 0.05),
            enthusiasm: lookingAtCamera ? 
              Math.min(0.9, prev.enthusiasm + 0.01) : 
              Math.max(0.3, prev.enthusiasm - 0.01)
          }));
        } else {
          setIsFaceDetected(false);
        }
      } catch (error) {
        console.error("Error detecting face:", error);
      }
    }
    
    // Continue detection loop
    requestAnimationRef.current = requestAnimationFrame(detectEyeContact);
  }, [detector, isRecording, eyeContactMetrics]);

  // Start eye contact detection when recording
  useEffect(() => {
    if (isRecording && detector && !isPaused) {
      detectEyeContact();
    } else if (requestAnimationRef.current) {
      cancelAnimationFrame(requestAnimationRef.current);
    }
    
    return () => {
      if (requestAnimationRef.current) {
        cancelAnimationFrame(requestAnimationRef.current);
      }
    };
  }, [isRecording, detector, isPaused, detectEyeContact]);

  // Calculate eye openness (simplified)
  const calculateEyeOpenness = (leftEye: any[], rightEye: any[]) => {
    // This is a simplified measure - in production you'd use proper measurements
    // between upper and lower eyelids
    return leftEye.length > 0 && rightEye.length > 0 ? 0.8 : 0.3;
  };

  // Check if looking at camera (simplified)
  const isLookingAtCamera = (face: any) => {
    // In production, you would calculate where the eyes are looking based on
    // the position of the iris relative to the eye corners
    const rotation = face.box.yaw || 0;
    // Consider "looking at camera" if face rotation is minimal
    return Math.abs(rotation) < 0.3;
  };

  // Handle recording actions
  const handleStartRecording = useCallback(() => {
    if (!webcamRef.current || !webcamRef.current.video) return;
    
    setRecordedChunks([]);
    setRecordingTime(0);
    setEyeContactMetrics([]);
    
    const stream = webcamRef.current.video.srcObject as MediaStream;
    const mediaRecorder = new MediaRecorder(stream, {
      mimeType: "video/webm",
    });
    
    mediaRecorder.addEventListener("dataavailable", ({ data }) => {
      if (data.size > 0) {
        setRecordedChunks((prev) => [...prev, data]);
      }
    });
    
    mediaRecorderRef.current = mediaRecorder;
    mediaRecorder.start();
    setIsRecording(true);
    setIsPaused(false);
    
    // Reset tutorial metrics
    setTutorialMetrics({
      pacing: 0.7,
      enthusiasm: 0.5,
      facialExpressions: 0.6,
      slideAlignment: 0.6,
      overall: 0
    });
  }, []);

  const handleStopRecording = useCallback(() => {
    if (!mediaRecorderRef.current) return;
    
    mediaRecorderRef.current.stop();
    setIsRecording(false);
    setIsPaused(false);
    
    // Cancel the animation frame to stop face detection
    if (requestAnimationRef.current) {
      cancelAnimationFrame(requestAnimationRef.current);
    }
    
    setTimeout(() => {
      if (recordedChunks.length) {
        const blob = new Blob(recordedChunks, {
          type: "video/webm",
        });
        setVideoUrl(URL.createObjectURL(blob));
        setActiveTab("review");
        
        // Set a sample speech clarity score (in real implementation, this would be analyzed)
        const sampleSpeechClarity = 0.75 + (Math.random() * 0.2 - 0.1); // Random value between 0.65 and 0.85
        setSpeechClarityScore(sampleSpeechClarity);
        
        // Calculate overall tutorial metric
        const overall = (
          eyeContactScore * 0.3 +
          tutorialMetrics.facialExpressions * 0.2 +
          tutorialMetrics.enthusiasm * 0.2 +
          tutorialMetrics.pacing * 0.15 +
          tutorialMetrics.slideAlignment * 0.15
        );
        
        setTutorialMetrics(prev => ({
          ...prev,
          overall
        }));
      }
    }, 1000);
  }, [recordedChunks, eyeContactScore, tutorialMetrics]);

  const handlePauseResumeRecording = useCallback(() => {
    if (!mediaRecorderRef.current) return;
    
    if (isPaused) {
      // Resume recording
      mediaRecorderRef.current.resume();
      setIsPaused(false);
    } else {
      // Pause recording
      mediaRecorderRef.current.pause();
      setIsPaused(true);
    }
  }, [isPaused]);

  const handleSwitchCamera = useCallback(() => {
    setFacingMode((prevMode) => 
      prevMode === "user" ? "environment" : "user"
    );
  }, []);

  // Handle file upload
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    // Check if file is a video
    if (!file.type.startsWith('video/')) {
      toast({
        title: "Invalid file type",
        description: "Please upload a video file.",
        variant: "destructive"
      });
      return;
    }
    
    // Create URL for the uploaded video
    const fileUrl = URL.createObjectURL(file);
    setUploadedVideoUrl(fileUrl);
    
    // Reset previous URL if exists
    if (videoUrl) {
      URL.revokeObjectURL(videoUrl);
      setVideoUrl(null);
    }
    
    // Initialize metrics
    setEyeContactScore(0.65 + (Math.random() * 0.3)); // Simulate score between 0.65-0.95
    setSpeechClarityScore(0.6 + (Math.random() * 0.3)); // Simulate score between 0.6-0.9
    
    // Set tutorial metrics
    setTutorialMetrics({
      pacing: 0.6 + (Math.random() * 0.3),
      enthusiasm: 0.55 + (Math.random() * 0.3),
      facialExpressions: 0.5 + (Math.random() * 0.4),
      slideAlignment: 0.65 + (Math.random() * 0.25),
      overall: 0.6 + (Math.random() * 0.3)
    });
    
    // Switch to analysis tab
    setActiveTab("review");
    toast({
      title: "Video uploaded",
      description: "Your video is ready for analysis."
    });
  };

  // Analyze video recording
  const analyzeVideoContent = async () => {
    if (!videoUrl && !uploadedVideoUrl) return;
    
    setIsAnalyzing(true);
    
    try {
      // In a real implementation, you would upload the video to the server
      // and perform speech-to-text analysis, etc.
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Call parent callback with the metrics
      onRecordingComplete(eyeContactScore, speechClarityScore);
      
      toast({
        title: "Analysis complete",
        description: `Your tutorial video scored ${Math.round(tutorialMetrics.overall * 100)}%. View detailed feedback below.`
      });
      
      setAnalysisComplete(true);
    } catch (error) {
      console.error("Error analyzing video:", error);
      toast({
        title: "Analysis failed",
        description: "There was an error analyzing your video.",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Enter preview mode
  const enterPreviewMode = () => {
    setIsPreviewMode(true);
  };

  // Exit preview mode
  const exitPreviewMode = () => {
    setIsPreviewMode(false);
  };

  // Get eye contact level classification
  const getEyeContactLevel = () => {
    if (eyeContactScore >= 0.8) return "Excellent";
    if (eyeContactScore >= 0.6) return "Good";
    if (eyeContactScore >= 0.4) return "Fair";
    return "Needs Improvement";
  };

  // Get speech clarity level classification
  const getSpeechClarityLevel = () => {
    if (speechClarityScore >= 0.8) return "Excellent";
    if (speechClarityScore >= 0.6) return "Good";
    if (speechClarityScore >= 0.4) return "Fair";
    return "Needs Improvement";
  };

  // Get color class based on score
  const getScoreColorClass = (score: number) => {
    if (score >= 0.8) return "bg-success text-white";
    if (score >= 0.6) return "bg-primary text-white";
    if (score >= 0.4) return "bg-warning text-white";
    return "bg-error text-white";
  };

  // Get score rating
  const getScoreRating = (score: number) => {
    if (score >= 0.8) return "Excellent";
    if (score >= 0.6) return "Good";
    if (score >= 0.4) return "Fair";
    return "Needs Improvement";
  };

  // Navigate through slides
  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  // Parse current slide to extract title and content
  const parseCurrentSlide = () => {
    if (!slides[currentSlide]) return { title: "No slide content", content: "", imageUrl: "" };
    
    const slideContent = slides[currentSlide];
    const titleMatch = slideContent.match(/^#\s+(.+)$/m);
    const title = titleMatch ? titleMatch[1] : "Untitled Slide";
    
    // Extract image if exists
    const imageMatch = slideContent.match(/!\[.*?\]\((.*?)\)/);
    const imageUrl = imageMatch ? imageMatch[1] : "";
    
    // Remove title and image from content
    let content = slideContent
      .replace(/^#\s+(.+)$/m, '')
      .replace(/!\[.*?\]\((.*?)\)/g, '')
      .trim();
    
    return { title, content, imageUrl };
  };

  const currentSlideData = parseCurrentSlide();

  return (
    <div>
      {isPreviewMode && (videoUrl || uploadedVideoUrl) ? (
        <VideoPreviewAnalyzer 
          videoUrl={videoUrl || uploadedVideoUrl || ""}
          onClose={exitPreviewMode}
          learningLevel={learningLevel}
        />
      ) : (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full grid grid-cols-3 mb-6">
            <TabsTrigger value="setup" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              Setup
            </TabsTrigger>
            <TabsTrigger value="record" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              Record
            </TabsTrigger>
            <TabsTrigger value="review" className="data-[state=active]:bg-primary data-[state=active]:text-white" disabled={!videoUrl && !uploadedVideoUrl}>
              Review
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="setup">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4 flex items-center">
                    <Layers className="mr-2 h-5 w-5 text-primary" /> Slideshow Preview
                  </h3>
                  
                  {slides.length > 0 ? (
                    <div>
                      <div className="border border-neutral-200 rounded-lg p-4 mb-4 bg-white min-h-[250px] flex flex-col items-center justify-center">
                        <h2 className="text-xl font-bold mb-4">{currentSlideData.title}</h2>
                        <div className="text-neutral-600 whitespace-pre-line text-center mb-4">
                          {currentSlideData.content}
                        </div>
                        {currentSlideData.imageUrl && (
                          <img 
                            src={currentSlideData.imageUrl} 
                            alt="Slide illustration"
                            className="max-w-full max-h-[150px] object-contain mt-2" 
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src = 'https://via.placeholder.com/400x200?text=Image+Not+Found';
                            }}
                          />
                        )}
                      </div>
                      
                      <div className="flex justify-between">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={prevSlide}
                          disabled={currentSlide === 0}
                        >
                          Previous
                        </Button>
                        <span className="text-sm text-neutral-500">
                          Slide {currentSlide + 1} of {slides.length}
                        </span>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={nextSlide}
                          disabled={currentSlide === slides.length - 1}
                        >
                          Next
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center p-8 border border-dashed border-neutral-200 rounded-lg">
                      <Layers className="h-12 w-12 text-neutral-300 mx-auto mb-4" />
                      <p className="text-neutral-400">No slides available</p>
                      <p className="text-neutral-300 text-sm mt-2">
                        Create slides in the previous step
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4 flex items-center">
                    <MessageSquare className="mr-2 h-5 w-5 text-primary" /> Script Preview
                  </h3>
                  
                  <div className="border border-neutral-200 rounded-lg p-4 overflow-y-auto max-h-[300px] bg-white">
                    <div className="whitespace-pre-line text-neutral-600">
                      {speechContent || "No speech content available."}
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="text-lg font-medium mb-4 flex items-center">
                      <Video className="mr-2 h-5 w-5 text-primary" /> Record or Upload
                    </h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button 
                        className="bg-primary text-white"
                        onClick={() => setActiveTab("record")}
                      >
                        <Video className="mr-2 h-4 w-4" /> Record New Video
                      </Button>
                      
                      <div className="relative">
                        <input
                          type="file"
                          accept="video/*"
                          onChange={handleFileUpload}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        />
                        <Button 
                          variant="outline" 
                          className="w-full"
                        >
                          <Upload className="mr-2 h-4 w-4" /> Upload Video
                        </Button>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <h4 className="text-sm font-medium mb-2">Tutorial Video Tips</h4>
                      <ul className="list-disc list-inside space-y-2 text-neutral-600 text-xs">
                        <li>Look directly at the camera to maintain eye contact</li>
                        <li>Speak at a consistent, moderate pace</li>
                        <li>Use appropriate facial expressions to engage viewers</li>
                        <li>Reference your slides at the right moments</li>
                        <li>Incorporate hand gestures when appropriate</li>
                        <li>Aim for clear articulation and pronunciation</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="record">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <Card>
                  <CardContent className="p-6">
                    <div className="mb-4 relative">
                      <Webcam
                        audio={true}
                        ref={webcamRef}
                        videoConstraints={{
                          facingMode,
                          width: 640,
                          height: 480,
                        }}
                        className="w-full rounded-lg"
                      />
                      
                      {isModelLoading && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-60 rounded-lg">
                          <div className="text-center text-white p-4">
                            <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-2" />
                            <p>Loading face detection model...</p>
                          </div>
                        </div>
                      )}
                      
                      {isRecording && !isFaceDetected && (
                        <div className="absolute top-2 right-2">
                          <Badge variant="destructive" className="flex items-center">
                            <AlertTriangle className="mr-1 h-4 w-4" />
                            Face not detected
                          </Badge>
                        </div>
                      )}
                      
                      {isRecording && isFaceDetected && (
                        <div className="absolute top-2 right-2">
                          <Badge className="bg-success text-white flex items-center">
                            <Eye className="mr-1 h-4 w-4" />
                            Eye contact: {Math.round(eyeContactScore * 100)}%
                          </Badge>
                        </div>
                      )}
                      
                      {/* Recording indicator */}
                      {isRecording && (
                        <div className="absolute top-2 left-2 flex items-center">
                          <div className={`h-3 w-3 rounded-full ${isPaused ? 'bg-warning' : 'bg-error animate-pulse'} mr-2`}></div>
                          <span className="text-sm font-medium text-white bg-black bg-opacity-50 px-2 py-1 rounded">
                            {formatTime(recordingTime)}
                          </span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex flex-col space-y-3">
                      {/* Eye contact indicator */}
                      {isRecording && (
                        <div className="w-full">
                          <div className="flex justify-between text-sm mb-1">
                            <span>Eye Contact Quality</span>
                            <span>{Math.round(eyeContactScore * 100)}%</span>
                          </div>
                          <Progress value={eyeContactScore * 100} className="h-2" />
                        </div>
                      )}
                      
                      <div className="flex justify-between">
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={handleSwitchCamera}
                          disabled={isRecording}
                        >
                          <Camera className="h-4 w-4" />
                        </Button>
                        
                        {!isRecording ? (
                          <Button 
                            variant="default" 
                            className="bg-primary text-white px-4"
                            onClick={handleStartRecording}
                            disabled={isModelLoading}
                          >
                            <Video className="mr-2 h-4 w-4" /> 
                            Start Recording
                          </Button>
                        ) : (
                          <div className="space-x-2">
                            <Button 
                              variant={isPaused ? "default" : "outline"} 
                              size="icon"
                              onClick={handlePauseResumeRecording}
                            >
                              {isPaused ? (
                                <Play className="h-4 w-4" />
                              ) : (
                                <Pause className="h-4 w-4" />
                              )}
                            </Button>
                            
                            <Button 
                              variant="destructive" 
                              onClick={handleStopRecording}
                            >
                              <StopCircle className="mr-2 h-4 w-4" />
                              Stop
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-medium">Reference</h3>
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-xs px-2 h-7"
                          onClick={() => setScriptVisible(!scriptVisible)}
                        >
                          {scriptVisible ? "Hide Script" : "Show Script"}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="border border-neutral-200 rounded-lg p-3 mb-4 bg-white min-h-[150px] flex flex-col items-center justify-center">
                      <h3 className="text-lg font-bold mb-2">{currentSlideData.title}</h3>
                      <p className="text-sm text-neutral-500 text-center">
                        {currentSlideData.content.length > 100 
                          ? `${currentSlideData.content.substring(0, 100)}...` 
                          : currentSlideData.content}
                      </p>
                      {currentSlideData.imageUrl && (
                        <img 
                          src={currentSlideData.imageUrl} 
                          alt="Slide illustration"
                          className="max-w-full max-h-[100px] object-contain mt-2" 
                        />
                      )}
                    </div>
                    
                    <div className="flex justify-between mb-4">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={prevSlide}
                        disabled={currentSlide === 0}
                        className="text-xs px-2 h-7"
                      >
                        Previous
                      </Button>
                      <span className="text-xs text-neutral-500">
                        Slide {currentSlide + 1} of {slides.length}
                      </span>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={nextSlide}
                        disabled={currentSlide === slides.length - 1}
                        className="text-xs px-2 h-7"
                      >
                        Next
                      </Button>
                    </div>
                    
                    {scriptVisible && (
                      <div>
                        <div className="flex items-center mb-2">
                          <FileText className="h-4 w-4 mr-1 text-primary" />
                          <h4 className="text-sm font-medium">Script</h4>
                        </div>
                        <div className="border border-neutral-200 rounded-lg p-3 bg-neutral-50 max-h-[200px] overflow-y-auto">
                          <p className="text-xs text-neutral-600 whitespace-pre-line">
                            {speechContent}
                          </p>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="review">
            {(videoUrl || uploadedVideoUrl) && (
              <div className="space-y-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
                      <h3 className="text-lg font-medium mb-2 md:mb-0">Video Preview & Analysis</h3>
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          className="flex items-center"
                          onClick={enterPreviewMode}
                        >
                          <Maximize2 className="mr-2 h-4 w-4" /> Preview with Analysis
                        </Button>
                        
                        <div className="relative">
                          <input
                            type="file"
                            accept="video/*"
                            onChange={handleFileUpload}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                          />
                          <Button variant="outline" className="flex items-center">
                            <Upload className="mr-2 h-4 w-4" /> Upload Different Video
                          </Button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <video 
                        src={videoUrl || uploadedVideoUrl || undefined} 
                        controls 
                        className="w-full rounded-lg"
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                      <div>
                        <h4 className="text-sm font-medium mb-2 flex items-center">
                          <Eye className="h-4 w-4 mr-1 text-primary" /> Eye Contact
                        </h4>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-neutral-500">Quality</span>
                          <Badge className={getScoreColorClass(eyeContactScore)}>
                            {getEyeContactLevel()}
                          </Badge>
                        </div>
                        <Progress value={eyeContactScore * 100} className="h-2 mb-3" />
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium mb-2 flex items-center">
                          <Volume2 className="h-4 w-4 mr-1 text-primary" /> Speech Clarity
                        </h4>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-neutral-500">Quality</span>
                          <Badge className={getScoreColorClass(speechClarityScore)}>
                            {getSpeechClarityLevel()}
                          </Badge>
                        </div>
                        <Progress value={speechClarityScore * 100} className="h-2 mb-3" />
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium mb-2 flex items-center">
                          <Smile className="h-4 w-4 mr-1 text-primary" /> Expressions
                        </h4>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-neutral-500">Engagement</span>
                          <Badge className={getScoreColorClass(tutorialMetrics.facialExpressions)}>
                            {getScoreRating(tutorialMetrics.facialExpressions)}
                          </Badge>
                        </div>
                        <Progress value={tutorialMetrics.facialExpressions * 100} className="h-2 mb-3" />
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium mb-2 flex items-center">
                          <Timer className="h-4 w-4 mr-1 text-primary" /> Pacing
                        </h4>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-neutral-500">Consistency</span>
                          <Badge className={getScoreColorClass(tutorialMetrics.pacing)}>
                            {getScoreRating(tutorialMetrics.pacing)}
                          </Badge>
                        </div>
                        <Progress value={tutorialMetrics.pacing * 100} className="h-2 mb-3" />
                      </div>
                    </div>
                    
                    <Button 
                      className="w-full bg-primary text-white"
                      onClick={analyzeVideoContent}
                      disabled={isAnalyzing || analysisComplete}
                    >
                      {isAnalyzing ? (
                        <>
                          <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Analyzing...
                        </>
                      ) : analysisComplete ? (
                        <>
                          <CheckCircle className="mr-2 h-4 w-4" /> Analysis Complete
                        </>
                      ) : (
                        <>
                          <Video className="mr-2 h-4 w-4" /> Analyze Tutorial Quality
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
                
                {analysisComplete && (
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-lg font-medium mb-6 flex items-center">
                        <Video className="mr-2 h-5 w-5 text-primary" /> Tutorial Video Analysis
                      </h3>
                      
                      <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                          <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                            <div className="flex items-center mb-2">
                              <Timer className="h-4 w-4 mr-2 text-primary" />
                              <h4 className="font-medium">Pacing</h4>
                            </div>
                            <div className="text-2xl font-bold text-neutral-800 mb-1">
                              {Math.round(tutorialMetrics.pacing * 100)}%
                            </div>
                            <p className="text-xs text-neutral-500">
                              {tutorialMetrics.pacing >= 0.8 ? 
                                "Excellent pace that maintains viewer attention" : 
                                tutorialMetrics.pacing >= 0.6 ?
                                "Good pace with minor inconsistencies" :
                                "Work on maintaining consistent speaking pace"}
                            </p>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                            <div className="flex items-center mb-2">
                              <Smile className="h-4 w-4 mr-2 text-primary" />
                              <h4 className="font-medium">Enthusiasm</h4>
                            </div>
                            <div className="text-2xl font-bold text-neutral-800 mb-1">
                              {Math.round(tutorialMetrics.enthusiasm * 100)}%
                            </div>
                            <p className="text-xs text-neutral-500">
                              {tutorialMetrics.enthusiasm >= 0.8 ? 
                                "Your energy effectively engages viewers" : 
                                tutorialMetrics.enthusiasm >= 0.6 ?
                                "Good energy with room to show more enthusiasm" :
                                "Try to convey more excitement about your topic"}
                            </p>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                            <div className="flex items-center mb-2">
                              <Eye className="h-4 w-4 mr-2 text-primary" />
                              <h4 className="font-medium">Eye Contact</h4>
                            </div>
                            <div className="text-2xl font-bold text-neutral-800 mb-1">
                              {Math.round(eyeContactScore * 100)}%
                            </div>
                            <p className="text-xs text-neutral-500">
                              {eyeContactScore >= 0.8 ? 
                                "Excellent connection with viewers through eye contact" : 
                                eyeContactScore >= 0.6 ?
                                "Good eye contact with occasional breaks" :
                                "Work on looking more consistently at the camera"}
                            </p>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                            <div className="flex items-center mb-2">
                              <Layers className="h-4 w-4 mr-2 text-primary" />
                              <h4 className="font-medium">Slide Integration</h4>
                            </div>
                            <div className="text-2xl font-bold text-neutral-800 mb-1">
                              {Math.round(tutorialMetrics.slideAlignment * 100)}%
                            </div>
                            <p className="text-xs text-neutral-500">
                              {tutorialMetrics.slideAlignment >= 0.8 ? 
                                "Excellent alignment between speech and visuals" : 
                                tutorialMetrics.slideAlignment >= 0.6 ?
                                "Good use of slides with your presentation" :
                                "Better coordinate your speech with your slides"}
                            </p>
                          </div>
                        </div>
                        
                        <div className="border-t pt-6 mt-6">
                          <h4 className="font-medium mb-4">Tutorial Quality Assessment</h4>
                          
                          <div className="space-y-4">
                            <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                              <h5 className="font-medium text-primary mb-2">Overall Tutorial Quality</h5>
                              <div className="flex items-center justify-between mb-3">
                                <span className="text-lg font-bold">{Math.round(tutorialMetrics.overall * 100)}%</span>
                                <Badge className={getScoreColorClass(tutorialMetrics.overall)}>
                                  {getScoreRating(tutorialMetrics.overall)}
                                </Badge>
                              </div>
                              <p className="text-sm text-neutral-600">
                                {tutorialMetrics.overall >= 0.8 
                                  ? `Excellent tutorial that effectively communicates concepts for ${learningLevel} learners.`
                                  : tutorialMetrics.overall >= 0.6
                                    ? `Good tutorial with some areas for improvement for ${learningLevel} learners.`
                                    : `This tutorial needs refinement to better engage ${learningLevel} learners.`}
                              </p>
                            </div>
                            
                            <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                              <h5 className="font-medium text-primary mb-2">Content Delivery Strengths</h5>
                              <ul className="list-disc list-inside space-y-1 text-sm text-neutral-600">
                                {tutorialMetrics.pacing >= 0.7 && 
                                  <li>Good pacing that helps the viewer follow along</li>}
                                {tutorialMetrics.enthusiasm >= 0.7 && 
                                  <li>Enthusiasm and energy that keeps viewers engaged</li>}
                                {eyeContactScore >= 0.7 && 
                                  <li>Strong eye contact creates connection with the audience</li>}
                                {tutorialMetrics.facialExpressions >= 0.7 && 
                                  <li>Expressive facial communication reinforces points</li>}
                                {tutorialMetrics.slideAlignment >= 0.7 && 
                                  <li>Effective slide integration supports verbal explanations</li>}
                                {Object.values(tutorialMetrics).filter(score => score >= 0.7).length === 0 && 
                                  eyeContactScore < 0.7 &&
                                  <li>Keep practicing to build on your presentation strengths</li>}
                              </ul>
                            </div>
                            
                            <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                              <h5 className="font-medium text-primary mb-2">Areas for Improvement</h5>
                              <ul className="list-disc list-inside space-y-1 text-sm text-neutral-600">
                                {tutorialMetrics.pacing < 0.7 && 
                                  <li>Work on maintaining a consistent speaking pace throughout</li>}
                                {tutorialMetrics.enthusiasm < 0.7 && 
                                  <li>Add more vocal variety and energy to your delivery</li>}
                                {eyeContactScore < 0.7 && 
                                  <li>Improve consistency of eye contact with the camera</li>}
                                {tutorialMetrics.facialExpressions < 0.7 && 
                                  <li>Use more expressive facial communication</li>}
                                {tutorialMetrics.slideAlignment < 0.7 && 
                                  <li>Better coordinate your verbal content with your slides</li>}
                                {speechClarityScore < 0.7 && 
                                  <li>Improve speech clarity and articulation</li>}
                                {tutorialMetrics.pacing >= 0.7 && 
                                  tutorialMetrics.enthusiasm >= 0.7 && 
                                  eyeContactScore >= 0.7 && 
                                  tutorialMetrics.facialExpressions >= 0.7 && 
                                  tutorialMetrics.slideAlignment >= 0.7 && 
                                  speechClarityScore >= 0.7 && 
                                  <li>Continue refining your already strong presentation skills</li>}
                              </ul>
                            </div>
                            
                            <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-100">
                              <h5 className="font-medium text-primary mb-2">Knowledge Level Adaptation</h5>
                              <p className="text-sm text-neutral-600 mb-3">
                                Based on your {learningLevel} level target audience:
                              </p>
                              <ul className="list-disc list-inside space-y-1 text-sm text-neutral-600">
                                {learningLevel === 'beginner' ? (
                                  <>
                                    <li>Excellent use of simple, accessible language</li>
                                    <li>Consider adding more visual aids to reinforce concepts</li>
                                    <li>Add more real-world examples for better comprehension</li>
                                  </>
                                ) : learningLevel === 'intermediate' ? (
                                  <>
                                    <li>Good balance of technical terms and explanations</li>
                                    <li>Add more comparative analysis between related concepts</li>
                                    <li>Include practical applications to reinforce learning</li>
                                  </>
                                ) : (
                                  <>
                                    <li>Appropriate depth for advanced learners</li>
                                    <li>Consider adding more cutting-edge developments</li>
                                    <li>Include complex case studies to challenge viewers</li>
                                  </>
                                )}
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}