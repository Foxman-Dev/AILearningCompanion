import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import Webcam from "react-webcam";
import * as tf from "@tensorflow/tfjs";
import * as faceLandmarksDetection from "@tensorflow-models/face-landmarks-detection";
import EnhancedFaceAnalyzer from "./enhanced-face-analyzer";
import {
  Video,
  Mic2,
  Play,
  Pause,
  StopCircle,
  Camera,
  Eye,
  AlertTriangle,
  VolumeX,
  Volume2,
  RefreshCw,
  Layers,
  MessageSquare,
  FileText,
  CheckCircle,
  Sparkles
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

type LearningLevel = 'beginner' | 'intermediate' | 'advanced';

interface VideoCreatorProps {
  speechContent: string;
  slideshowContent: string;
  learningLevel: LearningLevel;
  onRecordingComplete: (eyeContactScore: number, speechClarityScore: number) => void;
}

export default function VideoCreator({
  speechContent,
  slideshowContent,
  learningLevel,
  onRecordingComplete
}: VideoCreatorProps) {
  const [activeTab, setActiveTab] = useState<string>("setup");
  
  // Video recording state
  const webcamRef = useRef<Webcam>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [recordedChunks, setRecordedChunks] = useState<Blob[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  
  // Face detection state
  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");
  const [detector, setDetector] = useState<any>(null);
  const [isModelLoading, setIsModelLoading] = useState(true);
  const [isFaceDetected, setIsFaceDetected] = useState(false);
  const requestAnimationRef = useRef<number>();
  
  // Metrics state
  const [eyeContactMetrics, setEyeContactMetrics] = useState<number[]>([]);
  const [eyeContactScore, setEyeContactScore] = useState(0);
  const [speechClarityScore, setSpeechClarityScore] = useState(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisComplete, setAnalysisComplete] = useState(false);
  
  // Google Cloud Vision state
  const [useGoogleVision, setUseGoogleVision] = useState(true);
  
  // Slides state
  const [currentSlide, setCurrentSlide] = useState(0);
  const [slides, setSlides] = useState<string[]>([]);
  const [scriptVisible, setScriptVisible] = useState(true);
  
  const { toast } = useToast();

  // Parse slides from slideshow content
  useEffect(() => {
    if (slideshowContent) {
      const parsedSlides = slideshowContent.split('---').map(slide => slide.trim());
      setSlides(parsedSlides);
    }
  }, [slideshowContent]);

  // Load TensorFlow.js and face landmarks model
  useEffect(() => {
    async function loadModel() {
      try {
        // Make sure TensorFlow.js is initialized
        await tf.ready();
        
        // Load the face landmarks detection model
        const model = faceLandmarksDetection.SupportedModels.MediaPipeFaceMesh;
        const detectorConfig = {
          runtime: 'mediapipe',
          solutionPath: 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh',
          maxFaces: 1
        };
        
        const faceDetector = await faceLandmarksDetection.createDetector(
          model, 
          detectorConfig as any
        );
        
        setDetector(faceDetector);
        setIsModelLoading(false);
        
        toast({
          title: "Face detection initialized",
          description: "Eye contact tracking is now active."
        });
      } catch (error) {
        console.error("Error loading facial recognition model:", error);
        toast({
          title: "Face detection failed",
          description: "Could not initialize eye contact tracking.",
          variant: "destructive"
        });
        setIsModelLoading(false);
      }
    }
    
    loadModel();
    
    return () => {
      if (requestAnimationRef.current) {
        cancelAnimationFrame(requestAnimationRef.current);
      }
    };
  }, [toast]);

  // Clean up URL objects on unmount
  useEffect(() => {
    return () => {
      if (videoUrl) {
        URL.revokeObjectURL(videoUrl);
      }
    };
  }, [videoUrl]);

  // Track recording time
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRecording && !isPaused) {
      interval = setInterval(() => {
        setRecordingTime((prevTime) => prevTime + 1);
      }, 1000);
    }
    
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isRecording, isPaused]);

  // Format seconds to mm:ss
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // Detect eye contact
  const detectEyeContact = useCallback(async () => {
    if (!detector || !webcamRef.current || !webcamRef.current.video || !isRecording) return;
    
    const video = webcamRef.current.video;
    
    if (video.readyState === 4) {
      try {
        // Get face landmarks
        const faces = await detector.estimateFaces(video);
        
        if (faces && faces.length > 0) {
          setIsFaceDetected(true);
          
          // Extract eye landmarks
          const face = faces[0];
          const leftEye = face.keypoints.filter((kp: any) => kp.name && kp.name.includes('leftEye'));
          const rightEye = face.keypoints.filter((kp: any) => kp.name && kp.name.includes('rightEye'));
          
          // Calculate eye attention metrics (simplified)
          const eyeOpenness = calculateEyeOpenness(leftEye, rightEye);
          const lookingAtCamera = isLookingAtCamera(face);
          
          // Score from 0-1, where 1 is perfect eye contact
          let contactScore = eyeOpenness * 0.5 + (lookingAtCamera ? 0.5 : 0);
          
          // Add to metrics array
          setEyeContactMetrics(prevMetrics => {
            const newMetrics = [...prevMetrics, contactScore];
            // Only keep last 30 frames for real-time display
            if (newMetrics.length > 30) {
              return newMetrics.slice(newMetrics.length - 30);
            }
            return newMetrics;
          });
          
          // Update overall score (average of all metrics)
          if (eyeContactMetrics.length > 0) {
            const averageScore = eyeContactMetrics.reduce((sum, score) => sum + score, 0) / eyeContactMetrics.length;
            setEyeContactScore(averageScore);
          }
        } else {
          setIsFaceDetected(false);
        }
      } catch (error) {
        console.error("Error detecting face:", error);
      }
    }
    
    // Continue detection loop
    requestAnimationRef.current = requestAnimationFrame(detectEyeContact);
  }, [detector, isRecording, eyeContactMetrics]);

  // Start eye contact detection when recording
  useEffect(() => {
    if (isRecording && detector && !isPaused) {
      detectEyeContact();
    } else if (requestAnimationRef.current) {
      cancelAnimationFrame(requestAnimationRef.current);
    }
    
    return () => {
      if (requestAnimationRef.current) {
        cancelAnimationFrame(requestAnimationRef.current);
      }
    };
  }, [isRecording, detector, isPaused, detectEyeContact]);

  // Calculate eye openness (simplified)
  const calculateEyeOpenness = (leftEye: any[], rightEye: any[]) => {
    // This is a simplified measure - in production you'd use proper measurements
    // between upper and lower eyelids
    return leftEye.length > 0 && rightEye.length > 0 ? 0.8 : 0.3;
  };

  // Check if looking at camera (simplified)
  const isLookingAtCamera = (face: any) => {
    // In production, you would calculate where the eyes are looking based on
    // the position of the iris relative to the eye corners
    const rotation = face.box.yaw || 0;
    // Consider "looking at camera" if face rotation is minimal
    return Math.abs(rotation) < 0.3;
  };

  // Handle recording actions
  const handleStartRecording = useCallback(() => {
    if (!webcamRef.current || !webcamRef.current.video) return;
    
    setRecordedChunks([]);
    setRecordingTime(0);
    setEyeContactMetrics([]);
    
    const stream = webcamRef.current.video.srcObject as MediaStream;
    const mediaRecorder = new MediaRecorder(stream, {
      mimeType: "video/webm",
    });
    
    mediaRecorder.addEventListener("dataavailable", ({ data }) => {
      if (data.size > 0) {
        setRecordedChunks((prev) => [...prev, data]);
      }
    });
    
    mediaRecorderRef.current = mediaRecorder;
    mediaRecorder.start();
    setIsRecording(true);
    setIsPaused(false);
  }, []);

  const handleStopRecording = useCallback(() => {
    if (!mediaRecorderRef.current) return;
    
    mediaRecorderRef.current.stop();
    setIsRecording(false);
    setIsPaused(false);
    
    // Cancel the animation frame to stop face detection
    if (requestAnimationRef.current) {
      cancelAnimationFrame(requestAnimationRef.current);
    }
    
    setTimeout(() => {
      if (recordedChunks.length) {
        const blob = new Blob(recordedChunks, {
          type: "video/webm",
        });
        setVideoUrl(URL.createObjectURL(blob));
        setActiveTab("review");
        
        // Set a sample speech clarity score (in real implementation, this would be analyzed)
        const sampleSpeechClarity = 0.75 + (Math.random() * 0.2 - 0.1); // Random value between 0.65 and 0.85
        setSpeechClarityScore(sampleSpeechClarity);
      }
    }, 1000);
  }, [recordedChunks]);

  const handlePauseResumeRecording = useCallback(() => {
    if (!mediaRecorderRef.current) return;
    
    if (isPaused) {
      // Resume recording
      mediaRecorderRef.current.resume();
      setIsPaused(false);
    } else {
      // Pause recording
      mediaRecorderRef.current.pause();
      setIsPaused(true);
    }
  }, [isPaused]);

  const handleSwitchCamera = useCallback(() => {
    setFacingMode((prevMode) => 
      prevMode === "user" ? "environment" : "user"
    );
  }, []);

  // Analyze video recording
  const analyzeVideoContent = async () => {
    if (!videoUrl) return;
    
    setIsAnalyzing(true);
    
    try {
      // In a real implementation, you would upload the video to the server
      // and perform speech-to-text analysis, etc.
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Call parent callback with the metrics
      onRecordingComplete(eyeContactScore, speechClarityScore);
      
      toast({
        title: "Analysis complete",
        description: "Your video has been analyzed successfully."
      });
      
      setAnalysisComplete(true);
    } catch (error) {
      console.error("Error analyzing video:", error);
      toast({
        title: "Analysis failed",
        description: "There was an error analyzing your video.",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Get eye contact level classification
  const getEyeContactLevel = () => {
    if (eyeContactScore >= 0.8) return "Excellent";
    if (eyeContactScore >= 0.6) return "Good";
    if (eyeContactScore >= 0.4) return "Fair";
    return "Needs Improvement";
  };

  // Get speech clarity level classification
  const getSpeechClarityLevel = () => {
    if (speechClarityScore >= 0.8) return "Excellent";
    if (speechClarityScore >= 0.6) return "Good";
    if (speechClarityScore >= 0.4) return "Fair";
    return "Needs Improvement";
  };

  // Get color class based on score
  const getScoreColorClass = (score: number) => {
    if (score >= 0.8) return "bg-success text-white";
    if (score >= 0.6) return "bg-primary text-white";
    if (score >= 0.4) return "bg-warning text-white";
    return "bg-error text-white";
  };

  // Navigate through slides
  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  // Parse current slide to extract title and content
  const parseCurrentSlide = () => {
    if (!slides[currentSlide]) return { title: "No slide content", content: "", imageUrl: "" };
    
    const slideContent = slides[currentSlide];
    const titleMatch = slideContent.match(/^#\s+(.+)$/m);
    const title = titleMatch ? titleMatch[1] : "Untitled Slide";
    
    // Extract image if exists
    const imageMatch = slideContent.match(/!\[.*?\]\((.*?)\)/);
    const imageUrl = imageMatch ? imageMatch[1] : "";
    
    // Remove title and image from content
    let content = slideContent
      .replace(/^#\s+(.+)$/m, '')
      .replace(/!\[.*?\]\((.*?)\)/g, '')
      .trim();
    
    return { title, content, imageUrl };
  };

  const currentSlideData = parseCurrentSlide();

  return (
    <div>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-3 mb-6">
          <TabsTrigger value="setup" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            Setup
          </TabsTrigger>
          <TabsTrigger value="record" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            Record
          </TabsTrigger>
          <TabsTrigger value="review" className="data-[state=active]:bg-primary data-[state=active]:text-white" disabled={!videoUrl}>
            Review
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="setup">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-medium mb-4 flex items-center">
                  <Layers className="mr-2 h-5 w-5 text-primary" /> Slideshow Preview
                </h3>
                
                {slides.length > 0 ? (
                  <div>
                    <div className="border border-neutral-200 rounded-lg p-4 mb-4 bg-white min-h-[250px] flex flex-col items-center justify-center">
                      <h2 className="text-xl font-bold mb-4">{currentSlideData.title}</h2>
                      <div className="text-neutral-600 whitespace-pre-line text-center mb-4">
                        {currentSlideData.content}
                      </div>
                      {currentSlideData.imageUrl && (
                        <img 
                          src={currentSlideData.imageUrl} 
                          alt="Slide illustration"
                          className="max-w-full max-h-[150px] object-contain mt-2" 
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = 'https://via.placeholder.com/400x200?text=Image+Not+Found';
                          }}
                        />
                      )}
                    </div>
                    
                    <div className="flex justify-between">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={prevSlide}
                        disabled={currentSlide === 0}
                      >
                        Previous
                      </Button>
                      <span className="text-sm text-neutral-500">
                        Slide {currentSlide + 1} of {slides.length}
                      </span>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={nextSlide}
                        disabled={currentSlide === slides.length - 1}
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 border border-dashed border-neutral-200 rounded-lg">
                    <Layers className="h-12 w-12 text-neutral-300 mx-auto mb-4" />
                    <p className="text-neutral-400">No slides available</p>
                    <p className="text-neutral-300 text-sm mt-2">
                      Create slides in the previous step
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-medium mb-4 flex items-center">
                  <MessageSquare className="mr-2 h-5 w-5 text-primary" /> Script Preview
                </h3>
                
                <div className="border border-neutral-200 rounded-lg p-4 overflow-y-auto max-h-[300px] bg-white">
                  <div className="whitespace-pre-line text-neutral-600">
                    {speechContent || "No speech content available."}
                  </div>
                </div>
                
                <div className="mt-6">
                  <h3 className="text-lg font-medium mb-4 flex items-center">
                    <Video className="mr-2 h-5 w-5 text-primary" /> Video Recording Tips
                  </h3>
                  
                  <ul className="list-disc list-inside space-y-2 text-neutral-600 text-sm">
                    <li>Ensure you're in a well-lit environment</li>
                    <li>Position yourself directly facing the camera</li>
                    <li>Use the script and slides as reference during recording</li>
                    <li>Maintain eye contact with the camera while speaking</li>
                    <li>Speak clearly and at a moderate pace</li>
                  </ul>
                  
                  <Button 
                    className="w-full mt-6 bg-primary text-white"
                    onClick={() => setActiveTab("record")}
                  >
                    Continue to Recording
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="record">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <Card>
                <CardContent className="p-6">
                  <div className="mb-4 relative">
                    <Webcam
                      audio={true}
                      ref={webcamRef}
                      videoConstraints={{
                        facingMode,
                        width: 640,
                        height: 480,
                      }}
                      className="w-full rounded-lg"
                    />
                    
                    {isModelLoading && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-60 rounded-lg">
                        <div className="text-center text-white p-4">
                          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-2" />
                          <p>Loading face detection model...</p>
                        </div>
                      </div>
                    )}
                    
                    {isRecording && !isFaceDetected && (
                      <div className="absolute top-2 right-2">
                        <Badge variant="destructive" className="flex items-center">
                          <AlertTriangle className="mr-1 h-4 w-4" />
                          Face not detected
                        </Badge>
                      </div>
                    )}
                    
                    {isRecording && isFaceDetected && (
                      <div className="absolute top-2 right-2">
                        <Badge className="flex items-center bg-success text-white">
                          <Eye className="mr-1 h-4 w-4" />
                          Eye contact: {Math.round(eyeContactScore * 100)}%
                        </Badge>
                      </div>
                    )}
                    
                    {/* Recording indicator */}
                    {isRecording && (
                      <div className="absolute top-2 left-2 flex items-center">
                        <div className={`h-3 w-3 rounded-full ${isPaused ? 'bg-warning' : 'bg-error animate-pulse'} mr-2`}></div>
                        <span className="text-sm font-medium text-white bg-black bg-opacity-50 px-2 py-1 rounded">
                          {formatTime(recordingTime)}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex flex-col space-y-3">
                    {/* Eye contact indicator */}
                    {isRecording && (
                      <div className="w-full">
                        <div className="flex justify-between text-sm mb-1">
                          <span>Eye Contact Quality</span>
                          <span>{Math.round(eyeContactScore * 100)}%</span>
                        </div>
                        <Progress value={eyeContactScore * 100} className="h-2" />
                      </div>
                    )}
                    
                    <div className="flex justify-between">
                      <Button 
                        variant="outline" 
                        size="icon"
                        onClick={handleSwitchCamera}
                        disabled={isRecording}
                      >
                        <Camera className="h-4 w-4" />
                      </Button>
                      
                      {!isRecording ? (
                        <Button 
                          variant="default" 
                          className="bg-primary text-white px-4"
                          onClick={handleStartRecording}
                          disabled={isModelLoading}
                        >
                          <Video className="mr-2 h-4 w-4" /> 
                          Start Recording
                        </Button>
                      ) : (
                        <div className="space-x-2">
                          <Button 
                            variant={isPaused ? "default" : "outline"} 
                            size="icon"
                            onClick={handlePauseResumeRecording}
                          >
                            {isPaused ? (
                              <Play className="h-4 w-4" />
                            ) : (
                              <Pause className="h-4 w-4" />
                            )}
                          </Button>
                          
                          <Button 
                            variant="destructive" 
                            onClick={handleStopRecording}
                          >
                            <StopCircle className="mr-2 h-4 w-4" />
                            Stop
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-medium">Reference</h3>
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-xs px-2 h-7"
                        onClick={() => setScriptVisible(!scriptVisible)}
                      >
                        {scriptVisible ? "Hide Script" : "Show Script"}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="border border-neutral-200 rounded-lg p-3 mb-4 bg-white min-h-[150px] flex flex-col items-center justify-center">
                    <h3 className="text-lg font-bold mb-2">{currentSlideData.title}</h3>
                    <p className="text-sm text-neutral-500 text-center">
                      {currentSlideData.content.length > 100 
                        ? `${currentSlideData.content.substring(0, 100)}...` 
                        : currentSlideData.content}
                    </p>
                    {currentSlideData.imageUrl && (
                      <img 
                        src={currentSlideData.imageUrl} 
                        alt="Slide illustration"
                        className="max-w-full max-h-[100px] object-contain mt-2" 
                      />
                    )}
                  </div>
                  
                  <div className="flex justify-between mb-4">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={prevSlide}
                      disabled={currentSlide === 0}
                      className="text-xs px-2 h-7"
                    >
                      Previous
                    </Button>
                    <span className="text-xs text-neutral-500">
                      Slide {currentSlide + 1} of {slides.length}
                    </span>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={nextSlide}
                      disabled={currentSlide === slides.length - 1}
                      className="text-xs px-2 h-7"
                    >
                      Next
                    </Button>
                  </div>
                  
                  {scriptVisible && (
                    <div>
                      <div className="flex items-center mb-2">
                        <FileText className="h-4 w-4 mr-1 text-primary" />
                        <h4 className="text-sm font-medium">Script</h4>
                      </div>
                      <div className="border border-neutral-200 rounded-lg p-3 bg-neutral-50 max-h-[200px] overflow-y-auto">
                        <p className="text-xs text-neutral-600 whitespace-pre-line">
                          {speechContent}
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="review">
          {videoUrl && (
            <div className="space-y-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4">Video Review</h3>
                  <div className="mb-4">
                    <video 
                      src={videoUrl} 
                      controls 
                      className="w-full rounded-lg"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div>
                      <h4 className="text-sm font-medium mb-2">Eye Contact</h4>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-neutral-500">Quality</span>
                        <Badge className={getScoreColorClass(eyeContactScore)}>
                          {getEyeContactLevel()}
                        </Badge>
                      </div>
                      <Progress value={eyeContactScore * 100} className="h-2 mb-3" />
                      <p className="text-xs text-neutral-500">
                        {eyeContactScore >= 0.8 
                          ? "Excellent eye contact throughout the presentation."
                          : eyeContactScore >= 0.6
                            ? "Good eye contact with some room for improvement."
                            : eyeContactScore >= 0.4
                              ? "Inconsistent eye contact. Try to look at the camera more."
                              : "Limited eye contact. Practice maintaining camera focus."
                        }
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium mb-2">Speech Clarity</h4>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-neutral-500">Quality</span>
                        <Badge className={getScoreColorClass(speechClarityScore)}>
                          {getSpeechClarityLevel()}
                        </Badge>
                      </div>
                      <Progress value={speechClarityScore * 100} className="h-2 mb-3" />
                      <p className="text-xs text-neutral-500">
                        {speechClarityScore >= 0.8 
                          ? "Clear and well-articulated speech throughout."
                          : speechClarityScore >= 0.6
                            ? "Generally clear speech with occasional unclear moments."
                            : speechClarityScore >= 0.4
                              ? "Speech was sometimes unclear. Work on pronunciation."
                              : "Speech was difficult to understand. Practice articulation."
                        }
                      </p>
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full bg-primary text-white"
                    onClick={analyzeVideoContent}
                    disabled={isAnalyzing || analysisComplete}
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing...
                      </>
                    ) : analysisComplete ? (
                      <>
                        <CheckCircle className="mr-2 h-4 w-4" /> Analysis Complete
                      </>
                    ) : (
                      <>
                        <Sparkles className="mr-2 h-4 w-4" /> Analyze Content & Delivery
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
              
              {analysisComplete && (
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium mb-4">AI Feedback</h3>
                    
                    <div className="space-y-4">
                      <div className="border border-neutral-200 rounded-lg p-4">
                        <h4 className="font-medium mb-2 text-primary">Content Adaptation</h4>
                        <p className="text-sm text-neutral-600 mb-2">
                          Your content {learningLevel === 'beginner' 
                            ? "uses simple language appropriate for beginners." 
                            : learningLevel === 'intermediate'
                              ? "balances technical terms with explanations well for intermediate learners."
                              : "provides advanced concepts suitable for experienced learners."}
                        </p>
                        <p className="text-xs text-neutral-500">
                          Tips for {learningLevel} level: {learningLevel === 'beginner' 
                            ? "Continue using concrete examples and visual aids to reinforce concepts." 
                            : learningLevel === 'intermediate'
                              ? "Consider adding more comparative analysis between concepts to deepen understanding."
                              : "Include more industry applications and cutting-edge developments to challenge advanced learners."}
                        </p>
                      </div>
                      
                      <div className="border border-neutral-200 rounded-lg p-4">
                        <h4 className="font-medium mb-2 text-primary">Presentation Skills</h4>
                        <div className="grid grid-cols-2 gap-4 text-sm mb-2">
                          <div>
                            <p className="font-medium">Eye Contact</p>
                            <p className="text-neutral-600">
                              {getEyeContactLevel()} ({Math.round(eyeContactScore * 100)}%)
                            </p>
                          </div>
                          <div>
                            <p className="font-medium">Speech Clarity</p>
                            <p className="text-neutral-600">
                              {getSpeechClarityLevel()} ({Math.round(speechClarityScore * 100)}%)
                            </p>
                          </div>
                        </div>
                        <p className="text-xs text-neutral-500">
                          Suggested improvements: {eyeContactScore < 0.7 ? "Practice maintaining eye contact with the camera. " : ""}
                          {speechClarityScore < 0.7 ? "Work on speech articulation and pacing. " : ""}
                          {eyeContactScore >= 0.7 && speechClarityScore >= 0.7 ? "Your presentation skills are strong. Consider adding more dynamic vocal variety." : ""}
                        </p>
                      </div>
                      
                      <div className="border border-neutral-200 rounded-lg p-4">
                        <h4 className="font-medium mb-2 text-primary">Slide Integration</h4>
                        <p className="text-sm text-neutral-600 mb-2">
                          Your slides {slides.length < 5 
                            ? "are minimal, which may not fully support your verbal content." 
                            : slides.length < 10
                              ? "provide good visual support for your presentation."
                              : "are comprehensive and illustrate your points well."}
                        </p>
                        <p className="text-xs text-neutral-500">
                          Tips for improvement: {slides.length < 5 
                            ? "Consider adding more visual aids to reinforce key concepts." 
                            : slides.length < 10
                              ? "Ensure each slide has a clear purpose and reinforces a single main point."
                              : "Check for information overload; simpler slides often communicate more effectively."}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}