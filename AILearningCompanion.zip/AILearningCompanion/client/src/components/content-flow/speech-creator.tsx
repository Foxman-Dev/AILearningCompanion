import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import {
  Bold,
  Italic,
  List,
  ArrowDownToLine,
  Sparkles,
  Loader2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

type LearningLevel = 'beginner' | 'intermediate' | 'advanced';

interface SpeechCreatorProps {
  initialContent: string;
  learningLevel: LearningLevel;
  onContentChange: (content: string) => void;
  onLevelChange: (level: LearningLevel) => void;
}

export default function SpeechCreator({ 
  initialContent, 
  learningLevel, 
  onContentChange, 
  onLevelChange 
}: SpeechCreatorProps) {
  const [title, setTitle] = useState("Untitled Speech");
  const [content, setContent] = useState(initialContent || "");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [feedback, setFeedback] = useState<any>(null);
  const { toast } = useToast();

  // Handle content change and notify parent
  const handleContentChange = (newContent: string) => {
    setContent(newContent);
    onContentChange(newContent);
  };

  // Handle learning level change
  const handleLevelChange = (level: LearningLevel) => {
    onLevelChange(level);
  };

  // Format text functions
  const applyFormat = (format: string) => {
    const textarea = document.getElementById('speechContent') as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end);
    let formattedText = '';

    switch (format) {
      case 'bold':
        formattedText = `**${selectedText}**`;
        break;
      case 'italic':
        formattedText = `*${selectedText}*`;
        break;
      case 'list':
        formattedText = selectedText
          .split('\n')
          .map(line => line.trim() ? `- ${line}` : line)
          .join('\n');
        break;
      default:
        return;
    }

    const newContent = 
      content.substring(0, start) + 
      formattedText + 
      content.substring(end);
    
    handleContentChange(newContent);
    
    // Re-focus and set selection after format is applied
    setTimeout(() => {
      textarea.focus();
      textarea.selectionStart = start;
      textarea.selectionEnd = start + formattedText.length;
    }, 0);
  };

  // Analyze content for learning level
  const analyzeContent = async () => {
    if (!content.trim()) {
      toast({
        title: "Cannot analyze",
        description: "Please add some content before analyzing.",
        variant: "destructive"
      });
      return;
    }

    setIsAnalyzing(true);

    try {
      const response = await apiRequest(
        'POST',
        '/api/analyze-content',
        {
          content,
          contentType: 'speech',
          knowledgeLevel: learningLevel
        }
      );

      const result = await response.json();
      setFeedback(result);

      toast({
        title: "Analysis complete",
        description: "Your speech has been analyzed for the selected knowledge level."
      });
    } catch (error) {
      console.error("Error analyzing content:", error);
      toast({
        title: "Analysis failed",
        description: "There was an error analyzing your content.",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Generate improved content based on feedback
  const generateImprovedContent = async () => {
    if (!content.trim()) {
      toast({
        title: "Cannot generate",
        description: "Please add some content before generating improvements.",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);

    try {
      const response = await apiRequest(
        'POST',
        '/api/generate-content',
        {
          originalContent: content,
          knowledgeLevel: learningLevel,
          contentType: 'speech'
        }
      );

      const result = await response.json();
      handleContentChange(result.content);

      toast({
        title: "Generation complete",
        description: `Your speech has been optimized for ${learningLevel} learners.`
      });
    } catch (error) {
      console.error("Error generating content:", error);
      toast({
        title: "Generation failed",
        description: "There was an error generating improved content.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <div className="mb-4">
          <label htmlFor="title" className="block text-neutral-600 text-sm font-medium mb-2">
            Title
          </label>
          <Input
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full focus:ring-2 focus:ring-primary focus:border-transparent"
            placeholder="Enter a title for your speech"
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-neutral-600 text-sm font-medium mb-2">
            Target Knowledge Level
          </label>
          <ToggleGroup 
            type="single" 
            value={learningLevel} 
            onValueChange={(value) => value && handleLevelChange(value as LearningLevel)}
            className="justify-start"
          >
            <ToggleGroupItem value="beginner" aria-label="Beginner" className={learningLevel === 'beginner' ? "bg-primary text-white" : ""}>
              Beginner
            </ToggleGroupItem>
            <ToggleGroupItem value="intermediate" aria-label="Intermediate" className={learningLevel === 'intermediate' ? "bg-primary text-white" : ""}>
              Intermediate
            </ToggleGroupItem>
            <ToggleGroupItem value="advanced" aria-label="Advanced" className={learningLevel === 'advanced' ? "bg-primary text-white" : ""}>
              Advanced
            </ToggleGroupItem>
          </ToggleGroup>
        </div>
        
        <div className="mb-4">
          <label htmlFor="speechContent" className="block text-neutral-600 text-sm font-medium mb-2">
            Speech Content
          </label>
          <div className="border border-neutral-200 rounded bg-white">
            <div className="border-b border-neutral-200 p-2 bg-neutral-100 flex">
              <Button variant="ghost" size="sm" className="p-1 mr-1 hover:bg-neutral-200 rounded" onClick={() => applyFormat('bold')}>
                <Bold className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" className="p-1 mr-1 hover:bg-neutral-200 rounded" onClick={() => applyFormat('italic')}>
                <Italic className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" className="p-1 mr-1 hover:bg-neutral-200 rounded" onClick={() => applyFormat('list')}>
                <List className="h-4 w-4" />
              </Button>
            </div>
            <Textarea
              id="speechContent"
              rows={16}
              value={content}
              onChange={(e) => handleContentChange(e.target.value)}
              className="w-full p-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent rounded-none border-0"
              placeholder="Write your speech content here..."
            />
          </div>
          <div className="flex justify-between mt-2 text-xs text-neutral-400">
            <span>{content.length} characters</span>
            <span>Approximately {Math.ceil(content.length / 1000)} minute read</span>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button variant="outline" className="flex items-center" onClick={analyzeContent} disabled={isAnalyzing}>
            {isAnalyzing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing...
              </>
            ) : (
              <>
                <ArrowDownToLine className="mr-2 h-4 w-4" /> Analyze for {learningLevel}
              </>
            )}
          </Button>
          <Button className="bg-primary text-white flex items-center" onClick={generateImprovedContent} disabled={isGenerating}>
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" /> Optimize Content
              </>
            )}
          </Button>
        </div>
      </div>

      <div>
        {feedback ? (
          <Card className="bg-neutral-50 p-4">
            <h3 className="font-medium text-lg mb-4 flex items-center text-neutral-600">
              <Sparkles className="mr-2 h-5 w-5 text-primary" /> AI Analysis
            </h3>
            
            <div className="mb-4">
              <h4 className={`font-medium mb-2 ${
                feedback.complexity.level === 'low' 
                  ? 'text-success' 
                  : feedback.complexity.level === 'moderate' 
                    ? 'text-warning' 
                    : 'text-error'
              }`}>
                Content Complexity
              </h4>
              <p className="text-sm text-neutral-600 mb-2">
                {feedback.complexity.level === 'low' 
                  ? "This content is appropriate for beginners." 
                  : feedback.complexity.level === 'moderate'
                    ? "This content may be difficult for beginners to understand."
                    : "This content is too complex for the target audience."}
              </p>
              <div className="text-sm">
                <strong className="text-neutral-700">Suggestion:</strong> 
                <span className="text-neutral-600">{feedback.complexity.suggestion}</span>
              </div>
            </div>
            
            {feedback.visualOpportunity && (
              <div className="mb-4">
                <h4 className="font-medium mb-2 text-primary">Visual Opportunity</h4>
                <p className="text-sm text-neutral-600 mb-2">Adding visuals would improve comprehension.</p>
                <div className="text-sm">
                  <strong className="text-neutral-700">Suggestion:</strong> 
                  <span className="text-neutral-600">{feedback.visualOpportunity.suggestion}</span>
                </div>
              </div>
            )}
            
            <div>
              <h4 className="font-medium mb-2 text-primary">Learning Enhancement</h4>
              <p className="text-sm text-neutral-600 mb-2">Consider adding more context or examples.</p>
              <div className="text-sm">
                <strong className="text-neutral-700">Suggestion:</strong> 
                <span className="text-neutral-600">{feedback.learningEnhancement.suggestion}</span>
              </div>
            </div>
          </Card>
        ) : (
          <div className="bg-neutral-50 p-6 border border-dashed border-neutral-200 rounded-lg text-center h-full flex flex-col justify-center items-center">
            <Sparkles className="h-10 w-10 text-neutral-300 mb-4" />
            <h3 className="text-neutral-400 font-medium mb-2">Speech Analysis</h3>
            <p className="text-neutral-300 text-sm mb-4">
              Click "Analyze" to get AI feedback on your speech content based on the selected knowledge level.
            </p>
            <Button variant="outline" className="text-primary" onClick={analyzeContent} disabled={isAnalyzing}>
              {isAnalyzing ? "Analyzing..." : "Analyze Content"}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}