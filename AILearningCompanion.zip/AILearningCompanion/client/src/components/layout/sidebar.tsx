import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Video,
  SlidersHorizontal,
  Mic2,
  LineChart,
  Settings
} from "lucide-react";

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  text: string;
  active?: boolean;
}

function NavItem({ href, icon, text, active }: NavItemProps) {
  return (
    <li>
      <Link href={href}>
        <a
          className={cn(
            "flex items-center py-3 px-4 hover:text-primary hover:bg-neutral-100 transition-colors",
            active
              ? "text-primary bg-primary/10 border-l-4 border-primary"
              : "text-neutral-400 border-l-4 border-transparent"
          )}
        >
          {icon}
          <span className="ml-2">{text}</span>
        </a>
      </Link>
    </li>
  );
}

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <nav className="bg-white w-64 shadow-lg hidden md:block overflow-y-auto">
      <div className="py-4">
        <div className="px-4 pb-4 border-b border-neutral-200">
          <h2 className="font-heading font-medium text-lg text-neutral-400">Content Library</h2>
        </div>
        
        <ul className="mt-4">
          <NavItem
            href="/"
            icon={<LayoutDashboard className="h-5 w-5" />}
            text="Dashboard"
            active={location === '/'}
          />
          <NavItem
            href="/video-courses"
            icon={<Video className="h-5 w-5" />}
            text="Video Courses"
            active={location === '/video-courses'}
          />
          <NavItem
            href="/slideshows"
            icon={<SlidersHorizontal className="h-5 w-5" />}
            text="Slideshows"
            active={location === '/slideshows'}
          />
          <NavItem
            href="/speeches"
            icon={<Mic2 className="h-5 w-5" />}
            text="Speeches"
            active={location === '/speeches'}
          />
          <li className="border-t border-neutral-200 mt-4 pt-4">
            <NavItem
              href="/analytics"
              icon={<LineChart className="h-5 w-5" />}
              text="Analytics"
              active={location === '/analytics'}
            />
          </li>
          <NavItem
            href="/settings"
            icon={<Settings className="h-5 w-5" />}
            text="Settings"
            active={location === '/settings'}
          />
        </ul>
      </div>
    </nav>
  );
}
