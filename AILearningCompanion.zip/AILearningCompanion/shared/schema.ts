import { pgTable, serial, text, varchar, integer, timestamp, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 255 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Content types enum
export const contentTypes = ['video', 'slideshow', 'speech'] as const;
export type ContentType = typeof contentTypes[number];

// Knowledge levels enum
export const knowledgeLevels = ['beginner', 'intermediate', 'advanced'] as const;
export type KnowledgeLevel = typeof knowledgeLevels[number];

// Contents table
export const contents = pgTable("contents", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  content: text("content").notNull(),
  knowledgeLevel: varchar("knowledge_level", { length: 50 }).notNull(),
  complexityScore: integer("complexity_score"),
  optimized: boolean("optimized").default(false),
  imageUrl: varchar("image_url", { length: 1000 }),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertContentSchema = createInsertSchema(contents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertContent = z.infer<typeof insertContentSchema>;
export type Content = typeof contents.$inferSelect;

// AI Feedback table
export const aiFeedbacks = pgTable("ai_feedbacks", {
  id: serial("id").primaryKey(),
  contentId: integer("content_id").references(() => contents.id).notNull(),
  complexity: integer("complexity").notNull(),
  clarity: integer("clarity").notNull(),
  engagement: integer("engagement").notNull(),
  feedback: text("feedback").notNull(),
  suggestions: text("suggestions"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAIFeedbackSchema = createInsertSchema(aiFeedbacks).omit({
  id: true,
  createdAt: true,
});

export type InsertAIFeedback = z.infer<typeof insertAIFeedbackSchema>;
export type AIFeedback = typeof aiFeedbacks.$inferSelect;

// Learning Achievements Types enum
export const achievementTypes = [
  'content_created', 
  'speech_mastery', 
  'slideshow_expert', 
  'video_presenter',
  'eye_contact_master',
  'speech_clarity_champion',
  'content_series_completed',
  'knowledge_level_up'
] as const;
export type AchievementType = typeof achievementTypes[number];

// Learning Progress and Achievements table
export const learningProgress = pgTable("learning_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  totalPoints: integer("total_points").default(0).notNull(),
  level: integer("level").default(1).notNull(),
  contentCreated: integer("content_created").default(0).notNull(),
  speechCompleted: integer("speech_completed").default(0).notNull(),
  slideshowsCreated: integer("slideshows_created").default(0).notNull(),
  videosRecorded: integer("videos_recorded").default(0).notNull(),
  avgEyeContactScore: integer("avg_eye_contact_score").default(0),
  avgSpeechClarityScore: integer("avg_speech_clarity_score").default(0),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const insertLearningProgressSchema = createInsertSchema(learningProgress).omit({
  id: true,
  lastUpdated: true,
});

export type InsertLearningProgress = z.infer<typeof insertLearningProgressSchema>;
export type LearningProgress = typeof learningProgress.$inferSelect;

// User Achievements table
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  pointsAwarded: integer("points_awarded").default(0).notNull(),
  iconUrl: varchar("icon_url", { length: 255 }),
  dateEarned: timestamp("date_earned").defaultNow().notNull(),
  level: integer("level").default(1).notNull(),
});

export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
  dateEarned: true,
});

export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type Achievement = typeof achievements.$inferSelect;

// Learning Milestones for Level Progression
export const learningMilestones = pgTable("learning_milestones", {
  id: serial("id").primaryKey(),
  level: integer("level").notNull().unique(),
  pointsRequired: integer("points_required").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  rewardDescription: text("reward_description"),
  iconUrl: varchar("icon_url", { length: 255 }),
});

export const insertLearningMilestoneSchema = createInsertSchema(learningMilestones).omit({
  id: true,
});

export type InsertLearningMilestone = z.infer<typeof insertLearningMilestoneSchema>;
export type LearningMilestone = typeof learningMilestones.$inferSelect;

// Define relationships between tables
export const usersRelations = relations(users, ({ many }) => ({
  contents: many(contents),
  progressRecords: many(learningProgress),
  achievements: many(achievements),
}));

export const contentsRelations = relations(contents, ({ one, many }) => ({
  user: one(users, {
    fields: [contents.userId],
    references: [users.id],
  }),
  feedbacks: many(aiFeedbacks),
}));

export const aiFeedbacksRelations = relations(aiFeedbacks, ({ one }) => ({
  content: one(contents, {
    fields: [aiFeedbacks.contentId],
    references: [contents.id],
  }),
}));

export const learningProgressRelations = relations(learningProgress, ({ one }) => ({
  user: one(users, {
    fields: [learningProgress.userId],
    references: [users.id],
  }),
}));

export const achievementsRelations = relations(achievements, ({ one }) => ({
  user: one(users, {
    fields: [achievements.userId],
    references: [users.id],
  }),
}));