import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertContentSchema, knowledgeLevels } from "@shared/schema";
import OpenAI from "openai";
import visionRoutes from "./routes/visionRoutes";

// Initialize OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "dummy_key" });

export async function registerRoutes(app: Express): Promise<Server> {
  // Register Vision API routes
  app.use('/api/vision', visionRoutes);
  
  // API routes
  app.get("/api/contents", async (req: Request, res: Response) => {
    try {
      const contents = await storage.getAllContents();
      res.json(contents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch contents" });
    }
  });

  app.get("/api/contents/:id", async (req: Request, res: Response) => {
    try {
      const content = await storage.getContent(parseInt(req.params.id));
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch content" });
    }
  });

  app.post("/api/contents", async (req: Request, res: Response) => {
    try {
      const validation = insertContentSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid content data", errors: validation.error.format() });
      }
      
      const content = await storage.createContent(validation.data);
      res.status(201).json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to create content" });
    }
  });

  // Content type-specific endpoints
  const contentTypes = ["video-courses", "slideshows", "speeches"];
  contentTypes.forEach(type => {
    app.get(`/api/${type}`, async (req: Request, res: Response) => {
      try {
        const contentType = type === "video-courses" ? "video" : type === "slideshows" ? "slideshow" : "speech";
        const contents = await storage.getContentsByType(contentType);
        res.json(contents);
      } catch (error) {
        res.status(500).json({ message: `Failed to fetch ${type}` });
      }
    });
    
    app.get(`/api/${type}/:id`, async (req: Request, res: Response) => {
      try {
        const content = await storage.getContent(parseInt(req.params.id));
        if (!content) {
          return res.status(404).json({ message: "Content not found" });
        }
        const contentType = type === "video-courses" ? "video" : type === "slideshows" ? "slideshow" : "speech";
        if (content.type !== contentType) {
          return res.status(404).json({ message: "Content type mismatch" });
        }
        res.json(content);
      } catch (error) {
        res.status(500).json({ message: `Failed to fetch ${type}` });
      }
    });
  });

  // AI Analysis endpoint
  const analyzeRequestSchema = z.object({
    content: z.string().min(1),
    contentType: z.enum(["video", "slideshow", "speech"]),
    knowledgeLevel: z.enum(["beginner", "intermediate", "advanced"]),
  });

  app.post("/api/analyze-content", async (req: Request, res: Response) => {
    try {
      const validation = analyzeRequestSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid analysis request", errors: validation.error.format() });
      }

      const { content, contentType, knowledgeLevel } = validation.data;
      
      // For simplicity in development, we'll use a mock response for OpenAI
      // In production, you'd use the real OpenAI API
      let complexityScore = 0.5;
      if (knowledgeLevel === "beginner") {
        complexityScore = content.length > 500 ? 0.7 : 0.3;
      } else if (knowledgeLevel === "intermediate") {
        complexityScore = content.length > 700 ? 0.8 : 0.5;
      } else {
        complexityScore = content.length > 1000 ? 0.5 : 0.9;
      }

      const analysis = {
        complexity: {
          level: complexityScore < 0.4 ? "low" : complexityScore < 0.7 ? "moderate" : "high",
          score: complexityScore,
          suggestion: "Add brief explanations of technical terms and simplify complex sentences for better understanding."
        },
        visualOpportunity: {
          suggestion: "Include a comparison chart showing key concepts to enhance visual learning."
        },
        learningEnhancement: {
          suggestion: "Add real-world examples or case studies to make the content more relatable and easier to understand."
        }
      };

      // If OpenAI API is available, use it for real analysis
      if (process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY !== "dummy_key") {
        try {
          const response = await openai.chat.completions.create({
            model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
            messages: [
              {
                role: "system",
                content: `You are an educational content analyzer. Analyze the following ${contentType} content for a ${knowledgeLevel} audience. Provide feedback on complexity, visual opportunities, and learning enhancements. Respond with JSON in this format: { "complexity": { "level": "low/moderate/high", "score": number between 0-1, "suggestion": "specific improvement suggestion" }, "visualOpportunity": { "suggestion": "specific suggestion" }, "learningEnhancement": { "suggestion": "specific suggestion" } }`
              },
              {
                role: "user",
                content: content
              }
            ],
            response_format: { type: "json_object" }
          });

          if (response.choices[0].message.content) {
            const aiAnalysis = JSON.parse(response.choices[0].message.content);
            // Store the feedback
            await storage.createAIFeedback({
              contentId: -1, // We'd use a real content ID in production
              feedback: aiAnalysis
            });
            return res.json(aiAnalysis);
          }
        } catch (openAiError) {
          console.error("OpenAI API error:", openAiError);
          // Fall back to mock response
        }
      }

      // Store the feedback
      await storage.createAIFeedback({
        contentId: -1, // We'd use a real content ID in production
        feedback: analysis
      });

      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing content:", error);
      res.status(500).json({ message: "Failed to analyze content" });
    }
  });

  // Content enhancement endpoint
  const enhanceRequestSchema = z.object({
    originalContent: z.string().min(1),
    knowledgeLevel: z.enum(knowledgeLevels),
  });

  app.post("/api/generate-content", async (req: Request, res: Response) => {
    try {
      const validation = enhanceRequestSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid enhancement request", errors: validation.error.format() });
      }

      const { originalContent, knowledgeLevel } = validation.data;
      
      // Enhanced content response (mock for development)
      let enhancedContent = originalContent;
      
      // Only use OpenAI if API key is available
      if (process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY !== "dummy_key") {
        try {
          const response = await openai.chat.completions.create({
            model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
            messages: [
              {
                role: "system",
                content: `You are an educational content enhancer. Improve the following content for ${knowledgeLevel} learners. Make it more clear, engaging, and appropriate for the knowledge level. Add examples and explanations where needed. Return the enhanced content in the same format as the original.`
              },
              {
                role: "user",
                content: originalContent
              }
            ]
          });

          if (response.choices[0].message.content) {
            enhancedContent = response.choices[0].message.content;
          }
        } catch (openAiError) {
          console.error("OpenAI API error:", openAiError);
          // Fall back to original content
        }
      }

      res.json({ content: enhancedContent });
    } catch (error) {
      console.error("Error generating enhanced content:", error);
      res.status(500).json({ message: "Failed to generate enhanced content" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
