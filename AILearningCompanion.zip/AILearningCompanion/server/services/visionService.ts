import fetch from 'node-fetch';

// Types for Google Cloud Vision API
interface VisionRequestImage {
  content?: string;
  source?: {
    imageUri: string;
  };
}

interface VisionRequest {
  image: VisionRequestImage;
  features: Array<{
    type: string;
    maxResults?: number;
  }>;
}

interface VisionResponse {
  faceAnnotations?: Array<{
    joyLikelihood: string;
    sorrowLikelihood: string;
    angerLikelihood: string;
    surpriseLikelihood: string;
    headwearLikelihood: string;
    detectionConfidence: number;
    landmarkingConfidence: number;
    panAngle: number;
    tiltAngle: number;
    rollAngle: number;
    boundingPoly: {
      vertices: Array<{
        x: number;
        y: number;
      }>;
    };
    fdBoundingPoly: {
      vertices: Array<{
        x: number;
        y: number;
      }>;
    };
    landmarks: Array<{
      type: string;
      position: {
        x: number;
        y: number;
        z: number;
      };
    }>;
  }>;
}

// Eye contact analysis result
export interface EyeContactAnalysis {
  score: number;
  lookingAtCamera: boolean;
  confidence: number;
}

// Facial expression analysis result
export interface FacialExpressionAnalysis {
  joy: number;
  sorrow: number;
  anger: number;
  surprise: number;
  engagementScore: number;
}

// Complete face analysis result
export interface FaceAnalysisResult {
  eyeContact: EyeContactAnalysis;
  facialExpression: FacialExpressionAnalysis;
  detectionConfidence: number;
  faceDetected: boolean;
}

// Convert likelihood string to numeric score
const likelihoodToScore = (likelihood: string): number => {
  const likelihoodMap: Record<string, number> = {
    'UNKNOWN': 0,
    'VERY_UNLIKELY': 0.1,
    'UNLIKELY': 0.3,
    'POSSIBLE': 0.5,
    'LIKELY': 0.7,
    'VERY_LIKELY': 0.9
  };
  
  return likelihoodMap[likelihood] || 0;
};

// Analyze eye contact based on face angles
const analyzeEyeContact = (faceAnnotation: any): EyeContactAnalysis => {
  const panAngle = Math.abs(faceAnnotation.panAngle); // Left-right head rotation
  const tiltAngle = Math.abs(faceAnnotation.tiltAngle); // Up-down head tilt
  const rollAngle = Math.abs(faceAnnotation.rollAngle); // Head roll

  // Calculate score based on face angles (lower angles = better eye contact)
  const maxAngleDeviation = 30; // Max allowable angle for good eye contact
  const panScore = Math.max(0, 1 - (panAngle / maxAngleDeviation));
  const tiltScore = Math.max(0, 1 - (tiltAngle / maxAngleDeviation));
  const rollScore = Math.max(0, 1 - (rollAngle / maxAngleDeviation));
  
  // Weighted average of the three scores
  const weightedScore = (panScore * 0.5) + (tiltScore * 0.3) + (rollScore * 0.2);
  
  // Scale to 0-100
  const score = Math.round(weightedScore * 100);
  
  return {
    score,
    lookingAtCamera: score > 70, // Consider good eye contact above 70%
    confidence: faceAnnotation.detectionConfidence
  };
};

// Analyze facial expressions based on likelihood values
const analyzeFacialExpression = (faceAnnotation: any): FacialExpressionAnalysis => {
  const joy = likelihoodToScore(faceAnnotation.joyLikelihood);
  const sorrow = likelihoodToScore(faceAnnotation.sorrowLikelihood);
  const anger = likelihoodToScore(faceAnnotation.angerLikelihood);
  const surprise = likelihoodToScore(faceAnnotation.surpriseLikelihood);
  
  // Engagement score - positively affected by joy and surprise, negatively by sorrow and anger
  const engagementScore = Math.round(((joy * 0.5) + (surprise * 0.3) - (sorrow * 0.1) - (anger * 0.1)) * 100);
  
  return {
    joy,
    sorrow,
    anger, 
    surprise,
    engagementScore: Math.max(0, Math.min(100, engagementScore)) // Clamp between 0-100
  };
};

/**
 * Analyzes a face in an image using Google Cloud Vision API
 * @param imageBase64 Base64 encoded image data (without data:image/jpeg;base64, prefix)
 * @returns Analysis of eye contact and facial expressions
 */
export async function analyzeFace(imageBase64: string): Promise<FaceAnalysisResult> {
  try {
    const apiKey = process.env.GOOGLE_CLOUD_VISION_API_KEY;
    
    if (!apiKey) {
      throw new Error('Google Cloud Vision API key not found in environment variables');
    }
    
    const requestBody: { requests: VisionRequest[] } = {
      requests: [
        {
          image: {
            content: imageBase64
          },
          features: [
            {
              type: 'FACE_DETECTION',
              maxResults: 1
            }
          ]
        }
      ]
    };
    
    const response = await fetch(
      `https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`,
      {
        method: 'POST',
        body: JSON.stringify(requestBody),
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );
    
    if (!response.ok) {
      throw new Error(`Google Cloud Vision API error: ${response.statusText}`);
    }
    
    const responseData = await response.json();
    
    // Check if faces were detected
    const faceAnnotations = responseData.responses[0]?.faceAnnotations;
    
    if (!faceAnnotations || faceAnnotations.length === 0) {
      return {
        eyeContact: { score: 0, lookingAtCamera: false, confidence: 0 },
        facialExpression: { joy: 0, sorrow: 0, anger: 0, surprise: 0, engagementScore: 0 },
        detectionConfidence: 0,
        faceDetected: false
      };
    }
    
    const faceAnnotation = faceAnnotations[0];
    const eyeContact = analyzeEyeContact(faceAnnotation);
    const facialExpression = analyzeFacialExpression(faceAnnotation);
    
    return {
      eyeContact,
      facialExpression,
      detectionConfidence: faceAnnotation.detectionConfidence,
      faceDetected: true
    };
  } catch (error) {
    console.error('Error analyzing face with Google Cloud Vision:', error);
    throw error;
  }
}