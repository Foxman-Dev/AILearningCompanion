import { 
  users, 
  type User, 
  type InsertUser, 
  contents, 
  type Content, 
  type InsertContent,
  aiFeedbacks,
  type AIFeedback,
  type InsertAIFeedback,
  learningProgress,
  type LearningProgress,
  type InsertLearningProgress,
  achievements,
  type Achievement,
  type InsertAchievement,
  learningMilestones,
  type LearningMilestone,
  type InsertLearningMilestone
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, count, avg } from "drizzle-orm";

// Storage interface
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Content operations
  getContent(id: number): Promise<Content | undefined>;
  getAllContents(): Promise<Content[]>;
  getContentsByType(type: string): Promise<Content[]>;
  getContentsByUserId(userId: number): Promise<Content[]>;
  createContent(content: InsertContent): Promise<Content>;
  updateContent(id: number, content: Partial<Content>): Promise<Content | undefined>;
  deleteContent(id: number): Promise<boolean>;
  
  // AI Feedback operations
  getAIFeedback(id: number): Promise<AIFeedback | undefined>;
  getAIFeedbacksByContentId(contentId: number): Promise<AIFeedback[]>;
  createAIFeedback(feedback: InsertAIFeedback): Promise<AIFeedback>;
  
  // Learning Progress operations
  getLearningProgress(userId: number): Promise<LearningProgress | undefined>;
  createLearningProgress(progress: InsertLearningProgress): Promise<LearningProgress>;
  updateLearningProgress(userId: number, updates: Partial<LearningProgress>): Promise<LearningProgress | undefined>;
  incrementLearningPoints(userId: number, points: number): Promise<LearningProgress | undefined>;
  
  // Achievement operations
  getAchievements(userId: number): Promise<Achievement[]>;
  getRecentAchievements(userId: number, limit: number): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  
  // Learning Milestone operations
  getLearningMilestones(): Promise<LearningMilestone[]>;
  getLearningMilestone(level: number): Promise<LearningMilestone | undefined>;
  createLearningMilestone(milestone: InsertLearningMilestone): Promise<LearningMilestone>;
  
  // User Stats operations
  getUserStats(userId: number): Promise<{
    contentCount: number;
    speechCount: number;
    slideshowCount: number;
    videoCount: number;
    avgEyeContactScore: number;
    avgSpeechClarityScore: number;
    achievementCount: number;
  }>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db
      .insert(users)
      .values(user)
      .returning();
    
    // Initialize learning progress for the new user
    await this.createLearningProgress({
      userId: newUser.id,
      totalPoints: 10, // Starting points
      level: 1,
      contentCreated: 0,
      speechCompleted: 0,
      slideshowsCreated: 0,
      videosRecorded: 0
    });
    
    // Award first achievement for account creation
    await this.createAchievement({
      userId: newUser.id,
      type: 'account_created',
      title: 'Joined the Journey',
      description: 'Created your account and started your educational journey',
      pointsAwarded: 10,
      iconUrl: '/icons/achievements/account_created.svg'
    });
    
    return newUser;
  }

  // Content methods
  async getContent(id: number): Promise<Content | undefined> {
    const [content] = await db.select().from(contents).where(eq(contents.id, id));
    return content;
  }

  async getAllContents(): Promise<Content[]> {
    return await db.select().from(contents).orderBy(desc(contents.updatedAt));
  }

  async getContentsByType(type: string): Promise<Content[]> {
    return await db.select()
      .from(contents)
      .where(eq(contents.type, type as any))
      .orderBy(desc(contents.updatedAt));
  }
  
  async getContentsByUserId(userId: number): Promise<Content[]> {
    return await db.select()
      .from(contents)
      .where(eq(contents.userId, userId))
      .orderBy(desc(contents.updatedAt));
  }

  async createContent(content: InsertContent): Promise<Content> {
    const [newContent] = await db
      .insert(contents)
      .values({
        title: content.title,
        type: content.type,
        content: content.content,
        knowledgeLevel: content.knowledgeLevel,
        imageUrl: content.imageUrl || null,
        userId: content.userId || null,
        complexityScore: content.complexityScore || 50,
        optimized: content.optimized || false
      })
      .returning();
    
    // If userId provided, update learning progress
    if (content.userId) {
      const progress = await this.getLearningProgress(content.userId);
      
      if (progress) {
        // Update content creation stats
        const updates: Partial<LearningProgress> = {
          contentCreated: progress.contentCreated + 1,
          totalPoints: progress.totalPoints + 10, // Award points for content creation
        };
        
        // Update specific content type counts
        if (content.type === 'speech') {
          updates.speechCompleted = progress.speechCompleted + 1;
        } else if (content.type === 'slideshow') {
          updates.slideshowsCreated = progress.slideshowsCreated + 1;
        } else if (content.type === 'video') {
          updates.videosRecorded = progress.videosRecorded + 1;
        }
        
        await this.updateLearningProgress(content.userId, updates);
        
        // Check for achievement unlocks
        if (progress.contentCreated === 0) {
          // First content creation achievement
          await this.createAchievement({
            userId: content.userId,
            type: 'content_created',
            title: 'First Creation',
            description: 'Created your first educational content',
            pointsAwarded: 15,
            iconUrl: '/icons/achievements/first_content.svg'
          });
        } else if (progress.contentCreated === 4) { // This will be their 5th content
          // 5 content creation achievement
          await this.createAchievement({
            userId: content.userId,
            type: 'content_created',
            title: 'Content Creator',
            description: 'Created 5 pieces of educational content',
            pointsAwarded: 25,
            iconUrl: '/icons/achievements/content_creator.svg'
          });
        } else if (progress.contentCreated === 9) { // This will be their 10th content
          // 10 content creation achievement
          await this.createAchievement({
            userId: content.userId,
            type: 'content_created',
            title: 'Content Expert',
            description: 'Created 10 pieces of educational content',
            pointsAwarded: 50,
            iconUrl: '/icons/achievements/content_expert.svg'
          });
        }
        
        // Check content-type specific achievements
        await this.checkContentTypeAchievements(content.userId, progress, content.type);
      } else {
        // Initialize progress if not exists
        await this.createLearningProgress({
          userId: content.userId,
          totalPoints: 25, // Starting points + content creation
          level: 1,
          contentCreated: 1,
          speechCompleted: content.type === 'speech' ? 1 : 0,
          slideshowsCreated: content.type === 'slideshow' ? 1 : 0,
          videosRecorded: content.type === 'video' ? 1 : 0
        });
        
        // First content achievement
        await this.createAchievement({
          userId: content.userId,
          type: 'content_created',
          title: 'First Creation',
          description: 'Created your first educational content',
          pointsAwarded: 15,
          iconUrl: '/icons/achievements/first_content.svg'
        });
      }
    }
    
    return newContent;
  }

  async updateContent(id: number, contentUpdate: Partial<Content>): Promise<Content | undefined> {
    const [updatedContent] = await db
      .update(contents)
      .set({
        ...contentUpdate,
        updatedAt: new Date()
      })
      .where(eq(contents.id, id))
      .returning();
    return updatedContent;
  }

  async deleteContent(id: number): Promise<boolean> {
    const result = await db
      .delete(contents)
      .where(eq(contents.id, id))
      .returning({ id: contents.id });
    return result.length > 0;
  }

  // AI Feedback methods
  async getAIFeedback(id: number): Promise<AIFeedback | undefined> {
    const [feedback] = await db
      .select()
      .from(aiFeedbacks)
      .where(eq(aiFeedbacks.id, id));
    return feedback;
  }

  async getAIFeedbacksByContentId(contentId: number): Promise<AIFeedback[]> {
    return await db
      .select()
      .from(aiFeedbacks)
      .where(eq(aiFeedbacks.contentId, contentId))
      .orderBy(desc(aiFeedbacks.createdAt));
  }

  async createAIFeedback(feedback: InsertAIFeedback): Promise<AIFeedback> {
    const [newFeedback] = await db
      .insert(aiFeedbacks)
      .values(feedback)
      .returning();
    
    // Update user's learning progress with eye contact and speech clarity scores if feedback contains it
    if (feedback.contentId) {
      const content = await this.getContent(feedback.contentId);
      if (content && content.userId) {
        // Add achievement for receiving AI feedback
        const achievements = await this.getAchievements(content.userId);
        const hasFeedbackAchievement = achievements.some(a => a.type === 'ai_feedback_received');
        
        if (!hasFeedbackAchievement) {
          await this.createAchievement({
            userId: content.userId,
            type: 'ai_feedback_received',
            title: 'Feedback Explorer',
            description: 'Received your first AI feedback on content',
            pointsAwarded: 20,
            iconUrl: '/icons/achievements/feedback_explorer.svg'
          });
        }
      }
    }
    
    return newFeedback;
  }
  
  // Learning Progress operations
  async getLearningProgress(userId: number): Promise<LearningProgress | undefined> {
    const [progress] = await db
      .select()
      .from(learningProgress)
      .where(eq(learningProgress.userId, userId));
    
    return progress;
  }
  
  async createLearningProgress(progress: InsertLearningProgress): Promise<LearningProgress> {
    const [newProgress] = await db
      .insert(learningProgress)
      .values({
        ...progress,
        lastUpdated: new Date()
      })
      .returning();
    
    return newProgress;
  }
  
  async updateLearningProgress(userId: number, updates: Partial<LearningProgress>): Promise<LearningProgress | undefined> {
    const [updatedProgress] = await db
      .update(learningProgress)
      .set({
        ...updates,
        lastUpdated: new Date()
      })
      .where(eq(learningProgress.userId, userId))
      .returning();
    
    // Check if level up is needed
    if (updates.totalPoints && updatedProgress) {
      await this.checkForLevelUp(userId, updatedProgress);
    }
    
    return updatedProgress;
  }
  
  async incrementLearningPoints(userId: number, points: number): Promise<LearningProgress | undefined> {
    const progress = await this.getLearningProgress(userId);
    
    if (progress) {
      const updatedProgress = await this.updateLearningProgress(userId, {
        totalPoints: progress.totalPoints + points
      });
      
      return updatedProgress;
    }
    
    return undefined;
  }
  
  // Achievement operations
  async getAchievements(userId: number): Promise<Achievement[]> {
    return await db
      .select()
      .from(achievements)
      .where(eq(achievements.userId, userId))
      .orderBy(desc(achievements.dateEarned));
  }
  
  async getRecentAchievements(userId: number, limit: number): Promise<Achievement[]> {
    return await db
      .select()
      .from(achievements)
      .where(eq(achievements.userId, userId))
      .orderBy(desc(achievements.dateEarned))
      .limit(limit);
  }
  
  async createAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const [newAchievement] = await db
      .insert(achievements)
      .values(achievement)
      .returning();
    
    // Add points to user's learning progress
    if (achievement.pointsAwarded) {
      await this.incrementLearningPoints(achievement.userId, achievement.pointsAwarded);
    }
    
    return newAchievement;
  }
  
  // Learning Milestone operations
  async getLearningMilestones(): Promise<LearningMilestone[]> {
    return await db
      .select()
      .from(learningMilestones)
      .orderBy(learningMilestones.level);
  }
  
  async getLearningMilestone(level: number): Promise<LearningMilestone | undefined> {
    const [milestone] = await db
      .select()
      .from(learningMilestones)
      .where(eq(learningMilestones.level, level));
    
    return milestone;
  }
  
  async createLearningMilestone(milestone: InsertLearningMilestone): Promise<LearningMilestone> {
    const [newMilestone] = await db
      .insert(learningMilestones)
      .values(milestone)
      .returning();
    
    return newMilestone;
  }
  
  // User Stats operations
  async getUserStats(userId: number): Promise<{
    contentCount: number;
    speechCount: number;
    slideshowCount: number;
    videoCount: number;
    avgEyeContactScore: number;
    avgSpeechClarityScore: number;
    achievementCount: number;
  }> {
    // Get content counts by type
    const [contentStats] = await db
      .select({
        contentCount: count(),
        speechCount: count(sql`CASE WHEN ${contents.type} = 'speech' THEN 1 END`),
        slideshowCount: count(sql`CASE WHEN ${contents.type} = 'slideshow' THEN 1 END`),
        videoCount: count(sql`CASE WHEN ${contents.type} = 'video' THEN 1 END`)
      })
      .from(contents)
      .where(eq(contents.userId, userId));
    
    // Get achievement count
    const [achievementStats] = await db
      .select({
        achievementCount: count()
      })
      .from(achievements)
      .where(eq(achievements.userId, userId));
    
    // Get learning progress for scores
    const progress = await this.getLearningProgress(userId);
    
    return {
      contentCount: contentStats?.contentCount || 0,
      speechCount: contentStats?.speechCount || 0,
      slideshowCount: contentStats?.slideshowCount || 0,
      videoCount: contentStats?.videoCount || 0,
      avgEyeContactScore: progress?.avgEyeContactScore || 0,
      avgSpeechClarityScore: progress?.avgSpeechClarityScore || 0,
      achievementCount: achievementStats?.achievementCount || 0
    };
  }
  
  // Helper methods for achievements and progression
  private async checkContentTypeAchievements(userId: number, progress: LearningProgress, contentType: string): Promise<void> {
    const existingAchievements = await this.getAchievements(userId);
    
    // Check speech achievements
    if (contentType === 'speech') {
      if (progress.speechCompleted === 2) { // This will be their 3rd speech
        const hasAchievement = existingAchievements.some(a => a.title === 'Speech Writer');
        
        if (!hasAchievement) {
          await this.createAchievement({
            userId,
            type: 'speech_mastery',
            title: 'Speech Writer',
            description: 'Created 3 speech scripts',
            pointsAwarded: 20,
            iconUrl: '/icons/achievements/speech_writer.svg'
          });
        }
      } else if (progress.speechCompleted === 9) { // This will be their 10th speech
        const hasAchievement = existingAchievements.some(a => a.title === 'Speech Master');
        
        if (!hasAchievement) {
          await this.createAchievement({
            userId,
            type: 'speech_mastery',
            title: 'Speech Master',
            description: 'Created 10 speech scripts',
            pointsAwarded: 50,
            iconUrl: '/icons/achievements/speech_master.svg'
          });
        }
      }
    }
    
    // Check slideshow achievements
    if (contentType === 'slideshow') {
      if (progress.slideshowsCreated === 2) { // This will be their 3rd slideshow
        const hasAchievement = existingAchievements.some(a => a.title === 'Slideshow Creator');
        
        if (!hasAchievement) {
          await this.createAchievement({
            userId,
            type: 'slideshow_expert',
            title: 'Slideshow Creator',
            description: 'Created 3 slideshows',
            pointsAwarded: 20,
            iconUrl: '/icons/achievements/slideshow_creator.svg'
          });
        }
      } else if (progress.slideshowsCreated === 9) { // This will be their 10th slideshow
        const hasAchievement = existingAchievements.some(a => a.title === 'Slideshow Master');
        
        if (!hasAchievement) {
          await this.createAchievement({
            userId,
            type: 'slideshow_expert',
            title: 'Slideshow Master',
            description: 'Created 10 slideshows',
            pointsAwarded: 50,
            iconUrl: '/icons/achievements/slideshow_master.svg'
          });
        }
      }
    }
    
    // Check video achievements
    if (contentType === 'video') {
      if (progress.videosRecorded === 2) { // This will be their 3rd video
        const hasAchievement = existingAchievements.some(a => a.title === 'Video Presenter');
        
        if (!hasAchievement) {
          await this.createAchievement({
            userId,
            type: 'video_presenter',
            title: 'Video Presenter',
            description: 'Recorded 3 educational videos',
            pointsAwarded: 30,
            iconUrl: '/icons/achievements/video_presenter.svg'
          });
        }
      } else if (progress.videosRecorded === 9) { // This will be their 10th video
        const hasAchievement = existingAchievements.some(a => a.title === 'Video Master');
        
        if (!hasAchievement) {
          await this.createAchievement({
            userId,
            type: 'video_presenter',
            title: 'Video Master',
            description: 'Recorded 10 educational videos',
            pointsAwarded: 75,
            iconUrl: '/icons/achievements/video_master.svg'
          });
        }
      }
    }
    
    // Check for complete set achievement (at least 1 of each content type)
    if (progress.speechCompleted > 0 && progress.slideshowsCreated > 0 && progress.videosRecorded > 0) {
      const hasCompleteSetAchievement = existingAchievements.some(a => a.title === 'Content Trifecta');
      
      if (!hasCompleteSetAchievement) {
        await this.createAchievement({
          userId,
          type: 'content_series_completed',
          title: 'Content Trifecta',
          description: 'Created all three types of content: speech, slideshow, and video',
          pointsAwarded: 40,
          iconUrl: '/icons/achievements/content_trifecta.svg'
        });
      }
    }
  }
  
  private async checkForLevelUp(userId: number, progress: LearningProgress): Promise<void> {
    // Define level thresholds or get from database
    const levelThresholds = [
      { level: 2, points: 100, title: 'Content Novice' },
      { level: 3, points: 250, title: 'Content Enthusiast' },
      { level: 4, points: 500, title: 'Content Specialist' },
      { level: 5, points: 1000, title: 'Content Expert' },
      { level: 6, points: 2000, title: 'Content Master' },
      { level: 7, points: 3500, title: 'Content Virtuoso' },
      { level: 8, points: 5000, title: 'Content Legend' },
    ];
    
    // Find the highest level the user qualifies for
    let targetLevel = progress.level;
    
    for (const threshold of levelThresholds) {
      if (progress.totalPoints >= threshold.points && threshold.level > targetLevel) {
        targetLevel = threshold.level;
      }
    }
    
    // If user qualifies for a higher level
    if (targetLevel > progress.level) {
      // Update user's level
      await this.updateLearningProgress(userId, {
        level: targetLevel
      });
      
      // Find the threshold info for this level
      const levelInfo = levelThresholds.find(t => t.level === targetLevel);
      
      // Award level up achievement
      await this.createAchievement({
        userId,
        type: 'knowledge_level_up',
        title: `Level ${targetLevel}: ${levelInfo?.title || 'Level Up'}`,
        description: `Advanced to level ${targetLevel}`,
        pointsAwarded: 30 * (targetLevel - progress.level), // More points for bigger jumps
        iconUrl: `/icons/achievements/level_${targetLevel}.svg`
      });
    }
  }
}

// Replace in-memory storage with database storage
export const storage = new DatabaseStorage();
