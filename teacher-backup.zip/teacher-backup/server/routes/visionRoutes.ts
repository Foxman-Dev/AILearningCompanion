import { Request, Response, Router } from 'express';
import { analyzeFace } from '../services/visionService';

const router = Router();

/**
 * Endpoint for analyzing facial expressions and eye contact using Google Cloud Vision
 * @route POST /api/vision/analyze-face
 * @body { image: string } - Base64 encoded image (without the data:image/jpeg;base64, prefix)
 * @returns Analysis of eye contact and facial expressions
 */
router.post('/analyze-face', async (req: Request, res: Response) => {
  try {
    const { image } = req.body;
    
    if (!image) {
      return res.status(400).json({ 
        success: false, 
        error: 'Image data is required' 
      });
    }
    
    // Remove data URL prefix if present
    let imageBase64 = image;
    if (image.startsWith('data:')) {
      const parts = image.split(',');
      if (parts.length > 1) {
        imageBase64 = parts[1];
      }
    }
    
    const analysis = await analyzeFace(imageBase64);
    
    res.json({
      success: true,
      data: analysis
    });
    
  } catch (error: any) {
    console.error('Error in analyze-face endpoint:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message || 'Error analyzing face'
    });
  }
});

export default router;