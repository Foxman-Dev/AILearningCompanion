import { useState, useRef, useEffect, useCallback } from "react";
import Webcam from "react-webcam";
import * as tf from "@tensorflow/tfjs";
import * as faceLandmarksDetection from "@tensorflow-models/face-landmarks-detection";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Video, 
  Pause, 
  Play, 
  StopCircle, 
  Camera, 
  RefreshCw,
  Eye,
  AlertTriangle
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface VideoRecorderProps {
  onRecordingComplete: (videoBlob: Blob, eyeContactScore: number) => void;
}

export default function VideoRecorder({ onRecordingComplete }: VideoRecorderProps) {
  const webcamRef = useRef<Webcam>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordedChunks, setRecordedChunks] = useState<Blob[]>([]);
  const [recordingTime, setRecordingTime] = useState(0);
  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");
  const [detector, setDetector] = useState<any>(null);
  const [eyeContactMetrics, setEyeContactMetrics] = useState<number[]>([]);
  const [eyeContactScore, setEyeContactScore] = useState(0);
  const [isModelLoading, setIsModelLoading] = useState(true);
  const [isFaceDetected, setIsFaceDetected] = useState(false);
  const requestAnimationRef = useRef<number>();
  const eyeContactIntervalRef = useRef<NodeJS.Timeout>();
  const { toast } = useToast();

  // Load TensorFlow.js and face landmarks model
  useEffect(() => {
    async function loadModel() {
      try {
        // Make sure TensorFlow.js is initialized
        await tf.ready();
        
        // Load the face landmarks detection model
        const model = faceLandmarksDetection.SupportedModels.MediaPipeFaceMesh;
        const detectorConfig = {
          runtime: 'mediapipe',
          solutionPath: 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh',
          maxFaces: 1
        };
        
        const faceDetector = await faceLandmarksDetection.createDetector(
          model, 
          detectorConfig as any
        );
        
        setDetector(faceDetector);
        setIsModelLoading(false);
        
        toast({
          title: "Face detection initialized",
          description: "Eye contact tracking is now active."
        });
      } catch (error) {
        console.error("Error loading facial recognition model:", error);
        toast({
          title: "Face detection failed",
          description: "Could not initialize eye contact tracking.",
          variant: "destructive"
        });
        setIsModelLoading(false);
      }
    }
    
    loadModel();
    
    return () => {
      if (requestAnimationRef.current) {
        cancelAnimationFrame(requestAnimationRef.current);
      }
      if (eyeContactIntervalRef.current) {
        clearInterval(eyeContactIntervalRef.current);
      }
    };
  }, [toast]);

  // Track recording time
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRecording && !isPaused) {
      interval = setInterval(() => {
        setRecordingTime((prevTime) => prevTime + 1);
      }, 1000);
    }
    
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isRecording, isPaused]);

  // Format seconds to mm:ss
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // Detect eye contact
  const detectEyeContact = useCallback(async () => {
    if (!detector || !webcamRef.current || !webcamRef.current.video || !isRecording) return;
    
    const video = webcamRef.current.video;
    
    if (video.readyState === 4) {
      try {
        // Get face landmarks
        const faces = await detector.estimateFaces(video);
        
        if (faces && faces.length > 0) {
          setIsFaceDetected(true);
          
          // Extract eye landmarks
          const face = faces[0];
          const leftEye = face.keypoints.filter((kp: any) => kp.name && kp.name.includes('leftEye'));
          const rightEye = face.keypoints.filter((kp: any) => kp.name && kp.name.includes('rightEye'));
          
          // Calculate eye attention metrics (simplified)
          // In a real application, you would use more sophisticated calculations
          const eyeOpenness = calculateEyeOpenness(leftEye, rightEye);
          const lookingAtCamera = isLookingAtCamera(face);
          
          // Score from 0-1, where 1 is perfect eye contact
          let contactScore = eyeOpenness * 0.5 + (lookingAtCamera ? 0.5 : 0);
          
          // Add to metrics array
          setEyeContactMetrics(prevMetrics => {
            const newMetrics = [...prevMetrics, contactScore];
            // Only keep last 30 frames for real-time display
            if (newMetrics.length > 30) {
              return newMetrics.slice(newMetrics.length - 30);
            }
            return newMetrics;
          });
          
          // Update overall score (average of all metrics)
          if (eyeContactMetrics.length > 0) {
            const averageScore = eyeContactMetrics.reduce((sum, score) => sum + score, 0) / eyeContactMetrics.length;
            setEyeContactScore(averageScore);
          }
        } else {
          setIsFaceDetected(false);
        }
      } catch (error) {
        console.error("Error detecting face:", error);
      }
    }
    
    // Continue detection loop
    requestAnimationRef.current = requestAnimationFrame(detectEyeContact);
  }, [detector, isRecording, eyeContactMetrics]);

  // Start eye contact detection when recording
  useEffect(() => {
    if (isRecording && detector && !isPaused) {
      detectEyeContact();
    } else if (requestAnimationRef.current) {
      cancelAnimationFrame(requestAnimationRef.current);
    }
    
    return () => {
      if (requestAnimationRef.current) {
        cancelAnimationFrame(requestAnimationRef.current);
      }
    };
  }, [isRecording, detector, isPaused, detectEyeContact]);

  // Calculate eye openness (simplified)
  const calculateEyeOpenness = (leftEye: any[], rightEye: any[]) => {
    // This is a simplified measure - in production you'd use proper measurements
    // between upper and lower eyelids
    return leftEye.length > 0 && rightEye.length > 0 ? 0.8 : 0.3;
  };

  // Check if looking at camera (simplified)
  const isLookingAtCamera = (face: any) => {
    // In production, you would calculate where the eyes are looking based on
    // the position of the iris relative to the eye corners
    // This is a placeholder implementation
    const rotation = face.box.yaw || 0;
    // Consider "looking at camera" if face rotation is minimal
    return Math.abs(rotation) < 0.3;
  };

  // Handle recording actions
  const handleStartRecording = useCallback(() => {
    if (!webcamRef.current || !webcamRef.current.video) return;
    
    setRecordedChunks([]);
    setRecordingTime(0);
    setEyeContactMetrics([]);
    setEyeContactScore(0);
    
    const stream = webcamRef.current.video.srcObject as MediaStream;
    const mediaRecorder = new MediaRecorder(stream, {
      mimeType: "video/webm",
    });
    
    mediaRecorder.addEventListener("dataavailable", ({ data }) => {
      if (data.size > 0) {
        setRecordedChunks((prev) => [...prev, data]);
      }
    });
    
    mediaRecorderRef.current = mediaRecorder;
    mediaRecorder.start();
    setIsRecording(true);
    setIsPaused(false);
  }, []);

  const handleStopRecording = useCallback(() => {
    if (!mediaRecorderRef.current) return;
    
    mediaRecorderRef.current.stop();
    setIsRecording(false);
    setIsPaused(false);
    
    // Cancel the animation frame to stop face detection
    if (requestAnimationRef.current) {
      cancelAnimationFrame(requestAnimationRef.current);
    }
    
    setTimeout(() => {
      if (recordedChunks.length) {
        const blob = new Blob(recordedChunks, {
          type: "video/webm",
        });
        onRecordingComplete(blob, eyeContactScore);
      }
    }, 1000);
  }, [recordedChunks, onRecordingComplete, eyeContactScore]);

  const handlePauseResumeRecording = useCallback(() => {
    if (!mediaRecorderRef.current) return;
    
    if (isPaused) {
      // Resume recording
      mediaRecorderRef.current.resume();
      setIsPaused(false);
    } else {
      // Pause recording
      mediaRecorderRef.current.pause();
      setIsPaused(true);
    }
  }, [isPaused]);

  const handleSwitchCamera = useCallback(() => {
    setFacingMode((prevMode) => 
      prevMode === "user" ? "environment" : "user"
    );
  }, []);

  return (
    <div className="relative">
      <Card className="p-4">
        <div className="mb-4 relative">
          <Webcam
            audio={true}
            ref={webcamRef}
            videoConstraints={{
              facingMode,
              width: 640,
              height: 480,
            }}
            className="w-full rounded-lg"
          />
          
          {isModelLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-60 rounded-lg">
              <div className="text-center text-white p-4">
                <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-2" />
                <p>Loading face detection model...</p>
              </div>
            </div>
          )}
          
          {isRecording && !isFaceDetected && (
            <div className="absolute top-2 right-2">
              <Badge variant="destructive" className="flex items-center">
                <AlertTriangle className="mr-1 h-4 w-4" />
                Face not detected
              </Badge>
            </div>
          )}
          
          {isRecording && isFaceDetected && (
            <div className="absolute top-2 right-2">
              <Badge variant="success" className="flex items-center bg-success text-white">
                <Eye className="mr-1 h-4 w-4" />
                Eye contact: {Math.round(eyeContactScore * 100)}%
              </Badge>
            </div>
          )}
          
          {/* Recording indicator */}
          {isRecording && (
            <div className="absolute top-2 left-2 flex items-center">
              <div className={`h-3 w-3 rounded-full ${isPaused ? 'bg-warning' : 'bg-error animate-pulse'} mr-2`}></div>
              <span className="text-sm font-medium text-white bg-black bg-opacity-50 px-2 py-1 rounded">
                {formatTime(recordingTime)}
              </span>
            </div>
          )}
        </div>
        
        <div className="flex flex-col space-y-3">
          {/* Eye contact indicator */}
          {isRecording && (
            <div className="w-full">
              <div className="flex justify-between text-sm mb-1">
                <span>Eye Contact Quality</span>
                <span>{Math.round(eyeContactScore * 100)}%</span>
              </div>
              <Progress value={eyeContactScore * 100} className="h-2" />
            </div>
          )}
          
          <div className="flex justify-between">
            <Button 
              variant="outline" 
              size="icon"
              onClick={handleSwitchCamera}
              disabled={isRecording}
            >
              <Camera className="h-4 w-4" />
            </Button>
            
            {!isRecording ? (
              <Button 
                variant="default" 
                className="bg-primary text-white px-4"
                onClick={handleStartRecording}
                disabled={isModelLoading}
              >
                <Video className="mr-2 h-4 w-4" /> 
                Start Recording
              </Button>
            ) : (
              <div className="space-x-2">
                <Button 
                  variant={isPaused ? "default" : "outline"} 
                  size="icon"
                  onClick={handlePauseResumeRecording}
                >
                  {isPaused ? (
                    <Play className="h-4 w-4" />
                  ) : (
                    <Pause className="h-4 w-4" />
                  )}
                </Button>
                
                <Button 
                  variant="destructive" 
                  onClick={handleStopRecording}
                >
                  <StopCircle className="mr-2 h-4 w-4" />
                  Stop
                </Button>
              </div>
            )}
          </div>
        </div>
      </Card>
      
      {/* Instructions */}
      <div className="mt-4 text-sm text-neutral-300">
        <p className="font-medium mb-2">Tips for better eye contact:</p>
        <ul className="list-disc list-inside space-y-1">
          <li>Look directly at the camera, not at your screen</li>
          <li>Position your camera at eye level</li>
          <li>Maintain a neutral head position</li>
          <li>Try to blink naturally</li>
        </ul>
      </div>
    </div>
  );
}