import { Button } from "@/components/ui/button";
import { 
  Brain, 
  Wand2,
} from "lucide-react";
import { AIFeedback } from "@/lib/openai";

interface AIAssistantProps {
  feedback: AIFeedback | null;
  isLoading: boolean;
  onApplySuggestions: () => void;
}

export default function AIAssistant({ 
  feedback, 
  isLoading,
  onApplySuggestions 
}: AIAssistantProps) {
  if (isLoading) {
    return (
      <div className="bg-neutral-100 p-4 rounded-lg">
        <h3 className="font-heading font-medium text-lg mb-4 flex items-center text-neutral-400">
          <Brain className="mr-2 h-5 w-5" /> AI Assistant
        </h3>
        <div className="bg-white rounded-lg p-4 animate-pulse h-52"></div>
      </div>
    );
  }

  if (!feedback) {
    return (
      <div className="bg-neutral-100 p-4 rounded-lg">
        <h3 className="font-heading font-medium text-lg mb-4 flex items-center text-neutral-400">
          <Brain className="mr-2 h-5 w-5" /> AI Assistant
        </h3>
        <div className="bg-white rounded-lg p-4 text-center">
          <p className="text-neutral-300">Click "Analyze with AI" to get feedback on your content.</p>
        </div>
      </div>
    );
  }

  const getComplexityColor = () => {
    const { level } = feedback.complexity;
    if (level === 'low') return 'border-success';
    if (level === 'moderate') return 'border-warning';
    return 'border-error';
  };

  return (
    <div className="bg-neutral-100 p-4 rounded-lg">
      <h3 className="font-heading font-medium text-lg mb-4 flex items-center text-neutral-400">
        <Brain className="mr-2 h-5 w-5" /> AI Assistant
      </h3>
      
      <div className={`bg-white rounded-lg p-4 mb-4 border-l-4 ${getComplexityColor()}`}>
        <h4 className={`font-medium mb-2 ${feedback.complexity.level === 'low' ? 'text-success' : feedback.complexity.level === 'moderate' ? 'text-warning' : 'text-error'}`}>
          Content Complexity
        </h4>
        <p className="text-sm text-neutral-300 mb-3">
          {feedback.complexity.level === 'low' 
            ? "This content is appropriate for beginners." 
            : feedback.complexity.level === 'moderate'
              ? "This content may be difficult for beginners to understand."
              : "This content is too complex for the target audience."}
        </p>
        <div className="knowledge-indicator bg-neutral-200 mb-3 h-3 rounded-full overflow-hidden">
          <div 
            className={`h-full ${feedback.complexity.level === 'low' ? 'bg-success' : feedback.complexity.level === 'moderate' ? 'bg-warning' : 'bg-error'}`} 
            style={{ width: `${feedback.complexity.score * 100}%` }}
          ></div>
        </div>
        <div className="text-sm">
          <strong className="text-neutral-400">Suggestion:</strong> 
          <span className="text-neutral-300">{feedback.complexity.suggestion}</span>
        </div>
      </div>
      
      {feedback.visualOpportunity && (
        <div className="bg-white rounded-lg p-4 mb-4 border-l-4 border-success">
          <h4 className="font-medium mb-2 text-success">Visual Opportunity</h4>
          <p className="text-sm text-neutral-300 mb-2">Adding a visual would improve comprehension.</p>
          <div className="text-sm">
            <strong className="text-neutral-400">Suggestion:</strong> 
            <span className="text-neutral-300">{feedback.visualOpportunity.suggestion}</span>
          </div>
        </div>
      )}
      
      <div className="bg-white rounded-lg p-4 border-l-4 border-primary">
        <h4 className="font-medium mb-2 text-primary">Learning Enhancement</h4>
        <p className="text-sm text-neutral-300 mb-2">Consider adding more context or examples.</p>
        <div className="text-sm">
          <strong className="text-neutral-400">Suggestion:</strong> 
          <span className="text-neutral-300">{feedback.learningEnhancement.suggestion}</span>
        </div>
      </div>
      
      <Button 
        className="w-full mt-4 bg-primary text-white hover:bg-primary-dark"
        onClick={onApplySuggestions}
      >
        <Wand2 className="mr-1 h-4 w-4" /> Apply AI Suggestions
      </Button>
    </div>
  );
}
