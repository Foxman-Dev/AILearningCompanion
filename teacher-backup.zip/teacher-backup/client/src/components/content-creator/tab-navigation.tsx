import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface TabNavigationProps {
  activeTab: 'slideshow' | 'video' | 'speech';
  onTabChange: (tab: 'slideshow' | 'video' | 'speech') => void;
}

export default function TabNavigation({ activeTab, onTabChange }: TabNavigationProps) {
  return (
    <div className="border-b border-neutral-200 mb-6">
      <Tabs value={activeTab} onValueChange={(value) => onTabChange(value as any)}>
        <TabsList className="-mb-px">
          <TabsTrigger
            value="slideshow"
            className={`p-4 ${activeTab === 'slideshow' ? 'border-b-2 border-primary text-primary' : 'border-b-2 border-transparent hover:text-primary hover:border-primary-light text-neutral-300'}`}
          >
            Slideshow
          </TabsTrigger>
          <TabsTrigger
            value="video"
            className={`p-4 ${activeTab === 'video' ? 'border-b-2 border-primary text-primary' : 'border-b-2 border-transparent hover:text-primary hover:border-primary-light text-neutral-300'}`}
          >
            Video Course
          </TabsTrigger>
          <TabsTrigger
            value="speech"
            className={`p-4 ${activeTab === 'speech' ? 'border-b-2 border-primary text-primary' : 'border-b-2 border-transparent hover:text-primary hover:border-primary-light text-neutral-300'}`}
          >
            Speech
          </TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  );
}
