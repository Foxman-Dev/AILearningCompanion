import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Bold,
  Italic,
  List,
  Image,
  ArrowLeft,
  ArrowRight,
  Save,
  Sparkles,
  Wand
} from "lucide-react";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { analyzeContent } from "@/lib/openai";
import SpeechGenerator from "../content-creation/speech-generator";

interface ContentEditorProps {
  contentType: 'video' | 'slideshow' | 'speech';
  onAnalyzeContent: (content: string, knowledgeLevel: 'beginner' | 'intermediate' | 'advanced') => Promise<void>;
}

export default function ContentEditor({ contentType, onAnalyzeContent }: ContentEditorProps) {
  const [title, setTitle] = useState("Introduction to Sustainable Energy");
  const [content, setContent] = useState(`# Sustainable Energy Sources

- **Solar Energy**: Conversion of sunlight into electricity
- **Wind Energy**: Harnessing wind power through turbines
- **Hydroelectric Power**: Energy generated from flowing water
- **Geothermal Energy**: Heat from the earth's core
- **Biomass**: Organic material burned for energy production

These renewable sources offer alternatives to fossil fuels and help reduce carbon emissions and climate change impacts.`);
  
  const [knowledgeLevel, setKnowledgeLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('beginner');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [editorTab, setEditorTab] = useState<'manual' | 'aiGenerated'>(contentType === 'speech' ? 'aiGenerated' : 'manual');
  const { toast } = useToast();

  const handleAnalyzeContent = async () => {
    if (!content.trim()) {
      toast({
        title: "Content is empty",
        description: "Please add some content before analyzing.",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    try {
      await onAnalyzeContent(content, knowledgeLevel);
      toast({
        title: "Analysis complete",
        description: "Your content has been analyzed successfully.",
      });
    } catch (error) {
      toast({
        title: "Analysis failed",
        description: "There was an error analyzing your content.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const formatText = (format: string) => {
    // This would be implemented with a real text editor
    // Currently just a placeholder
    console.log(`Formatting text with ${format}`);
  };

  const handleSpeechGenerated = (generatedSpeech: string) => {
    setContent(generatedSpeech);
    setEditorTab('manual');
    toast({
      title: "Speech generated",
      description: "AI-generated speech has been added to the editor. You can now edit or analyze it.",
    });
  };

  return (
    <div className="lg:col-span-2">
      <div className="mb-4">
        <label htmlFor="title" className="block text-neutral-400 text-sm font-medium mb-2">
          Title
        </label>
        <Input
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full p-2 border border-neutral-200 rounded focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
        />
      </div>
      
      <div className="mb-4">
        <label className="block text-neutral-400 text-sm font-medium mb-2">
          Target Knowledge Level
        </label>
        <ToggleGroup type="single" value={knowledgeLevel} onValueChange={(value) => value && setKnowledgeLevel(value as any)}>
          <ToggleGroupItem value="beginner" aria-label="Beginner" className={knowledgeLevel === 'beginner' ? "bg-primary text-white" : ""}>
            Beginner
          </ToggleGroupItem>
          <ToggleGroupItem value="intermediate" aria-label="Intermediate" className={knowledgeLevel === 'intermediate' ? "bg-primary text-white" : ""}>
            Intermediate
          </ToggleGroupItem>
          <ToggleGroupItem value="advanced" aria-label="Advanced" className={knowledgeLevel === 'advanced' ? "bg-primary text-white" : ""}>
            Advanced
          </ToggleGroupItem>
        </ToggleGroup>
      </div>
      
      {contentType === 'speech' ? (
        <Tabs value={editorTab} onValueChange={(value) => setEditorTab(value as 'manual' | 'aiGenerated')} className="mb-4">
          <TabsList className="mb-4">
            <TabsTrigger value="manual" className="flex items-center">
              <Wand className="h-4 w-4 mr-2" />
              Manual Editor
            </TabsTrigger>
            <TabsTrigger value="aiGenerated" className="flex items-center">
              <Sparkles className="h-4 w-4 mr-2" />
              AI Speech Generator
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="manual">
            <div className="mb-4">
              <label htmlFor="speechContent" className="block text-neutral-400 text-sm font-medium mb-2">
                Speech Content
              </label>
              <div className="border border-neutral-200 rounded bg-white">
                <div className="border-b border-neutral-200 p-2 bg-neutral-100 flex">
                  <Button variant="ghost" size="sm" className="p-1 mr-1 hover:bg-neutral-200 rounded" onClick={() => formatText('bold')}>
                    <Bold className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="p-1 mr-1 hover:bg-neutral-200 rounded" onClick={() => formatText('italic')}>
                    <Italic className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="p-1 mr-1 hover:bg-neutral-200 rounded" onClick={() => formatText('list')}>
                    <List className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="p-1 mr-1 hover:bg-neutral-200 rounded" onClick={() => formatText('image')}>
                    <Image className="h-4 w-4" />
                  </Button>
                </div>
                <Textarea
                  id="speechContent"
                  rows={10}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full p-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                />
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="aiGenerated">
            <SpeechGenerator onSpeechGenerated={handleSpeechGenerated} />
          </TabsContent>
        </Tabs>
      ) : (
        <div className="mb-4">
          <label htmlFor="contentArea" className="block text-neutral-400 text-sm font-medium mb-2">
            {contentType === 'slideshow' ? 'Slide Content' : 'Video Script'}
          </label>
          <div className="border border-neutral-200 rounded bg-white">
            <div className="border-b border-neutral-200 p-2 bg-neutral-100 flex">
              <Button variant="ghost" size="sm" className="p-1 mr-1 hover:bg-neutral-200 rounded" onClick={() => formatText('bold')}>
                <Bold className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" className="p-1 mr-1 hover:bg-neutral-200 rounded" onClick={() => formatText('italic')}>
                <Italic className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" className="p-1 mr-1 hover:bg-neutral-200 rounded" onClick={() => formatText('list')}>
                <List className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" className="p-1 mr-1 hover:bg-neutral-200 rounded" onClick={() => formatText('image')}>
                <Image className="h-4 w-4" />
              </Button>
            </div>
            <Textarea
              id="contentArea"
              rows={10}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full p-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            />
          </div>
        </div>
      )}
      
      <div className="flex justify-between">
        <div className="flex">
          <Button variant="outline" className="flex items-center mr-2" disabled={contentType === 'slideshow' && true}>
            <ArrowLeft className="mr-1 h-4 w-4" /> Previous
          </Button>
          <Button variant="outline" className="flex items-center" disabled={contentType === 'slideshow' && true}>
            Next <ArrowRight className="ml-1 h-4 w-4" />
          </Button>
        </div>
        <div>
          <Button variant="default" className="bg-primary text-white hover:bg-primary-dark mr-2">
            <Save className="mr-1 h-4 w-4" /> Save
          </Button>
          <Button 
            variant="default" 
            className="bg-success text-white hover:opacity-90"
            onClick={handleAnalyzeContent}
            disabled={isAnalyzing || (contentType === 'speech' && editorTab === 'aiGenerated')}
          >
            {isAnalyzing ? "Analyzing..." : "Analyze with AI"}
          </Button>
        </div>
      </div>
    </div>
  );
}
