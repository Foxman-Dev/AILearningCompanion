import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Plus } from "lucide-react";
import { Link } from "wouter";

interface QuickActionCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  buttonText: string;
  href: string;
}

export default function QuickActionCard({
  title,
  description,
  icon,
  buttonText,
  href
}: QuickActionCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          <div className="text-primary text-3xl mr-3">{icon}</div>
          <h3 className="font-heading font-medium text-lg">{title}</h3>
        </div>
        <p className="text-neutral-300 mb-4">{description}</p>
        <Link href={href}>
          <Button className="bg-primary text-white hover:bg-primary-dark transition-colors">
            <Plus className="mr-1 h-4 w-4" /> {buttonText}
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
