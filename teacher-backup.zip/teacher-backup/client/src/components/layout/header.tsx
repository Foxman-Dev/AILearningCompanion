import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  HelpCircle,
  Bell,
  School,
} from "lucide-react";

export default function Header() {
  return (
    <header className="bg-primary text-white p-4 shadow-md z-10">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center">
          <School className="mr-2 h-6 w-6" />
          <h1 className="font-heading text-xl font-semibold">EduGenius AI</h1>
        </div>
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" className="rounded-full hover:bg-primary-dark transition-colors">
            <HelpCircle className="h-5 w-5" />
            <span className="sr-only">Help</span>
          </Button>
          <Button variant="ghost" size="icon" className="rounded-full hover:bg-primary-dark transition-colors">
            <Bell className="h-5 w-5" />
            <span className="sr-only">Notifications</span>
          </Button>
          <Avatar className="h-8 w-8 border-2 border-white">
            <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100" alt="User profile" />
            <AvatarFallback>TE</AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
}
