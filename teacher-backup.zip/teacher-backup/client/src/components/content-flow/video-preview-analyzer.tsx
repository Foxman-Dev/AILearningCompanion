import { useState, useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import * as tf from "@tensorflow/tfjs";
import * as faceLandmarksDetection from "@tensorflow-models/face-landmarks-detection";
import { apiRequest } from "@/lib/queryClient";
import FacialExpressionReport from "../content-analysis/facial-expression-report";
import {
  Eye,
  Smile,
  Timer,
  RefreshCw,
  Volume2,
  Maximize2,
  CheckCircle,
  X,
  Sparkles,
  BarChart3
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface VideoPreviewAnalyzerProps {
  videoUrl: string;
  onClose: () => void;
  learningLevel: 'beginner' | 'intermediate' | 'advanced';
}

export default function VideoPreviewAnalyzer({
  videoUrl,
  onClose,
  learningLevel
}: VideoPreviewAnalyzerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [detectorLoaded, setDetectorLoaded] = useState(false);
  const [detector, setDetector] = useState<any>(null);
  const [isModelLoading, setIsModelLoading] = useState(true);
  const [analysisFrameCount, setAnalysisFrameCount] = useState(0);
  const requestAnimationRef = useRef<number>();
  const { toast } = useToast();
  
  // Tutorial metrics
  const [metrics, setMetrics] = useState({
    eyeContact: 0,
    facialExpressions: 0,
    speechClarity: 0,
    pacing: 0,
    enthusiasm: 0,
    slideAlignment: 0,
    gestures: 0,
    overallScore: 0,
    eyeContactScore: 0,
    // Detailed facial expression data from Google Cloud Vision
    facialExpressionsData: {
      joy: 0.5,
      sorrow: 0.1,
      anger: 0.1,
      surprise: 0.3
    }
  });
  
  // Google Cloud Vision analysis state
  const [useGoogleVision, setUseGoogleVision] = useState(true);
  const [visionAnalysisRunning, setVisionAnalysisRunning] = useState(false);
  const [captureFrameInterval, setCaptureFrameInterval] = useState<NodeJS.Timeout | null>(null);
  
  // Analysis progress (0-100)
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [analysisComplete, setAnalysisComplete] = useState(false);

  // Load TensorFlow and face model
  useEffect(() => {
    async function loadModel() {
      try {
        await tf.ready();
        
        const model = faceLandmarksDetection.SupportedModels.MediaPipeFaceMesh;
        const detectorConfig = {
          runtime: 'mediapipe',
          solutionPath: 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh',
          maxFaces: 1
        };
        
        const faceDetector = await faceLandmarksDetection.createDetector(
          model, 
          detectorConfig as any
        );
        
        setDetector(faceDetector);
        setIsModelLoading(false);
        setDetectorLoaded(true);
        
        toast({
          title: "Analysis ready",
          description: "Face detection model loaded. Start playback to analyze."
        });
      } catch (error) {
        console.error("Error loading facial recognition model:", error);
        toast({
          title: "Analysis limited",
          description: "Face detection couldn't be initialized. Limited analysis available.",
          variant: "destructive"
        });
        setIsModelLoading(false);
      }
    }
    
    loadModel();
    
    return () => {
      if (requestAnimationRef.current) {
        cancelAnimationFrame(requestAnimationRef.current);
      }
    };
  }, [toast]);

  // Analyze video frames
  const analyzeVideoFrame = async () => {
    if (!detector || !videoRef.current || !canvasRef.current || !isAnalyzing) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx || video.paused || video.ended) return;
    
    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw current video frame to canvas
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    try {
      // Only analyze every 15 frames to improve performance
      if (analysisFrameCount % 15 === 0) {
        const faces = await detector.estimateFaces(video);
        
        if (faces && faces.length > 0) {
          const face = faces[0];
          
          // Draw face detection rectangle
          const box = face.box;
          ctx.strokeStyle = 'rgba(0, 255, 0, 0.8)';
          ctx.lineWidth = 2;
          ctx.strokeRect(box.xMin, box.yMin, box.width, box.height);
          
          // Draw eye contact indicator
          const lookingAtCamera = isLookingAtCamera(face);
          ctx.fillStyle = lookingAtCamera ? 'rgba(0, 255, 0, 0.6)' : 'rgba(255, 0, 0, 0.6)';
          ctx.font = '16px Arial';
          ctx.fillText(
            lookingAtCamera ? 'Good eye contact' : 'Look at camera', 
            box.xMin, 
            box.yMin - 10
          );
          
          // Update metrics
          updateMetrics(face, video);
        }
      }
      
      // Update analysis progress based on video position
      const progress = (video.currentTime / video.duration) * 100;
      setAnalysisProgress(progress);
      
      // Handle analysis completion
      if (progress > 99 && !analysisComplete) {
        setAnalysisComplete(true);
        finalizeAnalysis();
      }
      
      setAnalysisFrameCount(prev => prev + 1);
    } catch (error) {
      console.error("Error analyzing video frame:", error);
    }
    
    // Continue analysis loop
    requestAnimationRef.current = requestAnimationFrame(analyzeVideoFrame);
  };

  // Start/stop analysis based on video playback
  useEffect(() => {
    if (videoRef.current && detectorLoaded) {
      const video = videoRef.current;
      
      const handlePlay = () => {
        setIsAnalyzing(true);
        if (requestAnimationRef.current) {
          cancelAnimationFrame(requestAnimationRef.current);
        }
        analyzeVideoFrame();
        
        // Set up interval to capture frames for Google Cloud Vision analysis
        if (useGoogleVision && !captureFrameInterval) {
          const interval = setInterval(() => {
            if (video.paused || video.ended) return;
            captureFrameForVisionAnalysis();
          }, 5000); // Capture a frame every 5 seconds to avoid too many API calls
          
          setCaptureFrameInterval(interval);
        }
      };
      
      const handlePause = () => {
        setIsAnalyzing(false);
        if (requestAnimationRef.current) {
          cancelAnimationFrame(requestAnimationRef.current);
        }
        
        // Clear capture interval when video is paused
        if (captureFrameInterval) {
          clearInterval(captureFrameInterval);
          setCaptureFrameInterval(null);
        }
      };
      
      const handleEnded = () => {
        setIsAnalyzing(false);
        setAnalysisComplete(true);
        finalizeAnalysis();
        if (requestAnimationRef.current) {
          cancelAnimationFrame(requestAnimationRef.current);
        }
        
        // Clear capture interval when video ends
        if (captureFrameInterval) {
          clearInterval(captureFrameInterval);
          setCaptureFrameInterval(null);
        }
      };
      
      // Setup event listeners
      video.addEventListener('play', handlePlay);
      video.addEventListener('pause', handlePause);
      video.addEventListener('ended', handleEnded);
      
      return () => {
        video.removeEventListener('play', handlePlay);
        video.removeEventListener('pause', handlePause);
        video.removeEventListener('ended', handleEnded);
        if (requestAnimationRef.current) {
          cancelAnimationFrame(requestAnimationRef.current);
        }
        
        // Clear interval on unmount
        if (captureFrameInterval) {
          clearInterval(captureFrameInterval);
          setCaptureFrameInterval(null);
        }
      };
    }
  }, [detectorLoaded, useGoogleVision, captureFrameInterval]);

  // Check if looking at camera (simplified)
  const isLookingAtCamera = (face: any) => {
    const rotation = face.box.yaw || 0;
    return Math.abs(rotation) < 0.3;
  };

  // Capture frame for Google Cloud Vision analysis
  const captureFrameForVisionAnalysis = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx || video.paused || video.ended) return;
    
    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw current video frame to canvas
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    try {
      // Convert canvas to base64 for API request (without data:image/jpeg;base64, prefix)
      const imageBase64 = canvas.toDataURL('image/jpeg').split(',')[1];
      
      // Send to Google Cloud Vision API
      const response = await apiRequest('/api/vision/analyze-face', {
        method: 'POST',
        body: JSON.stringify({ image: imageBase64 }),
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (response && response.faceDetected) {
        // Update metrics with Google Cloud Vision analysis results
        setMetrics(prev => ({
          ...prev,
          eyeContactScore: response.eyeContact.score / 100,
          facialExpressionsData: {
            joy: response.facialExpression.joy / 100,
            sorrow: response.facialExpression.sorrow / 100,
            anger: response.facialExpression.anger / 100,
            surprise: response.facialExpression.surprise / 100
          }
        }));
      }
    } catch (error) {
      console.error('Error analyzing face with Google Cloud Vision:', error);
    }
  };

  // Update metrics based on analysis
  const updateMetrics = (face: any, video: HTMLVideoElement) => {
    // Eye contact calculation
    const lookingAtCamera = isLookingAtCamera(face);
    const newEyeContact = lookingAtCamera ? 
      Math.min(1, metrics.eyeContact + 0.02) : 
      Math.max(0, metrics.eyeContact - 0.02);
    
    // Save eye contact score for facial expression report
    const eyeContactScore = newEyeContact;
    
    // Facial expressions (simplified simulation)
    const expressiveness = Math.random() * 0.3 + 0.6; // Random value between 0.6 and 0.9
    const newFacialExpressions = (metrics.facialExpressions * 0.95) + (expressiveness * 0.05);
    
    // Speech clarity (simplified simulation)
    const clarity = Math.random() * 0.3 + 0.65; // Random value between 0.65 and 0.95
    
    // Enthusiasm (simplified simulation)
    const enthusiasm = Math.random() * 0.3 + 0.6;
    
    // Pacing based on playback rate
    const idealPacing = 1.0;
    const pacingScore = 1 - Math.min(0.5, Math.abs(video.playbackRate - idealPacing));
    
    // Update metrics
    setMetrics(prev => {
      const newMetrics = {
        ...prev,
        eyeContact: newEyeContact,
        eyeContactScore: eyeContactScore,
        facialExpressions: newFacialExpressions,
        speechClarity: (prev.speechClarity * 0.95) + (clarity * 0.05),
        pacing: (prev.pacing * 0.95) + (pacingScore * 0.05),
        enthusiasm: (prev.enthusiasm * 0.95) + (enthusiasm * 0.05),
        slideAlignment: prev.slideAlignment || 0.7, // Placeholder
        gestures: prev.gestures || 0.65, // Placeholder
        overallScore: 0 // Will be calculated in finalizeAnalysis
      };
      
      return newMetrics;
    });
  };

  // Finalize analysis when video ends
  const finalizeAnalysis = () => {
    // Calculate overall score
    const overallScore = (
      metrics.eyeContact * 0.25 +
      metrics.facialExpressions * 0.15 +
      metrics.speechClarity * 0.2 +
      metrics.pacing * 0.15 +
      metrics.enthusiasm * 0.15 +
      metrics.slideAlignment * 0.05 +
      metrics.gestures * 0.05
    );
    
    setMetrics(prev => ({
      ...prev,
      overallScore
    }));
    
    toast({
      title: "Analysis complete",
      description: `Your tutorial video scored ${Math.round(overallScore * 100)}%. View detailed feedback below.`
    });
  };

  // Get color class based on score
  const getScoreColorClass = (score: number) => {
    if (score >= 0.8) return "bg-success text-white";
    if (score >= 0.6) return "bg-primary text-white";
    if (score >= 0.4) return "bg-warning text-white";
    return "bg-error text-white";
  };

  // Get score rating
  const getScoreRating = (score: number) => {
    if (score >= 0.8) return "Excellent";
    if (score >= 0.6) return "Good";
    if (score >= 0.4) return "Fair";
    return "Needs Improvement";
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4">
      <div className="relative w-full max-w-5xl h-full max-h-[90vh] flex flex-col">
        <Button 
          variant="outline" 
          size="icon" 
          className="absolute -top-10 right-0 bg-white"
          onClick={onClose}
        >
          <X className="h-4 w-4" />
        </Button>
        
        <div className="relative flex-1 min-h-0">
          <div className="absolute inset-0 flex flex-col">
            <div className="relative flex-1">
              <video 
                ref={videoRef}
                src={videoUrl} 
                controls 
                className="w-full h-full object-contain bg-black"
              />
              <canvas 
                ref={canvasRef}
                className="absolute top-0 left-0 w-full h-full pointer-events-none"
              />
              
              {isModelLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-70">
                  <div className="text-center text-white p-4">
                    <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-2" />
                    <p>Loading face detection model...</p>
                  </div>
                </div>
              )}
            </div>
            
            <div className="bg-white p-4 rounded-t-lg mt-4 overflow-y-auto" style={{maxHeight: '40%'}}>
              <div className="mb-4">
                <h3 className="font-medium mb-2 flex items-center">
                  {analysisComplete ? (
                    <>
                      <CheckCircle className="h-4 w-4 mr-2 text-success" /> Analysis Complete
                    </>
                  ) : (
                    <>
                      {isAnalyzing ? (
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin text-primary" />
                      ) : (
                        <Timer className="h-4 w-4 mr-2 text-primary" />
                      )}
                      Analysis Progress: {Math.round(analysisProgress)}%
                    </>
                  )}
                </h3>
                
                <Progress value={analysisProgress} className="h-2 mb-4" />
                
                <p className="text-xs text-neutral-500 mb-4">
                  {isAnalyzing 
                    ? "Analyzing your video in real-time... Play until the end for complete analysis." 
                    : analysisComplete 
                      ? "Analysis complete. Review your tutorial performance below."
                      : "Start playing the video to begin analysis."}
                </p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div>
                  <h4 className="text-sm font-medium mb-1 flex items-center">
                    <Eye className="h-3 w-3 mr-1 text-primary" /> Eye Contact
                  </h4>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-neutral-500">Quality</span>
                    <Badge className={getScoreColorClass(metrics.eyeContact)}>
                      {getScoreRating(metrics.eyeContact)}
                    </Badge>
                  </div>
                  <Progress value={metrics.eyeContact * 100} className="h-2 my-1" />
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-1 flex items-center">
                    <Smile className="h-3 w-3 mr-1 text-primary" /> Expressions
                  </h4>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-neutral-500">Engagement</span>
                    <Badge className={getScoreColorClass(metrics.facialExpressions)}>
                      {getScoreRating(metrics.facialExpressions)}
                    </Badge>
                  </div>
                  <Progress value={metrics.facialExpressions * 100} className="h-2 my-1" />
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-1 flex items-center">
                    <Volume2 className="h-3 w-3 mr-1 text-primary" /> Speech Clarity
                  </h4>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-neutral-500">Quality</span>
                    <Badge className={getScoreColorClass(metrics.speechClarity)}>
                      {getScoreRating(metrics.speechClarity)}
                    </Badge>
                  </div>
                  <Progress value={metrics.speechClarity * 100} className="h-2 my-1" />
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-1 flex items-center">
                    <Timer className="h-3 w-3 mr-1 text-primary" /> Pacing
                  </h4>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-neutral-500">Consistency</span>
                    <Badge className={getScoreColorClass(metrics.pacing)}>
                      {getScoreRating(metrics.pacing)}
                    </Badge>
                  </div>
                  <Progress value={metrics.pacing * 100} className="h-2 my-1" />
                </div>
              </div>
              
              {analysisComplete && (
                <div className="mt-4 pt-4 border-t">
                  <h3 className="font-medium mb-2">Tutorial Performance Summary</h3>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm">Overall Tutorial Quality:</span>
                    <Badge className={`${getScoreColorClass(metrics.overallScore)} px-3 py-1`}>
                      {Math.round(metrics.overallScore * 100)}%
                    </Badge>
                  </div>
                  
                  <p className="text-sm text-neutral-600 mb-3">
                    {metrics.overallScore >= 0.8 
                      ? "Excellent tutorial that effectively communicates concepts for " + learningLevel + " learners."
                      : metrics.overallScore >= 0.6
                        ? "Good tutorial with some areas for improvement for " + learningLevel + " learners."
                        : "This tutorial needs refinement to better engage " + learningLevel + " learners."}
                  </p>
                  
                  {/* Advanced Facial Expression Analysis with Google Cloud Vision */}
                  <div className="mt-6">
                    <h3 className="font-medium mb-3 flex items-center">
                      <BarChart3 className="h-5 w-5 mr-2 text-primary" />
                      Advanced Presentation Analysis
                    </h3>
                    <FacialExpressionReport 
                      facialExpressions={{
                        joy: metrics.facialExpressionsData?.joy || 0.5,
                        sorrow: metrics.facialExpressionsData?.sorrow || 0.1,
                        anger: metrics.facialExpressionsData?.anger || 0.1,
                        surprise: metrics.facialExpressionsData?.surprise || 0.3,
                        engagementScore: Math.round((metrics.facialExpressionsData?.joy || 0.5) * 100)
                      }}
                      eyeContact={{
                        score: Math.round((metrics.eyeContactScore || 0.7) * 100),
                        lookingAtCamera: (metrics.eyeContactScore || 0) > 0.65,
                        confidence: 0.85
                      }}
                      targetAudience={learningLevel}
                      showRecommendations={true}
                    />
                  </div>
                  
                  <div className="text-xs text-neutral-500">
                    <p className="font-medium mb-1">Top recommendations:</p>
                    <ul className="list-disc list-inside space-y-1">
                      {metrics.eyeContact < 0.7 && (
                        <li>Improve eye contact by looking directly at the camera more consistently</li>
                      )}
                      {metrics.facialExpressions < 0.7 && (
                        <li>Use more expressive facial communication to engage viewers</li>
                      )}
                      {metrics.speechClarity < 0.7 && (
                        <li>Work on speech clarity and articulation</li>
                      )}
                      {metrics.pacing < 0.7 && (
                        <li>Maintain a more consistent speaking pace</li>
                      )}
                      {metrics.enthusiasm < 0.7 && (
                        <li>Show more enthusiasm to better engage your audience</li>
                      )}
                      {Object.values(metrics).filter(score => score < 0.7).length === 0 && (
                        <li>Continue refining your excellent presentation skills</li>
                      )}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}