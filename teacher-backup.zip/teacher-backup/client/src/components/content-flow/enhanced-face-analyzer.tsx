import { useState, useEffect, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { apiRequest } from '@/lib/queryClient';
import {
  Eye,
  Smile,
  AlertCircle,
  Camera,
  RefreshCw,
  CheckCircle,
  XCircle
} from 'lucide-react';

interface EnhancedFaceAnalyzerProps {
  videoRef: React.RefObject<HTMLVideoElement>;
  onAnalysisComplete?: (analysis: {
    eyeContactScore: number;
    engagementScore: number;
    detectionConfidence: number;
  }) => void;
  autoCapture?: boolean;
  captureInterval?: number;
}

export default function EnhancedFaceAnalyzer({
  videoRef,
  onAnalysisComplete,
  autoCapture = false,
  captureInterval = 3000
}: EnhancedFaceAnalyzerProps) {
  const [capturing, setCapturing] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any | null>(null);
  const [captureCount, setCaptureCount] = useState(0);
  const [averageScores, setAverageScores] = useState({
    eyeContactScore: 0,
    engagementScore: 0,
    detectionConfidence: 0
  });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const captureTimerRef = useRef<NodeJS.Timeout | null>(null);
  const scoresRef = useRef<Array<{
    eyeContactScore: number;
    engagementScore: number;
    detectionConfidence: number;
  }>>([]);
  const { toast } = useToast();

  // Start auto-capture if enabled
  useEffect(() => {
    if (autoCapture) {
      startAutoCapture();
    }

    return () => {
      if (captureTimerRef.current) {
        clearInterval(captureTimerRef.current);
      }
    };
  }, [autoCapture]);

  // Start auto-capturing frames at regular intervals
  const startAutoCapture = () => {
    setCapturing(true);
    if (captureTimerRef.current) {
      clearInterval(captureTimerRef.current);
    }

    captureTimerRef.current = setInterval(() => {
      captureAndAnalyzeFrame();
    }, captureInterval);
  };

  // Stop auto-capturing
  const stopAutoCapture = () => {
    setCapturing(false);
    if (captureTimerRef.current) {
      clearInterval(captureTimerRef.current);
      captureTimerRef.current = null;
    }
  };

  // Capture current frame from video and send for analysis
  const captureAndAnalyzeFrame = async () => {
    if (!videoRef.current || !canvasRef.current || analyzing) return;

    try {
      setAnalyzing(true);
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');

      if (!context) {
        throw new Error('Could not get canvas context');
      }

      // Set canvas dimensions to match video
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      // Draw current video frame to canvas
      context.drawImage(video, 0, 0, canvas.width, canvas.height);

      // Get base64 encoded image data
      const imageData = canvas.toDataURL('image/jpeg', 0.8);

      // Analyze face using Google Cloud Vision API
      const result = await apiRequest<{ success: boolean; data: any }>('/api/vision/analyze-face', {
        method: 'POST',
        body: JSON.stringify({ image: imageData })
      });

      if (result.success && result.data) {
        setAnalysisResult(result.data);
        setCaptureCount(prev => prev + 1);

        // Extract scores for average calculation
        const eyeContactScore = result.data.eyeContact.score;
        const engagementScore = result.data.facialExpression.engagementScore;
        const detectionConfidence = result.data.detectionConfidence * 100;

        // Add to scores array
        scoresRef.current.push({
          eyeContactScore,
          engagementScore,
          detectionConfidence
        });

        // Calculate averages
        if (scoresRef.current.length > 0) {
          const avgEyeContact = scoresRef.current.reduce((sum, score) => sum + score.eyeContactScore, 0) / scoresRef.current.length;
          const avgEngagement = scoresRef.current.reduce((sum, score) => sum + score.engagementScore, 0) / scoresRef.current.length;
          const avgConfidence = scoresRef.current.reduce((sum, score) => sum + score.detectionConfidence, 0) / scoresRef.current.length;

          const newAverages = {
            eyeContactScore: Math.round(avgEyeContact),
            engagementScore: Math.round(avgEngagement),
            detectionConfidence: Math.round(avgConfidence)
          };

          setAverageScores(newAverages);

          // Call completion callback with average scores
          if (onAnalysisComplete && captureCount % 5 === 0) {
            onAnalysisComplete(newAverages);
          }
        }

        if (!result.data.faceDetected) {
          toast({
            title: 'No face detected',
            description: 'Please make sure your face is visible to the camera',
            variant: 'destructive'
          });
        }
      } else {
        throw new Error('Failed to analyze face');
      }
    } catch (error) {
      console.error('Error analyzing face:', error);
      toast({
        title: 'Analysis error',
        description: 'Could not analyze facial expression and eye contact',
        variant: 'destructive'
      });
    } finally {
      setAnalyzing(false);
    }
  };

  // Get a color class based on score
  const getScoreColorClass = (score: number) => {
    if (score >= 80) return 'bg-green-100 text-green-800';
    if (score >= 60) return 'bg-blue-100 text-blue-800';
    if (score >= 40) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium flex items-center">
            <Camera className="h-4 w-4 mr-1" /> Face Analysis with Google Cloud Vision
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Control buttons */}
            <div className="flex space-x-2">
              {!capturing ? (
                <Button 
                  size="sm" 
                  onClick={startAutoCapture} 
                  disabled={analyzing}
                >
                  Start Face Analysis
                </Button>
              ) : (
                <Button 
                  size="sm"
                  variant="outline" 
                  onClick={stopAutoCapture}
                >
                  Stop Analysis
                </Button>
              )}
              <Button
                size="sm"
                variant="outline"
                onClick={captureAndAnalyzeFrame}
                disabled={analyzing || !videoRef.current}
              >
                {analyzing ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-1 animate-spin" /> Analyzing...
                  </>
                ) : (
                  'Analyze Now'
                )}
              </Button>
            </div>

            {/* Stats summary */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Eye Contact Score */}
              <div className="bg-white p-2 rounded-lg shadow-sm border border-neutral-100">
                <div className="flex items-center justify-between mb-1">
                  <Label className="text-xs text-neutral-500 flex items-center">
                    <Eye className="h-3 w-3 mr-1" /> Eye Contact
                  </Label>
                  <Badge className={getScoreColorClass(averageScores.eyeContactScore)}>
                    {averageScores.eyeContactScore}%
                  </Badge>
                </div>
                <Progress value={averageScores.eyeContactScore} className="h-1" />
              </div>

              {/* Engagement Score */}
              <div className="bg-white p-2 rounded-lg shadow-sm border border-neutral-100">
                <div className="flex items-center justify-between mb-1">
                  <Label className="text-xs text-neutral-500 flex items-center">
                    <Smile className="h-3 w-3 mr-1" /> Engagement
                  </Label>
                  <Badge className={getScoreColorClass(averageScores.engagementScore)}>
                    {averageScores.engagementScore}%
                  </Badge>
                </div>
                <Progress value={averageScores.engagementScore} className="h-1" />
              </div>

              {/* Detection Confidence */}
              <div className="bg-white p-2 rounded-lg shadow-sm border border-neutral-100">
                <div className="flex items-center justify-between mb-1">
                  <Label className="text-xs text-neutral-500 flex items-center">
                    <AlertCircle className="h-3 w-3 mr-1" /> Confidence
                  </Label>
                  <Badge className={getScoreColorClass(averageScores.detectionConfidence)}>
                    {averageScores.detectionConfidence}%
                  </Badge>
                </div>
                <Progress value={averageScores.detectionConfidence} className="h-1" />
              </div>
            </div>

            {/* Current analysis details */}
            {analysisResult && (
              <div className="pt-1">
                <div className="text-xs text-neutral-500 flex items-center mb-2">
                  {analysisResult.faceDetected ? (
                    <CheckCircle className="h-3 w-3 mr-1 text-green-500" />
                  ) : (
                    <XCircle className="h-3 w-3 mr-1 text-red-500" />
                  )}
                  {analysisResult.faceDetected 
                    ? `Face detected - Capture #${captureCount}` 
                    : 'No face detected - Please ensure you are visible'}
                </div>

                {analysisResult.faceDetected && (
                  <div className="text-xs text-neutral-600 grid grid-cols-2 gap-2">
                    <div>
                      <span className="font-medium">Currently looking at camera:</span>{' '}
                      {analysisResult.eyeContact.lookingAtCamera ? 'Yes' : 'No'}
                    </div>
                    <div>
                      <span className="font-medium">Joy level:</span>{' '}
                      {Math.round(analysisResult.facialExpression.joy * 100)}%
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Hidden canvas for image capture */}
      <canvas 
        ref={canvasRef} 
        style={{ display: 'none' }}
      />
    </div>
  );
}