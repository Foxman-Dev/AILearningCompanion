import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  PenLine,
  SlidersHorizontal,
  Video,
  ArrowRight,
  CheckCircle,
  FileText,
  Sparkles,
  Eye,
  Volume2,
  Smile,
  Timer
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

// Step components will be imported as needed
import SpeechCreator from "./speech-creator";
import SlideshowCreator from "./slideshow-creator";
import EnhancedVideoCreator from "./enhanced-video-creator";

type ContentType = 'speech' | 'slideshow' | 'video';
type LearningLevel = 'beginner' | 'intermediate' | 'advanced';

interface ContentWorkflowProps {
  initialStep?: number;
  initialContent?: string;
  learningLevel?: LearningLevel;
}

export default function ContentWorkflow({ 
  initialStep = 1, 
  initialContent = "", 
  learningLevel = "beginner" 
}: ContentWorkflowProps) {
  const [currentStep, setCurrentStep] = useState(initialStep);
  const [contentTitle, setContentTitle] = useState("My Educational Content");
  const [speechContent, setSpeechContent] = useState(initialContent);
  const [slideshowContent, setSlideshowContent] = useState("");
  const [videoRecorded, setVideoRecorded] = useState(false);
  const [eyeContactScore, setEyeContactScore] = useState(0);
  const [speechClarityScore, setSpeechClarityScore] = useState(0);
  const [currentLevel, setCurrentLevel] = useState<LearningLevel>(learningLevel);
  const { toast } = useToast();
  
  // Tutorial metrics for more comprehensive analysis
  const [tutorialMetrics, setTutorialMetrics] = useState({
    pacing: 0,
    enthusiasm: 0,
    facialExpressions: 0,
    slideAlignment: 0,
    overall: 0
  });

  // Calculate overall progress
  const progress = Math.round((currentStep / 3) * 100);

  // Handle moving to next step
  const handleNextStep = () => {
    // Validate current step
    if (currentStep === 1 && !speechContent) {
      toast({
        title: "Speech content required",
        description: "Please create your speech content before continuing.",
        variant: "destructive"
      });
      return;
    }

    if (currentStep === 2 && !slideshowContent) {
      toast({
        title: "Slideshow content required",
        description: "Please create your slideshow content before continuing.",
        variant: "destructive"
      });
      return;
    }

    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  // Handle moving to previous step
  const handlePreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  // Handle speech content updates
  const handleSpeechUpdate = (content: string) => {
    setSpeechContent(content);
  };

  // Handle slideshow content updates
  const handleSlideshowUpdate = (content: string) => {
    setSlideshowContent(content);
  };

  // Handle video recording completion
  const handleVideoComplete = (eyeContact: number, speechClarity: number) => {
    setEyeContactScore(eyeContact);
    setSpeechClarityScore(speechClarity);
    setVideoRecorded(true);
    
    // Set simulated tutorial metrics
    setTutorialMetrics({
      pacing: 0.6 + (Math.random() * 0.3),
      enthusiasm: eyeContact * 0.7 + (Math.random() * 0.2),
      facialExpressions: 0.5 + (Math.random() * 0.4),
      slideAlignment: 0.7 + (Math.random() * 0.2),
      overall: (eyeContact * 0.3) + (speechClarity * 0.3) + (0.4 * (0.6 + Math.random() * 0.3))
    });
  };

  // Get color class based on score
  const getScoreColorClass = (score: number) => {
    if (score >= 0.8) return "bg-success text-white";
    if (score >= 0.6) return "bg-primary text-white";
    if (score >= 0.4) return "bg-warning text-white";
    return "bg-destructive text-white";
  };

  // Render the current step
  const renderCurrentStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <SpeechCreator 
            initialContent={speechContent}
            learningLevel={currentLevel}
            onContentChange={handleSpeechUpdate}
            onLevelChange={setCurrentLevel}
          />
        );
      case 2:
        return (
          <SlideshowCreator 
            speechContent={speechContent}
            learningLevel={currentLevel}
            onContentChange={handleSlideshowUpdate}
          />
        );
      case 3:
        return (
          <EnhancedVideoCreator 
            slideshowContent={slideshowContent}
            speechContent={speechContent}
            learningLevel={currentLevel}
            onRecordingComplete={handleVideoComplete}
          />
        );
      default:
        return <div>Invalid step</div>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <Card className="mb-8">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Create Educational Content</CardTitle>
            <div className="text-sm text-neutral-400">
              Learning Level: <span className="font-semibold capitalize">{currentLevel}</span>
            </div>
          </div>
          <CardDescription>
            Follow the steps to create effective educational content optimized for your audience
          </CardDescription>
          
          {/* Progress indicator */}
          <div className="mt-4">
            <div className="flex justify-between mb-2 text-sm">
              <div className="flex items-center">
                <PenLine className={`h-4 w-4 mr-1 ${currentStep >= 1 ? "text-primary" : "text-neutral-300"}`} /> 
                <span className={currentStep >= 1 ? "font-medium" : "text-neutral-300"}>Speech</span>
              </div>
              <div className="flex items-center">
                <SlidersHorizontal className={`h-4 w-4 mr-1 ${currentStep >= 2 ? "text-primary" : "text-neutral-300"}`} /> 
                <span className={currentStep >= 2 ? "font-medium" : "text-neutral-300"}>Slideshow</span>
              </div>
              <div className="flex items-center">
                <Video className={`h-4 w-4 mr-1 ${currentStep >= 3 ? "text-primary" : "text-neutral-300"}`} /> 
                <span className={currentStep >= 3 ? "font-medium" : "text-neutral-300"}>Video</span>
              </div>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </CardHeader>
        
        <CardContent>
          {renderCurrentStep()}
          
          {/* Navigation buttons */}
          <div className="flex justify-between mt-6">
            <Button 
              variant="outline" 
              onClick={handlePreviousStep}
              disabled={currentStep === 1}
            >
              Back
            </Button>
            
            {currentStep < 3 ? (
              <Button 
                className="bg-primary text-white"
                onClick={handleNextStep}
              >
                Continue <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            ) : videoRecorded ? (
              <Button 
                className="bg-success text-white"
                onClick={() => {
                  toast({
                    title: "Content creation complete!",
                    description: "Your educational content has been created and saved.",
                  });
                }}
              >
                <CheckCircle className="mr-2 h-4 w-4" /> Complete
              </Button>
            ) : (
              <Button 
                disabled
                className="bg-primary text-white opacity-50"
              >
                Complete Recording First
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Content summary if all steps completed */}
      {videoRecorded && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Sparkles className="mr-2 h-5 w-5 text-primary" /> Content Analysis & Summary
            </CardTitle>
            <CardDescription>
              Comprehensive analysis of your educational content
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-white p-4 rounded-lg shadow border border-neutral-100">
                <div className="flex items-center mb-2">
                  <FileText className="h-4 w-4 mr-2 text-primary" />
                  <h3 className="font-medium">Content Creation</h3>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm mb-2">
                  <div>
                    <p className="text-xs text-neutral-500">Speech Length</p>
                    <p className="font-medium">{Math.round(speechContent.length / 5)} words</p>
                  </div>
                  <div>
                    <p className="text-xs text-neutral-500">Slides Created</p>
                    <p className="font-medium">{slideshowContent.split('---').length}</p>
                  </div>
                </div>
                <p className="text-xs text-neutral-500 mt-2">
                  Content optimized for <span className="font-medium capitalize">{currentLevel}</span> knowledge level
                </p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow border border-neutral-100">
                <div className="flex items-center mb-2">
                  <Eye className="h-4 w-4 mr-2 text-primary" />
                  <h3 className="font-medium">Eye Contact & Engagement</h3>
                </div>
                <div className="mb-2">
                  <div className="flex justify-between items-center mb-1">
                    <p className="text-xs text-neutral-500">Eye Contact Quality</p>
                    <Badge className={getScoreColorClass(eyeContactScore)}>
                      {eyeContactScore >= 0.8 ? "Excellent" : 
                       eyeContactScore >= 0.6 ? "Good" : 
                       eyeContactScore >= 0.4 ? "Fair" : "Needs Work"}
                    </Badge>
                  </div>
                  <Progress value={eyeContactScore * 100} className="h-2 mb-2" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <p className="text-xs text-neutral-500">Facial Expressions</p>
                    <Badge className={getScoreColorClass(tutorialMetrics.facialExpressions)}>
                      {tutorialMetrics.facialExpressions >= 0.8 ? "Excellent" : 
                       tutorialMetrics.facialExpressions >= 0.6 ? "Good" : 
                       tutorialMetrics.facialExpressions >= 0.4 ? "Fair" : "Needs Work"}
                    </Badge>
                  </div>
                  <Progress value={tutorialMetrics.facialExpressions * 100} className="h-2" />
                </div>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow border border-neutral-100">
                <div className="flex items-center mb-2">
                  <Volume2 className="h-4 w-4 mr-2 text-primary" />
                  <h3 className="font-medium">Speech Quality</h3>
                </div>
                <div className="mb-2">
                  <div className="flex justify-between items-center mb-1">
                    <p className="text-xs text-neutral-500">Speech Clarity</p>
                    <Badge className={getScoreColorClass(speechClarityScore)}>
                      {speechClarityScore >= 0.8 ? "Excellent" : 
                       speechClarityScore >= 0.6 ? "Good" : 
                       speechClarityScore >= 0.4 ? "Fair" : "Needs Work"}
                    </Badge>
                  </div>
                  <Progress value={speechClarityScore * 100} className="h-2 mb-2" />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <p className="text-xs text-neutral-500">Pacing</p>
                    <Badge className={getScoreColorClass(tutorialMetrics.pacing)}>
                      {tutorialMetrics.pacing >= 0.8 ? "Excellent" : 
                       tutorialMetrics.pacing >= 0.6 ? "Good" : 
                       tutorialMetrics.pacing >= 0.4 ? "Fair" : "Needs Work"}
                    </Badge>
                  </div>
                  <Progress value={tutorialMetrics.pacing * 100} className="h-2" />
                </div>
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow border border-neutral-100 mb-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-medium flex items-center">
                  <Sparkles className="h-4 w-4 mr-2 text-primary" /> 
                  Overall Tutorial Quality
                </h3>
                <Badge className={getScoreColorClass(tutorialMetrics.overall)}>
                  {Math.round(tutorialMetrics.overall * 100)}% - {
                    tutorialMetrics.overall >= 0.8 ? "Excellent" : 
                    tutorialMetrics.overall >= 0.6 ? "Good" : 
                    tutorialMetrics.overall >= 0.4 ? "Fair" : "Needs Work"
                  }
                </Badge>
              </div>
              
              <Progress value={tutorialMetrics.overall * 100} className="h-3 mb-4" />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium mb-2">Strengths</h4>
                  <ul className="text-xs text-neutral-600 space-y-1 list-disc list-inside">
                    {eyeContactScore >= 0.7 && <li>Strong eye contact creates audience connection</li>}
                    {tutorialMetrics.facialExpressions >= 0.7 && <li>Expressive facial communication</li>}
                    {speechClarityScore >= 0.7 && <li>Clear and articulate speech delivery</li>}
                    {tutorialMetrics.pacing >= 0.7 && <li>Well-paced content delivery</li>}
                    {tutorialMetrics.slideAlignment >= 0.7 && <li>Effective integration of visual aids</li>}
                    {tutorialMetrics.enthusiasm >= 0.7 && <li>Engaging and enthusiastic presentation</li>}
                    {Object.values({...tutorialMetrics, eyeContact: eyeContactScore, speechClarity: speechClarityScore})
                      .filter(score => score >= 0.7).length === 0 && 
                      <li>Continue practicing to develop presentation strengths</li>
                    }
                  </ul>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-2">Areas for Improvement</h4>
                  <ul className="text-xs text-neutral-600 space-y-1 list-disc list-inside">
                    {eyeContactScore < 0.7 && <li>Improve eye contact with the camera</li>}
                    {tutorialMetrics.facialExpressions < 0.7 && <li>Use more varied facial expressions</li>}
                    {speechClarityScore < 0.7 && <li>Work on speech clarity and pronunciation</li>}
                    {tutorialMetrics.pacing < 0.7 && <li>Maintain more consistent speaking pace</li>}
                    {tutorialMetrics.slideAlignment < 0.7 && <li>Better align speech with visual content</li>}
                    {tutorialMetrics.enthusiasm < 0.7 && <li>Show more enthusiasm in presentation</li>}
                    {Object.values({...tutorialMetrics, eyeContact: eyeContactScore, speechClarity: speechClarityScore})
                      .filter(score => score < 0.7).length === 0 && 
                      <li>Refine your already strong presentation skills</li>
                    }
                  </ul>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow border border-neutral-100">
              <h3 className="font-medium mb-3">Knowledge Level Adaptation</h3>
              <p className="text-sm text-neutral-600 mb-3">
                Your content is tailored for <span className="font-semibold capitalize">{currentLevel}</span> level learners.
              </p>
              <div className="text-sm text-neutral-600">
                {currentLevel === 'beginner' ? (
                  <div className="space-y-2">
                    <p>✓ Uses accessible language and clear explanations</p>
                    <p>✓ Builds foundational knowledge with proper pacing</p>
                    <p>✓ Visual aids reinforce key concepts effectively</p>
                  </div>
                ) : currentLevel === 'intermediate' ? (
                  <div className="space-y-2">
                    <p>✓ Balances technical terminology with clear explanations</p>
                    <p>✓ Builds on existing knowledge with appropriate depth</p>
                    <p>✓ Presentation complexity matches audience capability</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <p>✓ Uses appropriate technical depth and complexity</p>
                    <p>✓ Assumes strong foundational knowledge</p>
                    <p>✓ Challenging content presented with proper context</p>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}