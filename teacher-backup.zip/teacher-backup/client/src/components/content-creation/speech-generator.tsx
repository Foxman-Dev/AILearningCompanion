import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Sparkles, Lightbulb, RotateCcw, Copy, Check, ArrowRight } from "lucide-react";

interface SpeechGeneratorProps {
  onSpeechGenerated: (speech: string) => void;
}

export default function SpeechGenerator({ onSpeechGenerated }: SpeechGeneratorProps) {
  const [topic, setTopic] = useState("");
  const [audience, setAudience] = useState("general");
  const [duration, setDuration] = useState(5); // in minutes
  const [includeExamples, setIncludeExamples] = useState(true);
  const [includeHooks, setIncludeHooks] = useState(true);
  const [formalityLevel, setFormalityLevel] = useState(50);
  const [knowledgeLevel, setKnowledgeLevel] = useState("intermediate");
  const [generatedSpeech, setGeneratedSpeech] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  // Generate the speech using OpenAI
  const generateSpeech = async () => {
    if (!topic) {
      toast({
        title: "Topic required",
        description: "Please enter a topic for your speech",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    try {
      const prompt = `
Create an educational speech script about "${topic}" for a ${knowledgeLevel} level audience.
The speech should be approximately ${duration} minutes long when spoken aloud.
Target audience: ${audience}.
Formality level: ${formalityLevel}% (where 0% is very casual and 100% is very formal).
${includeExamples ? "Include practical examples and scenarios." : ""}
${includeHooks ? "Include engaging hooks and questions to maintain audience interest." : ""}

Format the script with clear sections, including an introduction, main points, and conclusion.
Make it conversational and suitable for an educational presentation.
`;

      const response = await apiRequest<{content: string}>("/api/generate-content", {
        method: "POST",
        body: JSON.stringify({
          content: prompt,
          contentType: "speech",
          knowledgeLevel: knowledgeLevel,
          enhancementType: "clarity"
        })
      });

      if (response && response.content) {
        setGeneratedSpeech(response.content);
        toast({
          title: "Speech generated!",
          description: "Your educational speech has been created successfully.",
        });
      } else {
        throw new Error("Failed to generate speech content");
      }
    } catch (error) {
      console.error("Speech generation error:", error);
      toast({
        title: "Generation failed",
        description: "There was an error generating your speech. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  // Copy generated speech to clipboard
  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedSpeech);
    setCopied(true);
    toast({
      title: "Copied to clipboard",
      description: "Speech text has been copied to your clipboard."
    });
    setTimeout(() => setCopied(false), 2000);
  };

  // Reset the form
  const resetForm = () => {
    setTopic("");
    setAudience("general");
    setDuration(5);
    setIncludeExamples(true);
    setIncludeHooks(true);
    setFormalityLevel(50);
    setKnowledgeLevel("intermediate");
    setGeneratedSpeech("");
  };

  // Use the generated speech in the main application
  const useSpeech = () => {
    if (generatedSpeech) {
      onSpeechGenerated(generatedSpeech);
      toast({
        title: "Speech applied",
        description: "The generated speech has been added to your content."
      });
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Sparkles className="h-5 w-5 mr-2 text-primary" />
            AI Speech Generator
          </CardTitle>
          <CardDescription>
            Create educational speech content using AI. Provide a topic and preferences to generate a tailored speech.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Speech Parameters */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="topic">Speech Topic</Label>
                <Input 
                  id="topic"
                  placeholder="e.g. The impact of artificial intelligence in education"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="audience">Target Audience</Label>
                <Select value={audience} onValueChange={setAudience}>
                  <SelectTrigger id="audience">
                    <SelectValue placeholder="Select audience" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General Audience</SelectItem>
                    <SelectItem value="students">Students</SelectItem>
                    <SelectItem value="professionals">Professionals</SelectItem>
                    <SelectItem value="educators">Educators</SelectItem>
                    <SelectItem value="children">Children</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="duration">Approximate Duration (minutes)</Label>
                <div className="flex items-center space-x-2">
                  <Slider 
                    id="duration" 
                    min={1} 
                    max={15} 
                    step={1}
                    value={[duration]}
                    onValueChange={(value) => setDuration(value[0])}
                    className="flex-1"
                  />
                  <span className="w-8 text-center">{duration}</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="knowledge-level">Knowledge Level</Label>
                <Select value={knowledgeLevel} onValueChange={setKnowledgeLevel}>
                  <SelectTrigger id="knowledge-level">
                    <SelectValue placeholder="Select knowledge level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="formality">Formality Level</Label>
                <div className="flex items-center space-x-2">
                  <span className="text-xs">Casual</span>
                  <Slider 
                    id="formality" 
                    min={0} 
                    max={100} 
                    step={10}
                    value={[formalityLevel]}
                    onValueChange={(value) => setFormalityLevel(value[0])}
                    className="flex-1"
                  />
                  <span className="text-xs">Formal</span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="include-examples" className="cursor-pointer">Include examples and scenarios</Label>
                  <Switch 
                    id="include-examples" 
                    checked={includeExamples} 
                    onCheckedChange={setIncludeExamples} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="include-hooks" className="cursor-pointer">Include engagement hooks</Label>
                  <Switch 
                    id="include-hooks" 
                    checked={includeHooks} 
                    onCheckedChange={setIncludeHooks} 
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Generation Button */}
          <div className="flex justify-center pt-2">
            <Button 
              onClick={generateSpeech} 
              disabled={isGenerating || !topic} 
              className="w-full md:w-auto"
              size="lg"
            >
              {isGenerating ? (
                <>Generating<span className="loading loading-dots ml-2"></span></>
              ) : (
                <>
                  <Lightbulb className="h-4 w-4 mr-2" />
                  Generate Speech
                </>
              )}
            </Button>
          </div>

          {/* Generated Content */}
          {generatedSpeech && (
            <div className="mt-8">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-medium">Generated Speech</h3>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" onClick={copyToClipboard}>
                    {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                    {copied ? "Copied" : "Copy"}
                  </Button>
                  <Button variant="outline" size="sm" onClick={resetForm}>
                    <RotateCcw className="h-4 w-4 mr-1" />
                    Reset
                  </Button>
                </div>
              </div>
              <div className="border rounded-md p-4 bg-muted/20 min-h-[200px] max-h-[400px] overflow-y-auto">
                <pre className="whitespace-pre-wrap font-sans text-sm">
                  {generatedSpeech}
                </pre>
              </div>
            </div>
          )}
        </CardContent>
        {generatedSpeech && (
          <CardFooter className="flex justify-end pt-2">
            <Button onClick={useSpeech} className="group">
              Use This Speech <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </CardFooter>
        )}
      </Card>
    </div>
  );
}