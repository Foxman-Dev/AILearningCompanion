import ContentWorkflow from "@/components/content-flow/content-workflow";

export default function ContentWorkflowPage() {
  return (
    <div className="container mx-auto px-4 py-6">
      <ContentWorkflow />
    </div>
  );
}