import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import ContentCreator from "./content-creator";
import VideoRecorder from "@/components/content-creator/video-recorder";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, Film, FileText, Video, ArrowLeft } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function VideoCoursePage() {
  const params = useParams();
  const [_, setLocation] = useLocation();
  const id = params?.id;
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>("script");
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [eyeContactScore, setEyeContactScore] = useState<number>(0);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);

  const { data: videoContent, isLoading } = useQuery({
    queryKey: id ? [`/api/video-courses/${id}`] : null,
  });

  useEffect(() => {
    if (!id) {
      // If no ID, redirect to content creator with video type
      setLocation("/create?type=video");
    }
  }, [id, setLocation]);

  // Clean up URL objects on unmount
  useEffect(() => {
    return () => {
      if (videoUrl) {
        URL.revokeObjectURL(videoUrl);
      }
    };
  }, [videoUrl]);

  const handleRecordingComplete = (blob: Blob, score: number) => {
    setVideoBlob(blob);
    setVideoUrl(URL.createObjectURL(blob));
    setEyeContactScore(score);
    setActiveTab("review");
    
    toast({
      title: "Recording complete",
      description: `Your video has been recorded with an eye contact score of ${Math.round(score * 100)}%`,
    });
  };

  const analyzeVideoContent = async () => {
    if (!videoBlob) return;
    
    setIsAnalyzing(true);
    
    try {
      // In a real implementation, you would upload the video
      // and analyze it with AI on the server
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "Video analysis complete",
        description: "AI feedback for your video has been generated",
      });
      
      setActiveTab("feedback");
    } catch (error) {
      toast({
        title: "Analysis failed",
        description: "There was an error analyzing your video",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getEyeContactLevel = () => {
    if (eyeContactScore >= 0.8) return "Excellent";
    if (eyeContactScore >= 0.6) return "Good";
    if (eyeContactScore >= 0.4) return "Fair";
    return "Needs Improvement";
  };

  const getEyeContactColor = () => {
    if (eyeContactScore >= 0.8) return "bg-success text-white";
    if (eyeContactScore >= 0.6) return "bg-primary text-white";
    if (eyeContactScore >= 0.4) return "bg-warning text-white";
    return "bg-error text-white";
  };

  if (isLoading) {
    return <div className="container mx-auto p-8">Loading video course...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          className="mr-2" 
          onClick={() => setLocation("/")}
        >
          <ArrowLeft className="h-4 w-4 mr-1" /> Back
        </Button>
        <h1 className="text-2xl font-bold text-neutral-800">{id ? "Edit Video Course" : "Create Video Course"}</h1>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="script" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <FileText className="h-4 w-4 mr-2" /> Script
          </TabsTrigger>
          <TabsTrigger value="record" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Film className="h-4 w-4 mr-2" /> Record
          </TabsTrigger>
          <TabsTrigger value="review" className="data-[state=active]:bg-primary data-[state=active]:text-white" disabled={!videoUrl}>
            <Video className="h-4 w-4 mr-2" /> Review
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="script">
          <Card>
            <CardHeader>
              <CardTitle>Create Your Video Script</CardTitle>
              <CardDescription>
                Write and refine your video script before recording. This will be analyzed to ensure appropriate content complexity.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ContentCreator />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="record">
          <Card>
            <CardHeader>
              <CardTitle>Record Your Video</CardTitle>
              <CardDescription>
                Record yourself presenting the content. Eye contact will be analyzed to help improve your delivery.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <VideoRecorder 
                onRecordingComplete={handleRecordingComplete} 
              />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="review">
          {videoUrl && (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Review Your Recording</CardTitle>
                  <Badge className={`flex items-center ${getEyeContactColor()}`}>
                    <Eye className="mr-1 h-4 w-4" />
                    Eye Contact: {getEyeContactLevel()} ({Math.round(eyeContactScore * 100)}%)
                  </Badge>
                </div>
                <CardDescription>
                  Review your recording and analyze the content and presentation.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <video 
                    src={videoUrl} 
                    controls 
                    className="w-full rounded-lg"
                  />
                </div>
                
                <div className="mt-6">
                  <h3 className="text-lg font-semibold mb-3">Eye Contact Analysis</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="bg-white p-4 rounded-lg shadow">
                      <h4 className="font-medium mb-2">Engagement Level</h4>
                      <div className="text-3xl font-bold text-primary">
                        {Math.round(eyeContactScore * 100)}%
                      </div>
                    </div>
                    
                    <div className="bg-white p-4 rounded-lg shadow">
                      <h4 className="font-medium mb-2">Consistency</h4>
                      <div className="text-3xl font-bold text-primary">
                        {Math.round(eyeContactScore * 90)}%
                      </div>
                    </div>
                    
                    <div className="bg-white p-4 rounded-lg shadow">
                      <h4 className="font-medium mb-2">Duration</h4>
                      <div className="text-3xl font-bold text-primary">
                        Good
                      </div>
                    </div>
                  </div>
                  
                  <h3 className="text-lg font-semibold mb-3">Eye Contact Feedback</h3>
                  <div className="bg-white p-4 rounded-lg shadow mb-6">
                    <p className="text-neutral-600">
                      {eyeContactScore >= 0.8 ? (
                        "Excellent eye contact! You consistently maintained focus on the camera, which creates a strong connection with your audience."
                      ) : eyeContactScore >= 0.6 ? (
                        "Good eye contact. You generally maintained focus on the camera, with only occasional breaks in attention."
                      ) : eyeContactScore >= 0.4 ? (
                        "Fair eye contact. You sometimes looked away from the camera, which may reduce audience engagement. Try to maintain more consistent eye contact."
                      ) : (
                        "Your eye contact needs improvement. You frequently looked away from the camera, which can disconnect you from your audience. Practice looking directly at the camera more consistently."
                      )}
                    </p>
                  </div>
                  
                  <Button 
                    className="w-full bg-primary text-white"
                    onClick={analyzeVideoContent}
                    disabled={isAnalyzing}
                  >
                    {isAnalyzing ? "Analyzing..." : "Analyze Content & Presentation"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="feedback">
          <Card>
            <CardHeader>
              <CardTitle>AI Feedback</CardTitle>
              <CardDescription>
                Comprehensive analysis of your video content and presentation.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Content Analysis</h3>
                  <div className="bg-white p-4 rounded-lg shadow mb-4">
                    <h4 className="font-medium text-primary mb-2">Clarity</h4>
                    <p className="text-neutral-600 mb-2">
                      Your explanation of key concepts is clear, but could benefit from simpler language in some sections.
                    </p>
                    <div className="text-sm">
                      <strong>Suggestion:</strong> Simplify technical terminology in the middle section and add brief definitions.
                    </div>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg shadow mb-4">
                    <h4 className="font-medium text-primary mb-2">Structure</h4>
                    <p className="text-neutral-600 mb-2">
                      Good introduction and conclusion, but the middle section could be better organized.
                    </p>
                    <div className="text-sm">
                      <strong>Suggestion:</strong> Break down complex ideas into numbered steps or bullet points for easier comprehension.
                    </div>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg shadow">
                    <h4 className="font-medium text-primary mb-2">Knowledge Level Appropriateness</h4>
                    <p className="text-neutral-600 mb-2">
                      Some concepts may be too advanced for beginner learners.
                    </p>
                    <div className="text-sm">
                      <strong>Suggestion:</strong> Add more background context and basic explanations for beginners, or specify this content is for intermediate learners.
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-3">Presentation Analysis</h3>
                  <div className="bg-white p-4 rounded-lg shadow mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-primary">Eye Contact</h4>
                      <Badge className={getEyeContactColor()}>
                        {getEyeContactLevel()}
                      </Badge>
                    </div>
                    <p className="text-neutral-600 mb-2">
                      {eyeContactScore >= 0.8 ? (
                        "Excellent camera engagement creates a strong connection with viewers."
                      ) : eyeContactScore >= 0.6 ? (
                        "Good eye contact, but could be more consistent throughout."
                      ) : eyeContactScore >= 0.4 ? (
                        "Inconsistent eye contact may reduce audience engagement."
                      ) : (
                        "Limited eye contact creates a disconnect with the audience."
                      )}
                    </p>
                    <div className="text-sm">
                      <strong>Suggestion:</strong> {eyeContactScore < 0.7 ? "Practice looking directly at the camera more consistently." : "Maintain your excellent eye contact in future videos."}
                    </div>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg shadow mb-4">
                    <h4 className="font-medium text-primary mb-2">Pace & Timing</h4>
                    <p className="text-neutral-600 mb-2">
                      Your speaking pace is appropriate, but some sections could use more pauses.
                    </p>
                    <div className="text-sm">
                      <strong>Suggestion:</strong> Add deliberate pauses after introducing important concepts to give viewers time to process.
                    </div>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg shadow">
                    <h4 className="font-medium text-primary mb-2">Visual Opportunities</h4>
                    <p className="text-neutral-600 mb-2">
                      Adding visual elements would enhance understanding of complex topics.
                    </p>
                    <div className="text-sm">
                      <strong>Suggestion:</strong> Include diagrams or charts for key concepts, especially when explaining relationships or processes.
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-6">
                <Button 
                  className="w-full bg-primary text-white"
                  onClick={() => setLocation("/")}
                >
                  Save and Return to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
