import { useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import ContentCreator from "./content-creator";

export default function SlideshowPage() {
  const params = useParams();
  const [_, setLocation] = useLocation();
  const id = params?.id;

  const { data: slideshowContent, isLoading } = useQuery({
    queryKey: id ? [`/api/slideshows/${id}`] : null,
  });

  useEffect(() => {
    if (!id) {
      // If no ID, redirect to content creator with slideshow type
      setLocation("/create?type=slideshow");
    }
  }, [id, setLocation]);

  if (isLoading) {
    return <div className="container mx-auto p-8">Loading slideshow...</div>;
  }

  if (!id) {
    return <ContentCreator />;
  }

  // Display existing slideshow editing interface
  return (
    <div className="container mx-auto p-8">
      <h1 className="text-2xl font-bold mb-4">Edit Slideshow</h1>
      {/* Slideshow editing interface would go here */}
      <ContentCreator />
    </div>
  );
}
