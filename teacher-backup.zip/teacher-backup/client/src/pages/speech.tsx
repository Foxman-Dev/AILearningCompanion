import { useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import ContentCreator from "./content-creator";

export default function SpeechPage() {
  const params = useParams();
  const [_, setLocation] = useLocation();
  const id = params?.id;

  const { data: speechContent, isLoading } = useQuery({
    queryKey: id ? [`/api/speeches/${id}`] : null,
  });

  useEffect(() => {
    if (!id) {
      // If no ID, redirect to content creator with speech type
      setLocation("/create?type=speech");
    }
  }, [id, setLocation]);

  if (isLoading) {
    return <div className="container mx-auto p-8">Loading speech...</div>;
  }

  if (!id) {
    return <ContentCreator />;
  }

  // Display existing speech editing interface
  return (
    <div className="container mx-auto p-8">
      <h1 className="text-2xl font-bold mb-4">Edit Speech</h1>
      {/* Speech editing interface would go here */}
      <ContentCreator />
    </div>
  );
}
